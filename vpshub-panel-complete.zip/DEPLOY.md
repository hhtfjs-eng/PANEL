# DeUp-VPS — Production Hosting Guide

Complete guide to host the panel on your own VPS, connect it to a separate
LXC host for containers, and scale it to **2500+ concurrent users**.

---

## 1. Architecture (your setup)

```
┌─────────────────────────┐          ┌──────────────────────────┐
│  PANEL VPS              │          │  LXC HOST VPS            │
│  (DeUp control panel)   │  SSH     │  (runs the containers)   │
│                         │─────────▶│                          │
│  · Next.js (cluster)    │ key-auth │  · LXC + br0 bridge      │
│  · PostgreSQL           │          │  · lxc-create/start/...  │
│  · Redis (optional)     │          │  · NAT 10.10.0.0/24      │
│  · Caddy (HTTPS)        │          │                          │
│  · realtime svc :3003   │          │  customer VPS = LXC CT   │
└─────────────────────────┘          └──────────────────────────┘
```

The panel NEVER runs containers itself — it provisions them on the LXC
host over key-based SSH using `lxc-create / lxc-start / lxc-stop`.

---

## 2. Host the panel on your VPS (step by step)

Run on the **panel VPS** (Ubuntu 22.04/24.04):

```bash
# --- Prerequisites -------------------------------------------------
sudo apt update && sudo apt install -y curl git caddy
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
sudo npm i -g pm2 bun        # bun runs the realtime service
curl -fsSL https://www.postgresql.org/media/keys/ACCC4CF8.asc |
  sudo apt-key add -
echo "deb http://apt.postgresql.org/pub/repos/apt $(lsb_release -cs)-pgdg main" |
  sudo tee /etc/apt/sources.list.d/pgdg.list
sudo apt update && sudo apt install -y postgresql redis-server

# --- Database (PostgreSQL — required for 2500 users) ---------------
sudo -u postgres psql -c "CREATE USER deup WITH PASSWORD 'strong-pass-here';"
sudo -u postgres psql -c "CREATE DATABASE deup OWNER deup;"

# --- App ------------------------------------------------------------
git clone <your-repo> /opt/deup && cd /opt/deup   # (or unzip the source zip)
npm install

cp .env.example .env
nano .env   # set DATABASE_URL to your Postgres URL + a strong JWT_SECRET
#   DATABASE_URL=postgresql://deup:strong-pass-here@127.0.0.1:5432/deup
#   JWT_SECRET=<output of: openssl rand -hex 32>
#   REDIS_URL=redis://127.0.0.1:6379        (optional)
#   REALTIME_URL=http://127.0.0.1:3003

# Create the schema, generate the client, and seed everything
# (super admin NØCTIS + plans + OS templates + IP pools + branding)
npm run db:push:pg
npm run db:generate:pg
node prisma/seed.mjs        # idempotent — safe to re-run anytime

# Build + start in CLUSTER MODE (one process per CPU core)
npm run build
mkdir -p logs
pm2 start ecosystem.config.js
pm2 save && pm2 startup      # auto-start on reboot
```

### Caddy reverse proxy (automatic HTTPS)

```
# /etc/caddy/Caddyfile
your-domain.com {
    encode zstd gzip
    reverse_proxy 127.0.0.1:3000
}
# realtime websocket service
realtime.your-domain.com {
    reverse_proxy 127.0.0.1:3003
}
```

```bash
sudo systemctl reload caddy
```

> **Note on websockets**: the frontend connects with
> `io("/?XTransformPort=3003")` which the space-z gateway translates.
> On your own domain, either expose the realtime service on the
> subdomain above and change the connect URL in
> `src/components/customer/vps-console.tsx` to that subdomain, or add a
> Caddy route that path-rewrites `/socket.io/` to port 3003.

---

## 3. LXC — create VPSes as LXC containers

### 3.1 Prepare the LXC host (once)

Copy `scripts/setup-lxc-host.sh` to your **LXC VPS** and run it:

```bash
scp scripts/setup-lxc-host.sh root@<lxc-host-ip>:
ssh root@<lxc-host-ip> 'bash setup-lxc-host.sh'
```

The script installs LXC, creates the NAT bridge `br0` (10.10.0.0/24),
caches OS templates, runs a smoke-test container, and prints the exact
next steps.

### 3.2 Connect the panel to the LXC host

On the **panel VPS**:

```bash
# key-based SSH (must not prompt for a password)
ssh-keygen -t ed25519 -N "" -f /root/.ssh/id_ed25519
ssh-copy-id root@<lxc-host-ip>

# verify — this MUST print a container list with no password prompt
ssh -o BatchMode=yes root@<lxc-host-ip> 'lxc-ls'
```

In the panel: **Admin → Nodes → Add Node**

| Field        | Value                                  |
|--------------|----------------------------------------|
| Provider     | **LXC (native containers)**            |
| API Endpoint | `root@<lxc-host-ip>`                   |
| Capacities   | real cores/RAM/disk of the LXC host    |

Now **Deploy VPS** from the wizard — the panel runs `lxc-create` on the
host, applies CPU/RAM limits, starts the container and tracks it.
Every deployed "VPS" is a real LXC container.

### 3.3 How the LXC provider maps to commands

| Panel action   | Command on the LXC host                          |
|----------------|--------------------------------------------------|
| Deploy         | `lxc-create -t download -n <name>` + limits      |
| Start / Stop   | `lxc-start -n` / `lxc-stop -n`                   |
| Restart        | `lxc-stop` + `lxc-start`                         |
| Reinstall      | `lxc-destroy -f` + `lxc-create` (new template)   |
| Resize         | `lxc config set` (limits.cpu / limits.memory)    |
| Delete         | `lxc-stop` + `lxc-destroy -f`                    |
| Status/Stats   | `lxc-info -n`                                    |

Container naming: the container name = the VPS hostname = the owner's
name without spaces → SSH login reads `root@ownername` exactly as
requested. OS templates use `distro:version` IDs (e.g. `ubuntu:22.04`)
— set them on each OS Template record's *provider template id*.

### 3.4 Exposing container ports (optional)

Containers live on NAT (`10.10.0.x`). To publish a port on the LXC host:

```bash
iptables -t nat -A PREROUTING -p tcp --dport 2222 -j DNAT --to 10.10.0.10:22
```

Or allocate public IPs by routing a subnet to `br0` instead of NAT.

---

## 4. Scaling to 2500+ concurrent users — what was implemented

1. **PostgreSQL schema** — `prisma/schema.postgres.prisma` (SQLite
   serializes writes; Postgres handles 2500 users easily). Scripts:
   `npm run db:push:pg` / `db:migrate:pg` / `db:generate:pg`.
2. **PM2 cluster mode** — `ecosystem.config.js` runs one Next.js
   process per CPU core (`instances: 'max'`). Stateless JWT sessions in
   HTTP-only cookies mean any instance can serve any request.
3. **Atomic deployment claim** — `processDeployment()` uses a
   conditional `updateMany` so parallel cluster instances never
   double-process the same provisioning job.
4. **Redis adapter for socket.io** — when `REDIS_URL` is set, the
   realtime service plugs in `@socket.io/redis-adapter`, letting you
   run multiple realtime instances behind a load balancer.
5. **Pagination everywhere** — VPS/users lists are paginated
   server-side (`?page=&pageSize=`), so 2500 users don't produce
   2500-row responses.
6. **Indexed database** — every hot query path (ownerId, status,
   vpsId, createdAt…) is indexed in the Prisma schema.

### Capacity math

| Layer                  | Capacity per instance         |
|------------------------|-------------------------------|
| Next.js cluster worker | ~150–300 req/s                |
| PostgreSQL (tuned)     | ~2000+ simple queries/s       |
| socket.io instance     | ~5–10k concurrent sockets     |

A logged-in user generates roughly **1 API call per 15s** (dashboard
poll) + idle socket traffic → 2500 users ≈ **170 req/s** steady state
with spikes at login rushes. comfortably within one 8-core panel VPS.

---

## 5. Specs you need (just for THIS panel, LXC host separate)

### Panel VPS — recommended for 2500 concurrent users

| Component | Minimum | Comfortable (recommended) |
|-----------|---------|---------------------------|
| CPU       | 4 cores | **8 cores** (cluster mode = 1 worker/core) |
| RAM       | 8 GB    | **16 GB** (8×Next ~500MB + Postgres 4GB + Redis 1GB + headroom) |
| Disk      | 40 GB NVMe | **80 GB NVMe** (logs + DB growth) |
| Bandwidth | 1 TB/mo | **unmetered / 2 TB+** (2500 users × polling ≈ 5–8 Mbps sustained) |

> 4-core/8GB will hold for ~800–1200 concurrent users. For the full
> 2500, take 8 cores / 16 GB — the cluster uses every core and
> PostgreSQL wants ~4 GB `shared_buffers` headroom.

### LXC host VPS — depends on how many customer VPSes you sell

Sum the resources you sell, keep **~25% overhead**, and never oversell
RAM on containers:

| You sell (total)              | LXC host needed            |
|--------------------------------|----------------------------|
| 20 × (2vCPU/4GB/80GB)         | 8 cores / 96 GB / 1 TB NVMe |
| 50 × (2vCPU/4GB/80GB)         | 16 cores / 256 GB / 4 TB NVMe (or 2 hosts + 2 nodes in panel) |

Add more LXC hosts anytime — add each as another **Node** in the panel
and deployments spread across them.

### PostgreSQL quick tuning (16GB box)

```sql
-- /etc/postgresql/16/main/conf.d/deup.conf
shared_buffers = 4GB
effective_cache_size = 12GB
max_connections = 300
random_page_cost = 1.1      -- NVMe
```

---

## 6. Operations cheat-sheet

```bash
pm2 status                   # all processes
pm2 logs deup-panel --lines 100
pm2 reload deup-panel        # zero-downtime restart after deploy
pm2 scale deup-panel 8       # change worker count

# backup the database nightly
pg_dump -U deup deup | gzip > /backups/deup-$(date +%F).sql.gz
```

Super-admin login: **NØCTIS / nøctis@gmail.com / 123** — change the
password immediately after first login.
