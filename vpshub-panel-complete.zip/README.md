# VPSHUB Panel (DeUp-VPS)

A production-grade VPS management panel — Next.js 16 + Prisma + Tailwind,
with admin-controlled provisioning, customer dashboard, role-based access
control, support tickets, and real LXC container provisioning over SSH.

> **Hosting your panel? Read [`DEPLOY.md`](./DEPLOY.md) first** — it covers
> the full production setup (PostgreSQL, PM2 cluster mode, Caddy HTTPS,
> connecting an LXC host for real VPSes, and scaling to 2500+ users).

## Quick start (local development)

```bash
npm install
cp .env.example .env          # SQLite works out of the box (db/custom.db ships pre-seeded)
npm run db:generate           # generate the Prisma client
npm run dev                   # panel on http://localhost:3000
```

Login as super admin: **`nøctis@gmail.com`** (or username **`noctis`**) / **`123`**
— change the password immediately.

## Quick start (production)

```bash
npm install
cp .env.example .env          # set DATABASE_URL (PostgreSQL) + JWT_SECRET
npm run db:push:pg            # create the schema
npm run db:generate:pg        # generate the Postgres Prisma client
node prisma/seed.mjs          # super admin + plans + OS templates + IP pools + branding
npm run build
pm2 start ecosystem.config.js # panel :3000 (cluster) + realtime :3003
```

Then put Caddy/nginx in front (see `DEPLOY.md` and the included `Caddyfile`
example).

## What's inside

| Path | Purpose |
|------|---------|
| `src/app` | Next.js App Router pages + API routes |
| `src/components` | Admin / customer / shared UI |
| `src/lib` | Auth (JWT), RBAC permissions, providers (LXC, Proxmox), port forwarding, workers |
| `prisma/` | SQLite schema (`schema.prisma`), PostgreSQL schema (`schema.postgres.prisma`), seed (`seed.mjs`) |
| `mini-services/realtime` | socket.io service for live notifications & console |
| `scripts/` | Utilities — incl. `setup-lxc-host.sh` to bootstrap your LXC host |
| `ecosystem.config.js` | PM2 production process config (cluster mode) |
| `db/custom.db` | Pre-seeded SQLite database (development convenience) |

## Real VPS provisioning

The panel provisions customer VPSes as **LXC containers on a separate host**
over key-based SSH (`lxc-create`, `lxc-start`, `lxc-stop`, `lxc-destroy`,
iptables DNAT port-forwarding). Bootstrap that host with:

```bash
scp scripts/setup-lxc-host.sh root@<lxc-host-ip>:
ssh root@<lxc-host-ip> 'bash setup-lxc-host.sh'
```

Then register it in **Admin → Nodes → Add Node** (Provider: LXC,
API Endpoint: `root@<lxc-host-ip>`). Full details in `DEPLOY.md`.
