// Next.js instrumentation — runs once when the server process boots.
// Starts the background auto-suspend scheduler (VPS scheduled suspend dates).
export async function register() {
  if (process.env.NEXT_RUNTIME === 'nodejs') {
    const { startAutoSuspendScheduler } = await import('./lib/workers/auto-suspend');
    startAutoSuspendScheduler();
  }
}
