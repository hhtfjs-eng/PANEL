import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { cookies } from 'next/headers';
import { db } from '@/lib/db';
import { Permission, resolveRolePermissions } from '@/lib/permissions';

const SESSION_COOKIE = 'vps_session';
const JWT_SECRET = process.env.JWT_SECRET || 'vps-platform-secret-change-in-production-e18d72a4f3b1c9';
const SESSION_DURATION_DAYS = 7;

export interface SessionPayload {
  userId: string;
  role: string;
  email: string;
  username: string;
}

// ============================================================
// Password hashing (bcrypt with cost 12)
// ============================================================
export async function hashPassword(plain: string): Promise<string> {
  return bcrypt.hash(plain, 12);
}

export async function verifyPassword(plain: string, hash: string): Promise<boolean> {
  return bcrypt.compare(plain, hash);
}

// ============================================================
// JWT sessions
// ============================================================
export function signSessionToken(payload: SessionPayload): string {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: `${SESSION_DURATION_DAYS}d` });
}

export function verifySessionToken(token: string): SessionPayload | null {
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as SessionPayload;
    return decoded;
  } catch {
    return null;
  }
}

// ============================================================
// Cookie helpers (server-side)
// ============================================================
export async function setSessionCookie(payload: SessionPayload): Promise<void> {
  const token = signSessionToken(payload);
  const cookieStore = await cookies();
  cookieStore.set(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    maxAge: SESSION_DURATION_DAYS * 24 * 60 * 60,
  });
}

export async function clearSessionCookie(): Promise<void> {
  const cookieStore = await cookies();
  cookieStore.delete(SESSION_COOKIE);
}

export async function getSessionToken(): Promise<string | undefined> {
  const cookieStore = await cookies();
  return cookieStore.get(SESSION_COOKIE)?.value;
}

// ============================================================
// Current user resolver
// ============================================================
export async function getCurrentUser() {
  const token = await getSessionToken();
  if (!token) return null;
  const payload = verifySessionToken(token);
  if (!payload) return null;
  const user = await db.user.findUnique({
    where: { id: payload.userId },
    select: {
      id: true, email: true, username: true, name: true,
      role: true, status: true, emailVerified: true,
      lastLogin: true, lastActivity: true, createdAt: true,
    },
  });
  if (!user) return null;
  if (user.status !== 'ACTIVE') return null;
  return user;
}

export type AuthenticatedUser = NonNullable<Awaited<ReturnType<typeof getCurrentUser>>>;

// ============================================================
// Permission gate — throws / returns 403 if insufficient
// ============================================================
export interface AuthResult {
  ok: boolean;
  user?: AuthenticatedUser;
  error?: string;
  status?: number;
}

export async function requireAuth(): Promise<AuthResult> {
  const user = await getCurrentUser();
  if (!user) {
    return { ok: false, error: 'UNAUTHENTICATED', status: 401 };
  }
  return { ok: true, user };
}

export async function requirePermission(permission: Permission): Promise<AuthResult> {
  const auth = await requireAuth();
  if (!auth.ok) return auth;
  // Resolves built-in roles statically and custom roles (Role Editor) from the DB
  const perms = await resolveRolePermissions(auth.user!.role);
  if (!perms.includes(permission)) {
    return { ok: false, error: 'INSUFFICIENT_PERMISSIONS', status: 403, user: auth.user };
  }
  return auth;
}

// ============================================================
// Audit log helper
// ============================================================
export async function writeAudit(params: {
  actorId?: string;
  actorRole?: string;
  targetId?: string;
  action: string;
  success?: boolean;
  ipAddress?: string;
  userAgent?: string;
  metadata?: Record<string, unknown>;
}): Promise<void> {
  try {
    await db.auditLog.create({
      data: {
        actorId: params.actorId || null,
        actorRole: params.actorRole || null,
        targetId: params.targetId || null,
        action: params.action,
        success: params.success ?? true,
        ipAddress: params.ipAddress || null,
        userAgent: params.userAgent || null,
        metadata: params.metadata ? JSON.stringify(params.metadata) : null,
      },
    });
  } catch (err) {
    // Audit logging should never break the request flow
    console.error('Audit log write failed:', err);
  }
}

// ============================================================
// Helpers
// ============================================================
export function generateToken(length: number = 32): string {
  const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += chars[Math.floor(Math.random() * chars.length)];
  }
  return result;
}

export function generateRootPassword(length: number = 24): string {
  const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += chars[Math.floor(Math.random() * chars.length)];
  }
  return result;
}

// ============================================================
// SSH keypair generation (ED25519, OpenSSH wire format)
// ============================================================
import { generateKeyPairSync, createHash } from 'crypto';

export function generateSshKeyPair(comment: string = 'deup-vps'): {
  publicKey: string;   // single-line OpenSSH authorized_keys entry
  fingerprint: string; // SHA256:... (ssh-keygen -lf style)
} {
  const { publicKey } = generateKeyPairSync('ed25519');
  // SPKI DER for ed25519 = 12-byte header + 32-byte raw key
  const spki = publicKey.export({ type: 'spki', format: 'der' } as any) as Buffer;
  const raw = spki.subarray(spki.length - 32);

  // OpenSSH wire format: [len("ssh-ed25519")]["ssh-ed25519"][len(raw)][raw]
  const name = 'ssh-ed25519';
  const buf = Buffer.alloc(4 + name.length + 4 + raw.length);
  buf.writeUInt32BE(name.length, 0);
  buf.write(name, 4);
  buf.writeUInt32BE(raw.length, 4 + name.length);
  raw.copy(buf, 8 + name.length);

  const pubKeyLine = `ssh-ed25519 ${buf.toString('base64')} ${comment}`;
  const fp = createHash('sha256').update(buf).digest('base64').replace(/=+$/, '');
  return { publicKey: pubKeyLine, fingerprint: `SHA256:${fp}` };
}

export async function touchUserActivity(userId: string): Promise<void> {
  await db.user.update({
    where: { id: userId },
    data: { lastActivity: new Date() },
  }).catch(() => null);
}
