// ============================================================
// RBAC — Permission catalog
// ============================================================
// The system enforces server-side checks for EVERY permission.
// Customers cannot perform provisioning actions.

import { db } from '@/lib/db';

export type Permission =
  // User management
  | 'users.view' | 'users.edit' | 'users.suspend' | 'users.delete' | 'users.reset_password'
  // VPS — view + basic power (customers may have these)
  | 'vps.view' | 'vps.power' | 'vps.console' | 'vps.stats' | 'vps.network.view' | 'vps.activity.view'
  // VPS — provisioning (admin/staff only)
  | 'vps.create' | 'vps.deploy' | 'vps.reinstall' | 'vps.delete'
  | 'vps.suspend' | 'vps.unsuspend' | 'vps.resize' | 'vps.migrate' | 'vps.assign'
  | 'vps.delete.force'
  // Nodes
  | 'nodes.view' | 'nodes.create' | 'nodes.edit' | 'nodes.delete'
  // Plans
  | 'plans.view' | 'plans.create' | 'plans.edit' | 'plans.delete'
  // OS templates
  | 'os.view' | 'os.create' | 'os.edit' | 'os.delete'
  // Network / IPs
  | 'network.view' | 'network.manage' | 'ip.assign' | 'ip.release'
  // Deployments
  | 'deployments.view' | 'deployments.manage'
  // Settings
  | 'settings.view' | 'settings.edit'
  // Audit
  | 'audit.view' | 'audit.export'
  // Staff
  | 'staff.manage'
  // SSH/API keys (customers)
  | 'ssh_keys.manage' | 'api_keys.manage'
  // Support
  | 'support.view' | 'support.manage'
  // Notifications
  | 'notifications.view'
  // System health
  | 'system.health';

export type Role = 'USER' | 'SUPPORT' | 'STAFF' | 'ADMIN' | 'SUPER_ADMIN';

export const BUILTIN_ROLES: string[] = ['USER', 'SUPPORT', 'STAFF', 'ADMIN', 'SUPER_ADMIN'];

// Customer permissions — restricted set, NO provisioning
export const CUSTOMER_PERMISSIONS: Permission[] = [
  'vps.view', 'vps.power', 'vps.console', 'vps.stats',
  'vps.network.view', 'vps.activity.view',
  'ssh_keys.manage', 'api_keys.manage',
  'support.view',
  'notifications.view',
];

export const SUPPORT_PERMISSIONS: Permission[] = [
  ...CUSTOMER_PERMISSIONS,
  'users.view', 'users.edit',
  'support.view', 'support.manage',
  'vps.view', 'vps.suspend', 'vps.unsuspend',
  'audit.view',
  'system.health',
];

export const STAFF_PERMISSIONS: Permission[] = [
  ...SUPPORT_PERMISSIONS,
  'users.suspend',
  'vps.create', 'vps.deploy', 'vps.reinstall',
  'vps.resize', 'vps.migrate', 'vps.assign',
  'nodes.view', 'plans.view', 'os.view', 'network.view',
  'deployments.view', 'deployments.manage',
  'settings.view',
];

export const ADMIN_PERMISSIONS: Permission[] = [
  ...STAFF_PERMISSIONS,
  'users.delete', 'users.reset_password',
  'vps.delete', 'vps.delete.force',
  'nodes.create', 'nodes.edit', 'nodes.delete',
  'plans.create', 'plans.edit', 'plans.delete',
  'os.create', 'os.edit', 'os.delete',
  'network.manage', 'ip.assign', 'ip.release',
  'settings.edit',
  'audit.export',
  'staff.manage',
];

export const SUPER_ADMIN_PERMISSIONS: Permission[] = ADMIN_PERMISSIONS;

export function permissionsForRole(role: Role): Permission[] {
  switch (role) {
    case 'USER': return CUSTOMER_PERMISSIONS;
    case 'SUPPORT': return SUPPORT_PERMISSIONS;
    case 'STAFF': return STAFF_PERMISSIONS;
    case 'ADMIN': return ADMIN_PERMISSIONS;
    case 'SUPER_ADMIN': return SUPER_ADMIN_PERMISSIONS;
    default: return [];
  }
}

// ============================================================
// Custom roles (Role Editor) — resolved from the DB with a TTL cache
// ============================================================

const ROLE_CACHE_TTL_MS = 30_000;
let roleCache: { at: number; byKey: Map<string, Permission[]> } = { at: 0, byKey: new Map() };

/** All valid permission keys — used to validate Role Editor payloads. */
export const ALL_PERMISSIONS: Permission[] = [
  ...new Set<Permission>([
    ...CUSTOMER_PERMISSIONS, ...SUPPORT_PERMISSIONS, ...STAFF_PERMISSIONS,
    ...ADMIN_PERMISSIONS, 'users.delete', 'users.reset_password',
    'vps.delete', 'vps.delete.force', 'vps.deploy', 'vps.power', 'vps.console',
    'nodes.create', 'nodes.edit', 'nodes.delete',
    'plans.create', 'plans.edit', 'plans.delete',
    'os.create', 'os.edit', 'os.delete',
    'network.manage', 'ip.assign', 'ip.release',
    'settings.view', 'settings.edit',
    'audit.export', 'staff.manage',
    'deployments.view', 'deployments.manage',
    'system.health', 'notifications.view', 'support.view', 'support.manage',
    'ssh_keys.manage', 'api_keys.manage',
    'users.view', 'users.edit', 'users.suspend',
    'vps.view', 'vps.stats', 'vps.network.view', 'vps.activity.view',
    'vps.create', 'vps.reinstall', 'vps.suspend', 'vps.unsuspend',
    'vps.resize', 'vps.migrate', 'vps.assign',
    'nodes.view', 'plans.view', 'os.view', 'network.view',
  ]),
];

/** Invalidate the custom-role cache (call after role changes). */
export function invalidateRoleCache(): void {
  roleCache = { at: 0, byKey: new Map() };
}

async function loadCustomRoles(): Promise<Map<string, Permission[]>> {
  if (Date.now() - roleCache.at < ROLE_CACHE_TTL_MS) return roleCache.byKey;
  try {
    const roles = await db.role.findMany({ where: { isSystem: false } });
    const byKey = new Map<string, Permission[]>();
    for (const r of roles) {
      try {
        const parsed = JSON.parse(r.permissions);
        if (Array.isArray(parsed)) byKey.set(r.key, parsed.filter((p: any) => typeof p === 'string') as Permission[]);
      } catch { /* malformed JSON — treat as no permissions */ }
    }
    roleCache = { at: Date.now(), byKey };
  } catch {
    roleCache = { at: Date.now(), byKey: new Map() }; // DB unavailable — fail closed
  }
  return roleCache.byKey;
}

/**
 * Resolve the permission list for ANY role key — built-in roles use the static
 * catalogs; custom keys (created in the Role Editor) resolve from the DB.
 * Unknown keys resolve to [] (fail closed).
 */
export async function resolveRolePermissions(role: string | undefined | null): Promise<Permission[]> {
  if (!role) return [];
  if (BUILTIN_ROLES.includes(role)) return permissionsForRole(role as Role);
  const custom = await loadCustomRoles();
  return custom.get(role) || [];
}

// ============================================================
// Permission groups — powers the Role Editor matrix UI
// ============================================================
export const PERMISSION_GROUPS: { group: string; permissions: { key: Permission; label: string }[] }[] = [
  {
    group: 'Users',
    permissions: [
      { key: 'users.view', label: 'View users' },
      { key: 'users.edit', label: 'Edit users' },
      { key: 'users.suspend', label: 'Suspend users' },
      { key: 'users.delete', label: 'Delete users' },
      { key: 'users.reset_password', label: 'Reset passwords' },
      { key: 'staff.manage', label: 'Manage staff & roles' },
    ],
  },
  {
    group: 'VPS',
    permissions: [
      { key: 'vps.view', label: 'View VPS' },
      { key: 'vps.power', label: 'Power on/off' },
      { key: 'vps.console', label: 'Console access' },
      { key: 'vps.stats', label: 'View metrics' },
      { key: 'vps.network.view', label: 'View network' },
      { key: 'vps.activity.view', label: 'View activity' },
      { key: 'vps.create', label: 'Create VPS' },
      { key: 'vps.deploy', label: 'Deploy / redeploy' },
      { key: 'vps.reinstall', label: 'Reinstall OS' },
      { key: 'vps.delete', label: 'Delete VPS' },
      { key: 'vps.delete.force', label: 'Force delete' },
      { key: 'vps.suspend', label: 'Suspend VPS' },
      { key: 'vps.unsuspend', label: 'Unsuspend VPS' },
      { key: 'vps.resize', label: 'Resize VPS' },
      { key: 'vps.migrate', label: 'Migrate VPS' },
      { key: 'vps.assign', label: 'Assign / reassign owner' },
    ],
  },
  {
    group: 'Infrastructure',
    permissions: [
      { key: 'nodes.view', label: 'View nodes' },
      { key: 'nodes.create', label: 'Create nodes' },
      { key: 'nodes.edit', label: 'Edit nodes' },
      { key: 'nodes.delete', label: 'Delete nodes' },
      { key: 'plans.view', label: 'View plans' },
      { key: 'plans.create', label: 'Create plans' },
      { key: 'plans.edit', label: 'Edit plans' },
      { key: 'plans.delete', label: 'Delete plans' },
      { key: 'os.view', label: 'View OS templates' },
      { key: 'os.create', label: 'Create OS templates' },
      { key: 'os.edit', label: 'Edit OS templates' },
      { key: 'os.delete', label: 'Delete OS templates' },
      { key: 'network.view', label: 'View IPs' },
      { key: 'network.manage', label: 'Manage network' },
      { key: 'ip.assign', label: 'Assign IPs' },
      { key: 'ip.release', label: 'Release IPs' },
    ],
  },
  {
    group: 'Operations',
    permissions: [
      { key: 'deployments.view', label: 'View deployments' },
      { key: 'deployments.manage', label: 'Manage deployments' },
      { key: 'support.view', label: 'View tickets' },
      { key: 'support.manage', label: 'Manage tickets' },
      { key: 'audit.view', label: 'View audit log' },
      { key: 'audit.export', label: 'Export audit log' },
      { key: 'settings.view', label: 'View settings' },
      { key: 'settings.edit', label: 'Edit settings' },
      { key: 'system.health', label: 'System health' },
      { key: 'notifications.view', label: 'View notifications' },
    ],
  },
  {
    group: 'Customer features',
    permissions: [
      { key: 'ssh_keys.manage', label: 'Manage SSH keys' },
      { key: 'api_keys.manage', label: 'Manage API keys' },
    ],
  },
];

export function hasPermission(role: Role | undefined, permission: Permission): boolean {
  if (!role) return false;
  return permissionsForRole(role).includes(permission);
}

export function hasAnyPermission(role: Role | undefined, permissions: Permission[]): boolean {
  if (!role) return false;
  const rolePerms = permissionsForRole(role);
  return permissions.some(p => rolePerms.includes(p));
}

// Provisioning permissions — the critical "admin-only" set
export const PROVISIONING_PERMISSIONS: Permission[] = [
  'vps.create', 'vps.deploy', 'vps.reinstall', 'vps.delete',
  'vps.suspend', 'vps.unsuspend', 'vps.resize', 'vps.migrate', 'vps.assign',
  'nodes.create', 'nodes.edit', 'nodes.delete',
  'plans.create', 'plans.edit', 'plans.delete',
  'os.create', 'os.edit', 'os.delete',
  'network.manage', 'ip.assign', 'ip.release',
  'deployments.manage',
];

export function canProvision(role: Role | undefined): boolean {
  return hasAnyPermission(role, PROVISIONING_PERMISSIONS);
}
