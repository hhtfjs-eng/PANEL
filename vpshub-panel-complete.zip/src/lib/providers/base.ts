// ============================================================
// Infrastructure Provider Abstraction
// ============================================================
// All provider operations are performed on the SERVER side.
// Browser NEVER receives provider credentials.
// ============================================================

export interface ProviderVpsConfig {
  name: string;
  hostname: string;
  cpu: number;
  ramMb: number;
  diskGb: number;
  bandwidthMbps: number;
  osTemplateId?: string;
  ipv4?: string;
  ipv6?: string;
  gateway?: string;
  dnsPrimary?: string;
  dnsSecondary?: string;
  rootPasswordHash?: string;
  sshKeyFingerprint?: string;
  autoStart?: boolean;
}

export interface ProviderStats {
  cpuUsage: number;   // 0-100
  ramUsage: number;   // 0-100
  diskUsage: number;  // 0-100
  netInKbps: number;
  netOutKbps: number;
  uptimeSeconds: number;
}

export interface ProviderConsoleData {
  // token used to authorize a WebSocket console session
  consoleToken: string;
  // provider-side session ID (opaque to client)
  sessionId: string;
}

export interface ProviderVpsRecord {
  providerResourceId: string;
  state: string;
}

export interface ProviderPortForward {
  protocol: 'tcp' | 'udp';
  externalPort: number; // public port on the node's public IP
  internalPort: number; // port inside the VPS/container
  containerIp?: string;  // container/VPS private IP (NAT target)
}

export interface IInfrastructureProvider {
  readonly type: string;
  createVPS(config: ProviderVpsConfig): Promise<ProviderVpsRecord>;
  deleteVPS(providerResourceId: string): Promise<void>;
  startVPS(providerResourceId: string): Promise<void>;
  stopVPS(providerResourceId: string): Promise<void>;
  restartVPS(providerResourceId: string): Promise<void>;
  shutdownVPS(providerResourceId: string): Promise<void>;
  forceStopVPS(providerResourceId: string): Promise<void>;
  reinstallVPS(providerResourceId: string, osTemplateId: string): Promise<void>;
  resizeVPS(providerResourceId: string, cpu: number, ramMb: number, diskGb: number): Promise<void>;
  migrateVPS(providerResourceId: string, destinationNodeEndpoint: string): Promise<void>;
  getStatus(providerResourceId: string): Promise<string>;
  getStats(providerResourceId: string): Promise<ProviderStats>;
  getConsole(providerResourceId: string): Promise<ProviderConsoleData>;
  configureNetwork(providerResourceId: string, config: Partial<ProviderVpsConfig>): Promise<void>;
  // Port forwarding — NAT external port on the node → VPS internal port
  addPortForward(providerResourceId: string, rule: ProviderPortForward): Promise<void>;
  removePortForward(providerResourceId: string, rule: ProviderPortForward): Promise<void>;
}
