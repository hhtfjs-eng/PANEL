// ============================================================
// ProxmoxProvider — Simulated Provider
// ============================================================
// In production, this would call the real Proxmox API using
// credentials stored only on the server (env vars / vault).
//
// In the sandbox, we simulate the operations with realistic
// latencies and behavior. The interface is identical so the
// deployment pipeline can be swapped to a real provider.
// ============================================================

import { IInfrastructureProvider, ProviderVpsConfig, ProviderVpsRecord, ProviderStats, ProviderConsoleData, ProviderPortForward } from './base';
import { generateToken } from '@/lib/auth';
import { getLxcProvider } from './lxc';

const SIM_LATENCY_MS = 600;

function sleep(ms: number): Promise<void> {
  return new Promise(r => setTimeout(r, ms));
}

export class ProxmoxProvider implements IInfrastructureProvider {
  readonly type = 'PROXMOX';

  async createVPS(config: ProviderVpsConfig): Promise<ProviderVpsRecord> {
    // Simulate Proxmox API: POST /nodes/{node}/qemu
    await sleep(SIM_LATENCY_MS + Math.random() * 400);
    const id = `qemu-${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
    return { providerResourceId: id, state: config.autoStart ? 'running' : 'stopped' };
  }

  async deleteVPS(id: string): Promise<void> {
    await sleep(SIM_LATENCY_MS);
    if (!id) throw new Error('providerResourceId required');
  }

  async startVPS(id: string): Promise<void> {
    await sleep(SIM_LATENCY_MS);
  }

  async stopVPS(id: string): Promise<void> {
    await sleep(SIM_LATENCY_MS);
  }

  async restartVPS(id: string): Promise<void> {
    await sleep(SIM_LATENCY_MS + 200);
  }

  async shutdownVPS(id: string): Promise<void> {
    await sleep(SIM_LATENCY_MS);
  }

  async forceStopVPS(id: string): Promise<void> {
    await sleep(300);
  }

  async reinstallVPS(id: string, osTemplateId: string): Promise<void> {
    await sleep(1200);
  }

  async resizeVPS(id: string, cpu: number, ramMb: number, diskGb: number): Promise<void> {
    await sleep(800);
  }

  async migrateVPS(id: string, dest: string): Promise<void> {
    await sleep(1800);
  }

  async getStatus(id: string): Promise<string> {
    await sleep(80);
    // Use deterministic-ish state from id hash so status is stable
    const hash = id.split('').reduce((a, c) => a + c.charCodeAt(0), 0);
    return hash % 5 === 0 ? 'stopped' : 'running';
  }

  async getStats(id: string): Promise<ProviderStats> {
    await sleep(60);
    const seed = id.split('').reduce((a, c) => a + c.charCodeAt(0), 0);
    const t = Date.now() / 1000;
    return {
      cpuUsage: Math.min(95, Math.max(3, 15 + 20 * Math.sin(t / 3 + seed) + Math.random() * 10)),
      ramUsage: Math.min(92, Math.max(10, 35 + 15 * Math.sin(t / 5 + seed) + Math.random() * 8)),
      diskUsage: Math.min(85, Math.max(15, 40 + (seed % 30) + Math.random() * 5)),
      netInKbps: Math.max(100, 500 + 300 * Math.sin(t / 2) + Math.random() * 200),
      netOutKbps: Math.max(50, 250 + 200 * Math.cos(t / 2) + Math.random() * 150),
      uptimeSeconds: 86400 + (seed % 300000),
    };
  }

  async getConsole(id: string): Promise<ProviderConsoleData> {
    await sleep(80);
    // The browser gets a one-time token; hypervisor credentials stay server-side.
    return {
      consoleToken: generateToken(48),
      sessionId: `vnc-${id}-${Date.now().toString(36)}`,
    };
  }

  async configureNetwork(id: string, config: Partial<ProviderVpsConfig>): Promise<void> {
    await sleep(400);
  }

  // Port forwarding — stub/simulation mode. The database stays the
  // source of truth; a real Proxmox integration would create firewall
  // NAT rules via the Proxmox API here.
  async addPortForward(_id: string, _rule: ProviderPortForward): Promise<void> {
    await sleep(250);
  }

  async removePortForward(_id: string, _rule: ProviderPortForward): Promise<void> {
    await sleep(200);
  }
}

// Singleton
let _instance: ProxmoxProvider | null = null;
export function getProxmoxProvider(): ProxmoxProvider {
  if (!_instance) _instance = new ProxmoxProvider();
  return _instance;
}

// Registry — look up by provider type. For LXC nodes, the node's
// apiEndpoint ("user@host[:port]") selects the real SSH-connected
// provider; without an endpoint the simulated provider is used.
export function getProvider(
  type: string,
  node?: { apiEndpoint?: string | null } | null,
): IInfrastructureProvider {
  switch (type) {
    case 'LXC':
      return getLxcProvider(node?.apiEndpoint ?? null);
    case 'PROXMOX':
    case 'VMWARE':
    case 'HYPERV':
    case 'LIBVIRT':
    case 'CLOUD':
    case 'CUSTOM':
    default:
      return getProxmoxProvider();
  }
}
