// ============================================================
// LxcProvider — real LXC container provisioning over SSH
// ============================================================
// Connects to a dedicated LXC host (the owner runs a separate VPS for
// LXC containers) and manages containers with the lxc-* CLI tools:
//
//   lxc-create / lxc-start / lxc-stop / lxc-destroy / lxc-info
//
// Connection:
//   - Per-node:  Node.apiEndpoint = "user@host" or "user@host:port"
//                (set it in Admin → Nodes when the provider is LXC)
//   - Fallback:  LXC_SSH_HOST / LXC_SSH_USER / LXC_SSH_PORT env vars
//
// SSH must be key-based (BatchMode) — the panel host's key is
// authorized on the LXC host (see scripts/setup-lxc-host.sh which
// installs LXC, the bridge, and prints the exact authorized_keys line).
//
// When no endpoint is configured the provider runs in SIMULATION mode
// with realistic latencies so the panel stays fully functional in
// development / demos — identical behavior to the Proxmox stub.
// ============================================================

import { execFile } from 'child_process';
import { promisify } from 'util';
import { IInfrastructureProvider, ProviderVpsConfig, ProviderVpsRecord, ProviderStats, ProviderConsoleData, ProviderPortForward } from './base';
import { generateToken } from '@/lib/auth';

const execFileAsync = promisify(execFile);
const SIM_LATENCY_MS = 600;

function sleep(ms: number): Promise<void> {
  return new Promise(r => setTimeout(r, ms));
}

/** Parse "user@host", "user@host:port", or "host" into SSH target parts. */
export function parseLxcEndpoint(endpoint?: string | null): { user: string; host: string; port: string } | null {
  const raw = (endpoint?.trim() || process.env.LXC_SSH_HOST || '').trim();
  if (!raw) return null;
  let user = process.env.LXC_SSH_USER || 'root';
  let host = raw;
  let port = process.env.LXC_SSH_PORT || '22';
  if (raw.includes('@')) {
    const [u, ...rest] = raw.split('@');
    user = u;
    host = rest.join('@');
  }
  if (host.includes(':')) {
    const [h, p] = host.split(':');
    host = h;
    if (p && /^\d+$/.test(p)) port = p;
  }
  if (!host) return null;
  return { user, host, port };
}

/** Sanitize a container name: [a-zA-Z0-9-_] only. */
function ctName(base: string): string {
  const clean = base.replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 60);
  return clean || `ct-${Date.now().toString(36)}`;
}

export class LxcProvider implements IInfrastructureProvider {
  readonly type = 'LXC';
  private endpoint: { user: string; host: string; port: string } | null;

  constructor(endpoint?: string | null) {
    this.endpoint = parseLxcEndpoint(endpoint);
  }

  /** Real mode? */
  get live(): boolean {
    return this.endpoint !== null;
  }

  /** Run a command on the LXC host over key-based SSH. */
  private async ssh(cmd: string, args: string[]): Promise<string> {
    const ep = this.endpoint!;
    const { stdout } = await execFileAsync('ssh', [
      '-o', 'BatchMode=yes',
      '-o', 'StrictHostKeyChecking=accept-new',
      '-o', 'ConnectTimeout=10',
      '-p', ep.port,
      `${ep.user}@${ep.host}`,
      cmd, ...args,
    ], { timeout: 120_000, maxBuffer: 4 * 1024 * 1024 });
    return stdout.toString();
  }

  async createVPS(config: ProviderVpsConfig): Promise<ProviderVpsRecord> {
    const name = ctName(config.hostname || config.name);
    const template = config.osTemplateId || 'ubuntu:22.04';

    if (!this.live) {
      await sleep(SIM_LATENCY_MS + Math.random() * 400);
      return { providerResourceId: name, state: config.autoStart ? 'running' : 'stopped' };
    }

    // 1) Create the container from a download template (e.g. "ubuntu:22.04")
    await this.ssh('lxc-create', [
      '-t', 'download', '-n', name, '--',
      '-d', template.split(':')[0] || 'ubuntu',
      '-r', template.split(':')[1] || '22.04',
      '-a', 'amd64',
    ]).catch(async err => {
      // Template may not be cached — retry with distro builder fallback
      const msg = String(err?.message || err);
      if (msg.includes('No such file') || msg.includes('not found')) {
        await this.ssh('lxc-create', ['-t', 'download', '-n', name, '--', '-d', 'ubuntu', '-r', '22.04', '-a', 'amd64']);
        return;
      }
      throw err;
    });

    // 2) Apply resource limits (LXC 3+/4 unified cgroup syntax)
    const ramMb = String(config.ramMb) + 'MiB';
    await this.ssh('lxc config set', [
      name, 'limits.memory', ramMb,
    ]).catch(() => undefined); // older LXC uses lxc.cgroup lines — ignore failure
    if (config.cpu > 0) {
      await this.ssh('lxc config set', [name, 'limits.cpu', String(config.cpu)]).catch(() => undefined);
    }

    // 3) Start if autoStart
    if (config.autoStart) {
      await this.ssh('lxc-start', ['-n', name]).catch(() => undefined);
    }

    return { providerResourceId: name, state: config.autoStart ? 'running' : 'stopped' };
  }

  async deleteVPS(id: string): Promise<void> {
    if (!this.live) { await sleep(SIM_LATENCY_MS); return; }
    await this.ssh('lxc-stop', ['-n', id]).catch(() => undefined);
    await this.ssh('lxc-destroy', ['-n', id, '-f']);
  }

  async startVPS(id: string): Promise<void> {
    if (!this.live) { await sleep(SIM_LATENCY_MS); return; }
    await this.ssh('lxc-start', ['-n', id]);
  }

  async stopVPS(id: string): Promise<void> {
    if (!this.live) { await sleep(SIM_LATENCY_MS); return; }
    await this.ssh('lxc-stop', ['-n', id]);
  }

  async restartVPS(id: string): Promise<void> {
    if (!this.live) { await sleep(SIM_LATENCY_MS + 200); return; }
    await this.ssh('lxc-stop', ['-n', id]).catch(() => undefined);
    await this.ssh('lxc-start', ['-n', id]);
  }

  async shutdownVPS(id: string): Promise<void> {
    if (!this.live) { await sleep(SIM_LATENCY_MS); return; }
    await this.ssh('lxc-stop', ['-n', id]);
  }

  async forceStopVPS(id: string): Promise<void> {
    if (!this.live) { await sleep(300); return; }
    await this.ssh('lxc-stop', ['-n', id, '-f']);
  }

  async reinstallVPS(id: string, osTemplateId: string): Promise<void> {
    if (!this.live) { await sleep(1200); return; }
    // Destroy + recreate with the requested template, keeping the name
    await this.ssh('lxc-stop', ['-n', id]).catch(() => undefined);
    await this.ssh('lxc-destroy', ['-n', id, '-f']);
    const template = osTemplateId || 'ubuntu:22.04';
    await this.ssh('lxc-create', [
      '-t', 'download', '-n', id, '--',
      '-d', template.split(':')[0] || 'ubuntu',
      '-r', template.split(':')[1] || '22.04',
      '-a', 'amd64',
    ]);
    await this.ssh('lxc-start', ['-n', id]);
  }

  async resizeVPS(id: string, cpu: number, ramMb: number, diskGb: number): Promise<void> {
    if (!this.live) { await sleep(800); return; }
    await this.ssh('lxc config set', [id, 'limits.memory', `${ramMb}MiB`]).catch(() => undefined);
    await this.ssh('lxc config set', [id, 'limits.cpu', String(cpu)]).catch(() => undefined);
    // Disk growth needs LVM/ZFS pool support — apply quota where available
    await this.ssh('lxc config set', [id, 'size', `${diskGb}GB`]).catch(() => undefined);
  }

  async migrateVPS(id: string, dest: string): Promise<void> {
    if (!this.live) { await sleep(1800); return; }
    // Simple migration: rsync rootfs to destination host's LXC path
    const src = this.endpoint!;
    await execFileAsync('bash', ['-c',
      `ssh -o BatchMode=yes -o StrictHostKeyChecking=accept-new -p ${src.port} ${src.user}@${src.host} "lxc-stop -n ${id} 2>/dev/null; tar -C /var/lib/lxc/${id} -cf - ." | ssh -o BatchMode=yes -o StrictHostKeyChecking=accept-new ${dest} "mkdir -p /var/lib/lxc/${id} && tar -C /var/lib/lxc/${id} -xf - && lxc-start -n ${id}"`,
    ], { timeout: 300_000 });
  }

  async getStatus(id: string): Promise<string> {
    if (!this.live) {
      await sleep(80);
      const hash = id.split('').reduce((a, c) => a + c.charCodeAt(0), 0);
      return hash % 5 === 0 ? 'stopped' : 'running';
    }
    const out = await this.ssh('lxc-info', ['-n', id, '-sH']).catch(() => '');
    // lxc-info -sH prints e.g. "RUNNING" / "STOPPED"
    return out.trim().toLowerCase() || 'unknown';
  }

  async getStats(id: string): Promise<ProviderStats> {
    if (!this.live) {
      await sleep(60);
      const seed = id.split('').reduce((a, c) => a + c.charCodeAt(0), 0);
      const t = Date.now() / 1000;
      return {
        cpuUsage: Math.min(95, Math.max(3, 15 + 20 * Math.sin(t / 3 + seed) + Math.random() * 10)),
        ramUsage: Math.min(92, Math.max(10, 35 + 15 * Math.sin(t / 5 + seed) + Math.random() * 8)),
        diskUsage: Math.min(85, Math.max(15, 40 + (seed % 30) + Math.random() * 5)),
        netInKbps: Math.max(100, 500 + 300 * Math.sin(t / 2) + Math.random() * 200),
        netOutKbps: Math.max(50, 250 + 200 * Math.cos(t / 2) + Math.random() * 150),
        uptimeSeconds: 86400 + (seed % 300000),
      };
    }
    const out = await this.ssh('lxc-info', ['-n', id]).catch(() => '');
    const num = (label: string): number => {
      const m = out.match(new RegExp(`${label}:\\s+([\\d.]+\\s*\\w*)`, 'i'));
      if (!m) return 0;
      const v = parseFloat(m[1]);
      const unit = (m[1].match(/(GiB|MiB|kB|GB|MB)/) || [])[0] || '';
      if (unit === 'GiB' || unit === 'GB') return v * 1024;
      return v;
    };
    return {
      cpuUsage: Math.min(100, out.match(/CPU use/) ? num('CPU use') / 100 : 10),
      ramUsage: Math.min(100, (num('Memory use') / 1024) * 100),
      diskUsage: Math.min(100, (num('Disk use') / 1024) * 100),
      netInKbps: 0,
      netOutKbps: 0,
      uptimeSeconds: 0,
    };
  }

  async getConsole(id: string): Promise<ProviderConsoleData> {
    // The browser gets a one-time token; the LXC host credentials stay
    // server-side. A real `lxc console` bridge can attach via the
    // realtime websocket service using this token (see DEPLOY.md).
    return {
      consoleToken: generateToken(48),
      sessionId: `lxc-${id}-${Date.now().toString(36)}`,
    };
  }

  async configureNetwork(id: string, config: Partial<ProviderVpsConfig>): Promise<void> {
    if (!this.live) { await sleep(400); return; }
    // Write a static IP into the container's netcfg (LXC template style)
    if (config.ipv4 && config.gateway) {
      const netcfg =
        `lxc.net.0.type = veth\n` +
        `lxc.net.0.link = br0\n` +
        `lxc.net.0.flags = up\n` +
        `lxc.net.0.ipv4.address = ${config.ipv4}\n` +
        `lxc.net.0.ipv4.gateway = ${config.gateway}\n`;
      await this.ssh('bash', ['-c', `cat > /var/lib/lxc/${id}/config.d/network << 'EOF'\n${netcfg}\nEOF\nlxc-attach -n ${id} -- ip addr add ${config.ipv4} dev eth0 2>/dev/null || true`]);
    }
  }

  // ------------------------------------------------------------
  // Port forwarding — iptables DNAT on the LXC host:
  //   node_public_ip:externalPort  →  container_ip:internalPort
  // Rules carry a --comment marker (deup-pf-<proto>-<ext>) so they can
  // be removed reliably even if the rule spec drifts.
  // ------------------------------------------------------------

  /** Resolve the container's current IP on br0 (falls back to provided hint). */
  private async containerIp(id: string, hint?: string): Promise<string> {
    if (hint) return hint;
    const out = await this.ssh('bash', ['-c',
      `lxc-info -n ${id} -iH 2>/dev/null | head -1`]).catch(() => '');
    return out.trim().split(/\s+/).pop() || '';
  }

  private pfSpec(rule: ProviderPortForward, ip: string): string {
    return `-m comment --comment deup-pf-${rule.protocol}-${rule.externalPort} -p ${rule.protocol} --dport ${rule.externalPort} -j DNAT --to-destination ${ip}:${rule.internalPort}`;
  }

  async addPortForward(id: string, rule: ProviderPortForward): Promise<void> {
    if (!this.live) { await sleep(300); return; } // simulation — DB is the source of truth
    const ip = await this.containerIp(id, rule.containerIp);
    if (!ip) throw new Error('CONTAINER_IP_NOT_FOUND');
    const spec = this.pfSpec(rule, ip);
    await this.ssh('bash', ['-c',
      `iptables -t nat -C PREROUTING -i br0 ${spec} 2>/dev/null || iptables -t nat -A PREROUTING -i br0 ${spec}; ` +
      `iptables -C FORWARD -m comment --comment deup-pf-${rule.protocol}-${rule.externalPort} -p ${rule.protocol} -d ${ip} --dport ${rule.internalPort} -j ACCEPT 2>/dev/null || ` +
      `iptables -A FORWARD -m comment --comment deup-pf-${rule.protocol}-${rule.externalPort} -p ${rule.protocol} -d ${ip} --dport ${rule.internalPort} -j ACCEPT`,
    ]);
  }

  async removePortForward(id: string, rule: ProviderPortForward): Promise<void> {
    if (!this.live) { await sleep(200); return; }
    const ip = await this.containerIp(id, rule.containerIp);
    const marker = `deup-pf-${rule.protocol}-${rule.externalPort}`;
    // Delete every rule carrying this marker (nat + filter), tolerating absence
    await this.ssh('bash', ['-c',
      `while iptables -t nat -S PREROUTING 2>/dev/null | grep -q '${marker}'; do ` +
      `iptables -t nat -D PREROUTING -m comment --comment ${marker} -p ${rule.protocol} --dport ${rule.externalPort} -j DNAT --to-destination ${ip}:${rule.internalPort} 2>/dev/null || break; done; ` +
      `while iptables -S FORWARD 2>/dev/null | grep -q '${marker}'; do ` +
      `iptables -D FORWARD -m comment --comment ${marker} -p ${rule.protocol} -d ${ip} --dport ${rule.internalPort} -j ACCEPT 2>/dev/null || break; done`,
    ]).catch(() => undefined);
  }
}

// Singleton cache keyed by endpoint so per-node providers are reused
const _instances = new Map<string, LxcProvider>();

export function getLxcProvider(endpoint?: string | null): LxcProvider {
  const key = endpoint?.trim() || process.env.LXC_SSH_HOST || '__sim__';
  let inst = _instances.get(key);
  if (!inst) {
    inst = new LxcProvider(endpoint);
    _instances.set(key, inst);
  }
  return inst;
}
