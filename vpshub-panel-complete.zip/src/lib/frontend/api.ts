// Frontend API client — typed fetch wrapper with auth handling
//
// Resilience rules (why you should never see NON_JSON_RESPONSE again):
//  1. JSON is parsed leniently — the Content-Type header is ignored; if the
//     body parses as JSON, it is used.
//  2. Transient failures retry automatically with backoff:
//     network errors, HTML/proxy error pages, and 5xx/429 responses.
//     GETs retry up to 5 extra times (~17s window). Mutations retry once —
//     UNLESS the failure proves the request never reached the app (network
//     error, proxy 502/503/504), in which case they get the full ~17s ladder
//     too, so a deploy POST survives a dev-server recompile/restart.
//  3. An empty 2xx body counts as success.
//  4. A 401 UNAUTHENTICATED while logged in triggers ONE global logout with a
//     friendly toast — no error spam from parallel pollers.

export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
  details?: any;
  pagination?: { page: number; pageSize: number; total: number; totalPages: number };
}

const RETRYABLE_STATUS = new Set([408, 425, 429, 500, 502, 503, 504]);
// Statuses that prove the request never reached the app (proxy-level failures
// while the dev server restarts/recompiles). Safe to retry mutations fully —
// the request was never executed.
const PROXY_FAILURE_STATUS = new Set([502, 503, 504]);
// Extended ladder: dev-server cold compiles can take 10s+. Proven non-delivery
// failures now retry for up to ~46s (covers a full recompile cycle); unknown
// delivery mutations keep 2 attempts as defense in depth.
const RETRY_DELAYS = [600, 1200, 2400, 4800, 8000, 12000, 16000];

function sleep(ms: number): Promise<void> {
  return new Promise(r => setTimeout(r, ms));
}

// ------------------------------------------------------------
// Global session-expiry handling (deduped — one toast, one logout)
// ------------------------------------------------------------
let sessionExpiryHandledAt = 0;

// Broadcast auth events so other tabs stay in sync
function broadcastAuthEvent(type: 'login' | 'logout'): void {
  try {
    localStorage.setItem('vps_auth_event', JSON.stringify({ type, at: Date.now() }));
  } catch { /* private mode / SSR — ignore */ }
}

async function handleSessionExpired(): Promise<void> {
  const now = Date.now();
  if (now - sessionExpiryHandledAt < 3000) return; // dedupe parallel 401s
  sessionExpiryHandledAt = now;
  try {
    // Dynamic import avoids the api <-> store circular dependency at load time
    const { useAppStore } = await import('./store');
    const state = useAppStore.getState();
    if (!state.user) return; // not logged in — normal init/login flow

    // RACE FIX: this 401 may be stale — fired before a fresh login completed.
    // Re-verify with a raw, uncached call. If the session is actually valid,
    // the 401 came from an old in-flight request and must NOT log the user out.
    const check = await fetch('/api/auth/me', { credentials: 'include', cache: 'no-store' });
    if (check.ok) {
      const body = await check.json().catch(() => null);
      if (body?.user) {
        sessionExpiryHandledAt = 0; // stale 401 — don't consume the dedupe window
        return; // valid session — stale 401, ignore it
      }
    }

    useAppStore.setState({ user: null, view: 'dashboard', viewParams: null, loading: false });
    broadcastAuthEvent('logout');
    const { toast } = await import('sonner');
    toast.error('Your session has expired — please sign in again.');
  } catch {
    sessionExpiryHandledAt = 0; // verification itself failed — allow a retry later
    // never let session handling break a request
  }
}

async function request<T = any>(
  url: string,
  options: RequestInit = {},
): Promise<ApiResponse<T>> {
  const method = (options.method || 'GET').toUpperCase();
  const isMutation = method !== 'GET' && method !== 'HEAD';

  let lastError: ApiResponse<T> = { success: false, error: 'NETWORK_ERROR', message: 'Request failed' };
  // Set when a failure PROVES the request never reached the app (network
  // error, or proxy 502/503/504 HTML page served while the dev server
  // restarts/recompiles). Once proven, even mutations get the full retry
  // ladder — a retry cannot double-execute something that never ran.
  let provenNonDelivery = false;

  const maxAttempts = () => (!isMutation || provenNonDelivery) ? 8 : 2;

  for (let attempt = 0; ; attempt++) {
    const cap = maxAttempts();
    if (attempt >= cap) break;
    if (attempt > 0) await sleep(RETRY_DELAYS[Math.min(attempt - 1, RETRY_DELAYS.length - 1)]);
    try {
      const res = await fetch(url, {
        ...options,
        headers: {
          'Content-Type': 'application/json',
          ...(options.headers || {}),
        },
        credentials: 'include',
        cache: 'no-store', // never let the browser HTTP cache serve stale API responses
      });

      const text = await res.text();
      let data: any = null;
      if (text) {
        try { data = JSON.parse(text); } catch { /* HTML / empty / text body */ }
      }

      // Parsed a JSON object — normal application response
      if (data && typeof data === 'object' && !Array.isArray(data)) {
        if (res.status === 401 && data?.error === 'UNAUTHENTICATED') {
          await handleSessionExpired();
        }
        if (!res.ok && data.success !== true) {
          lastError = {
            success: false,
            error: data.error || 'HTTP_ERROR',
            message: data.message,
            details: data.details,
          };
          // 5xx JSON from the app itself: safe to retry for GETs only,
          // UNLESS the request is idempotent (carries idempotencyKey) —
          // in which case mutations are also safe to retry, because the
          // server dedupes on idempotencyKey. This covers the deploy POST
          // returning a 500 INTERNAL_ERROR and being retried cleanly.
          if (RETRYABLE_STATUS.has(res.status) && attempt < cap - 1) {
            const bodyStr = typeof options.body === 'string' ? options.body : '';
            const hasIdemKey = bodyStr.includes('"idempotencyKey"');
            if (!isMutation || hasIdemKey) continue;
          }
          return lastError;
        }
        return data as ApiResponse<T>;
      }
      // Arrays / primitives are not valid API envelopes — treat as non-JSON.

      // Empty successful response (204 etc.)
      if (res.ok) return { success: true } as ApiResponse<T>;

      // Non-JSON error body: proxy 502 page, dev-server restart, compile page…
      // The request almost certainly never reached the app — safe to retry.
      // Also flag HTML 500 from mutations that carry an idempotencyKey as
      // safe-to-retry: a 500 may mean the request threw AFTER side-effects
      // started, but if the request is idempotent the server dedupes on
      // idempotencyKey, so a retry returns the same response safely.
      if (PROXY_FAILURE_STATUS.has(res.status)) provenNonDelivery = true;
      else if (isMutation && res.status === 500) {
        const bodyStr = typeof options.body === 'string' ? options.body : '';
        if (bodyStr.includes('"idempotencyKey"')) provenNonDelivery = true;
      }
      lastError = {
        success: false,
        error: 'SERVICE_UNAVAILABLE',
        message: `Server returned HTTP ${res.status} while ${method} ${url}`,
      };
      if (attempt < cap - 1) continue;
      return lastError;
    } catch (err: any) {
      // Network-level failure: server down, connection refused/reset, offline
      provenNonDelivery = true;
      lastError = {
        success: false,
        error: 'NETWORK_ERROR',
        message: err?.message || 'Network request failed',
      };
      if (attempt < cap - 1) continue;
      return lastError;
    }
  }
  return lastError;
}

// ------------------------------------------------------------
// Human-friendly error text — never show raw error codes to users
// ------------------------------------------------------------
const ERROR_TEXT: Record<string, string> = {
  NETWORK_ERROR: 'Cannot reach the server — check your connection and try again.',
  SERVICE_UNAVAILABLE: 'The server is briefly unavailable (restarting or busy) — your action was retried automatically. Please try again in a moment.',
  NON_JSON_RESPONSE: 'The server returned an unexpected response — please retry.',
  HTTP_ERROR: 'The request failed — please try again.',
  VALIDATION_ERROR: 'Please check the values you entered.',
  UNAUTHENTICATED: 'Please sign in to continue.',
  INSUFFICIENT_PERMISSIONS: 'You do not have permission to do that.',
  ALREADY_SEEDED: 'Demo data is already initialized.',
  INTERNAL_ERROR: 'Something went wrong on the server — please try again.',
  OWNER_NOT_FOUND: 'The selected customer no longer exists.',
  OWNER_NOT_ACTIVE: 'That customer account is not active.',
  NODE_NOT_FOUND: 'Node not found.',
  NODE_DISABLED: 'That node is disabled.',
  NODE_MAINTENANCE: 'That node is in maintenance mode.',
  NODE_OFFLINE: 'That node is offline.',
  NODE_CPU_FULL: 'Not enough CPU capacity left on that node.',
  NODE_RAM_FULL: 'Not enough RAM capacity left on that node.',
  NODE_STORAGE_FULL: 'Not enough storage capacity left on that node.',
  NODE_HAS_VPS: 'That node still has VPS assigned and cannot be deleted.',
  OS_NOT_FOUND: 'OS template not found.',
  OS_UNAVAILABLE: 'That OS template is unavailable.',
  IP_EXHAUSTED: 'No free IP addresses are available.',
  TICKET_CLOSED: 'This ticket is closed and cannot be replied to.',
  NOT_FOUND: 'Not found — it may have been deleted.',
  VPS_SUSPENDED: 'This VPS is suspended.',
  CURRENT_PASSWORD_REQUIRED: 'Enter your current password to set a new one.',
  CURRENT_PASSWORD_WRONG: 'Your current password is incorrect.',
  USERNAME_TAKEN: 'This username is taken.',
  EMAIL_TAKEN: 'An account with this email already exists.',
  EMAIL_OR_USERNAME_TAKEN: 'That email or username is already in use.',
  EMAIL_INVALID: 'Enter a valid email address.',
  USERNAME_INVALID: 'Username must be 3-30 characters — letters, numbers and underscores only.',
  PASSWORD_TOO_SHORT: 'Password must be at least 8 characters long.',
  INVALID_ROLE: 'That role does not exist.',
  CANNOT_CHANGE_OWN_ROLE: 'You cannot change your own role — ask another Super Admin.',
  ROLE_CHANGE_FORBIDDEN: 'Only a Super Admin can assign or remove Super Admin roles.',
  ROLE_IS_SYSTEM: 'Built-in roles cannot be modified or deleted.',
  VPS_ALREADY_DEPLOYING: 'This VPS is already deploying.',
};

export function friendlyMessage(r: { error?: string; message?: string } | null | undefined): string {
  if (!r) return 'Something went wrong.';
  const code = r.error || 'HTTP_ERROR';
  return ERROR_TEXT[code] || r.message || code.replace(/_/g, ' ').toLowerCase();
}

export const api = {
  get: <T = any>(url: string) => request<T>(url, { method: 'GET' }),
  post: <T = any>(url: string, body?: any) =>
    request<T>(url, { method: 'POST', body: body ? JSON.stringify(body) : undefined }),
  patch: <T = any>(url: string, body?: any) =>
    request<T>(url, { method: 'PATCH', body: body ? JSON.stringify(body) : undefined }),
  put: <T = any>(url: string, body?: any) =>
    request<T>(url, { method: 'PUT', body: body ? JSON.stringify(body) : undefined }),
  delete: <T = any>(url: string) => request<T>(url, { method: 'DELETE' }),
};

// Auth
export const authApi = {
  register: (data: { name: string; username: string; email: string; password: string; confirmPassword: string }) =>
    api.post<{ user: any; verifyToken: string }>('/api/auth/register', data),
  login: (data: { email: string; password: string }) =>
    api.post<{ user: any }>('/api/auth/login', data),
  logout: () => api.post('/api/auth/logout'),
  me: () => api.get<{ user: any }>('/api/auth/me'),
  verifyEmail: (token: string) => api.post('/api/auth/verify-email', { token }),
  forgotPassword: (email: string) => api.post('/api/auth/forgot-password', { email }),
  resetPassword: (token: string, password: string) => api.post('/api/auth/reset-password', { token, password }),
  seed: () => api.post('/api/seed'),

  profile: () => api.get('/api/auth/profile'),
  updateProfile: (data: { name?: string; username?: string; email?: string; currentPassword?: string; newPassword?: string }) =>
    api.patch('/api/auth/profile', data),
};

// Customer VPS
export const customerApi = {
  listVps: (params: { search?: string; status?: string; page?: number; pageSize?: number; sort?: string } = {}) => {
    const q = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => v !== undefined && q.set(k, String(v)));
    return api.get(`/api/customer/vps?${q.toString()}`);
  },
  getVps: (id: string) => api.get(`/api/customer/vps/${id}`),
  power: (id: string, action: string) => api.post(`/api/customer/vps/${id}/${action}`),
  stats: (id: string) => api.get(`/api/customer/vps/${id}/stats`),
  activity: (id: string) => api.get(`/api/customer/vps/${id}/activity`),
  console: (id: string) => api.post(`/api/customer/vps/${id}/console`),
  // Self-service reinstall (owner/assigned only) — osId optional (keep current OS)
  reinstallVps: (id: string, osId?: string) => api.post(`/api/customer/vps/${id}/reinstall`, { osId }),
  reinstallOsOptions: (id: string) => api.get(`/api/customer/vps/${id}/reinstall`),
  // Port forwarding — max 5 active forwards per person (server-enforced)
  forwards: (id: string) => api.get(`/api/customer/vps/${id}/forwards`),
  addForward: (id: string, data: { protocol: string; externalPort?: number | string; internalPort: number | string; label?: string }) =>
    api.post(`/api/customer/vps/${id}/forwards`, data),
  deleteForward: (id: string, forwardId: string) => api.delete(`/api/customer/vps/${id}/forwards?forwardId=${forwardId}`),

  notifications: () => api.get('/api/customer/notifications'),
  notificationsUnread: () => api.get('/api/customer/notifications?unreadOnly=true'),
  markNotificationRead: (id: string) => api.post('/api/customer/notifications', { action: 'mark_read', id }),
  markAllNotificationsRead: () => api.post('/api/customer/notifications', { action: 'mark_all_read' }),

  sshKeys: () => api.get('/api/customer/ssh-keys'),
  addSshKey: (name: string, publicKey: string) => api.post('/api/customer/ssh-keys', { name, publicKey }),
  deleteSshKey: (id: string) => api.delete(`/api/customer/ssh-keys?id=${id}`),

  apiKeys: () => api.get('/api/customer/api-keys'),
  createApiKey: (name: string, scopes?: string) => api.post('/api/customer/api-keys', { name, scopes }),
  revokeApiKey: (id: string) => api.delete(`/api/customer/api-keys?id=${id}`),

  supportTickets: () => api.get('/api/customer/support'),
  createSupportTicket: (data: { subject: string; category: string; priority: string; message: string }) =>
    api.post('/api/customer/support', data),
  supportTicket: (id: string) => api.get(`/api/customer/support/${id}`),
  replySupportTicket: (id: string, body: string) => api.post(`/api/customer/support/${id}`, { body }),
  deleteSupportTicket: (id: string) => api.delete(`/api/customer/support/${id}`),
};

// Admin
export const adminApi = {
  dashboardStats: () => api.get('/api/admin/dashboard-stats'),
  systemHealth: () => api.get('/api/admin/system-health'),

  users: (params: any = {}) => {
    const q = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => v !== undefined && q.set(k, String(v)));
    return api.get(`/api/admin/users?${q.toString()}`);
  },
  user: (id: string) => api.get(`/api/admin/users/${id}`),
  updateUser: (id: string, data: any) => api.patch(`/api/admin/users/${id}`, data),
  deleteUser: (id: string) => api.delete(`/api/admin/users/${id}`),
  userAction: (id: string, action: string, extra: any = {}) => api.post(`/api/admin/users/${id}`, { action, ...extra }),

  vps: (params: any = {}) => {
    const q = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => v !== undefined && q.set(k, String(v)));
    return api.get(`/api/admin/vps?${q.toString()}`);
  },
  createVps: (data: any) => api.post('/api/admin/vps', data),
  getVps: (id: string) => api.get(`/api/admin/vps/${id}`),
  updateVps: (id: string, data: any) => api.patch(`/api/admin/vps/${id}`, data),
  deleteVps: (id: string) => api.delete(`/api/admin/vps/${id}`),
  deployVps: (id: string) => api.post(`/api/admin/vps/${id}/deploy`),
  reinstallVps: (id: string, osId: string) => api.post(`/api/admin/vps/${id}/reinstall`, { osId }),
  // Port forwarding (admin) — same 5-per-person limit on the VPS owner
  forwards: (id: string) => api.get(`/api/admin/vps/${id}/forwards`),
  addForward: (id: string, data: { protocol: string; externalPort?: number | string; internalPort: number | string; label?: string }) =>
    api.post(`/api/admin/vps/${id}/forwards`, data),
  deleteForward: (id: string, forwardId: string) => api.delete(`/api/admin/vps/${id}/forwards?forwardId=${forwardId}`),
  suspendVps: (id: string, reason: string) => api.post(`/api/admin/vps/${id}/suspend`, { reason }),
  unsuspendVps: (id: string) => api.post(`/api/admin/vps/${id}/unsuspend`),
  resizeVps: (id: string, data: any) => api.post(`/api/admin/vps/${id}/resize`, data),
  migrateVps: (id: string, destNodeId: string) => api.post(`/api/admin/vps/${id}/migrate`, { destNodeId }),
  powerVps: (id: string, action: string) => api.post(`/api/admin/vps/${id}/power`, { action }),

  nodes: () => api.get('/api/admin/nodes'),
  createNode: (data: any) => api.post('/api/admin/nodes', data),
  updateNode: (id: string, data: any) => api.patch(`/api/admin/nodes/${id}`, data),
  deleteNode: (id: string) => api.delete(`/api/admin/nodes/${id}`),
  nodeAction: (id: string, action: string, extra: any = {}) => api.post(`/api/admin/nodes/${id}`, { action, ...extra }),

  plans: () => api.get('/api/admin/plans'),
  createPlan: (data: any) => api.post('/api/admin/plans', data),
  updatePlan: (id: string, data: any) => api.patch(`/api/admin/plans/${id}`, data),
  deletePlan: (id: string) => api.delete(`/api/admin/plans/${id}`),

  os: () => api.get('/api/admin/os'),
  createOs: (data: any) => api.post('/api/admin/os', data),
  updateOs: (id: string, data: any) => api.patch(`/api/admin/os/${id}`, data),
  deleteOs: (id: string) => api.delete(`/api/admin/os/${id}`),
  osSeedProxmox: () => api.post('/api/admin/os', { action: 'seed_proxmox' }),

  supportTickets: (params: any = {}) => {
    const q = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => v !== undefined && v !== 'all' && q.set(k, String(v)));
    return api.get(`/api/admin/support?${q.toString()}`);
  },
  supportTicket: (id: string) => api.get(`/api/admin/support/${id}`),
  supportTicketAction: (id: string, action: string, extra: any = {}) =>
    api.post(`/api/admin/support/${id}`, { action, ...extra }),
  deleteSupportTicket: (id: string) => api.delete(`/api/admin/support/${id}`),

  ips: () => api.get('/api/admin/ips'),
  ipAction: (data: any) => api.post('/api/admin/ips', data),
  updateIp: (id: string, data: any) => api.patch(`/api/admin/ips/${id}`, data),
  deleteIp: (id: string) => api.delete(`/api/admin/ips/${id}`),

  deployments: (params: any = {}) => {
    const q = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => v !== undefined && q.set(k, String(v)));
    return api.get(`/api/admin/deployments?${q.toString()}`);
  },
  deployment: (id: string) => api.get(`/api/admin/deployments/${id}`),

  audit: (params: any = {}) => {
    const q = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => v !== undefined && q.set(k, String(v)));
    return api.get(`/api/admin/audit?${q.toString()}`);
  },

  settings: () => api.get('/api/admin/settings'),
  updateSettings: (updates: Record<string, string>) => api.patch('/api/admin/settings', { updates }),

  staff: () => api.get('/api/admin/staff'),
  createStaff: (data: any) => api.post('/api/admin/staff', data),

  roles: () => api.get('/api/admin/roles'),
  createRole: (data: { name: string; description?: string; permissions: string[] }) => api.post('/api/admin/roles', data),
  updateRole: (id: string, data: any) => api.patch(`/api/admin/roles/${id}`, data),
  deleteRole: (id: string) => api.delete(`/api/admin/roles/${id}`),
};
