import { create } from 'zustand';
import { api, authApi } from './api';

export interface User {
  id: string;
  email: string;
  username: string;
  name: string;
  role: string; // built-in (USER/SUPPORT/STAFF/ADMIN/SUPER_ADMIN) or custom Role Editor key
  emailVerified: boolean;
  status: string;
  permissions?: string[]; // resolved server-side (custom roles)
}

// Owner branding extras (links / watermark / credit) — synced from /api/settings
export interface Branding {
  youtubeUrl: string;     // "YT Owner" button link
  discordUrl: string;     // Discord Server button link
  watermarkText: string;  // bottom-right fixed watermark text
  ownerCredit: string;    // credit line under the buttons
  madeByUrl: string;      // link target for the owner-credit text

  // Login page hero — the big headline on the left panel (editable in Settings)
  heroTop: string;             // first (accent-colored) headline line, e.g. "Admin-Controlled"
  heroBottom: string;          // second headline line, e.g. "VPS Provisioning"
  heroDescription: string;     // paragraph under the headline
}

const DEFAULT_BRANDING: Branding = {
  youtubeUrl: 'https://www.youtube.com/channel/UCILvOqZhASpc_Pk0ULdrKUQ',
  discordUrl: 'https://discord.com',
  watermarkText: '', // bottom-left watermark disabled by default per user request
  ownerCredit: 'Made by YT',
  madeByUrl: 'https://www.youtube.com/@DevAVoid',
  heroTop: 'Admin-Controlled',
  heroBottom: 'VPS Provisioning',
  heroDescription: 'A production-grade virtual infrastructure management platform. Built for hosting providers who need strict separation between customer and administrative actions.',
};

interface AppState {
  user: User | null;
  loading: boolean;
  error: string | null;

  // Branding (site.name from /api/settings — synced live)
  brand: string;
  refreshBrand: () => Promise<void>;

  // Owner branding (links / watermark / credit — synced live)
  branding: Branding;

  // UI state for the single-page routing
  view: string;
  viewParams: any;

  // Sidebar open state (mobile slide-in)
  sidebarOpen: boolean;
  // Sidebar collapsed state (desktop rail mode — icons only)
  sidebarCollapsed: boolean;

  // Bootstrap
  init: () => Promise<void>;
  login: (email: string, password: string) => Promise<boolean>;
  register: (data: any) => Promise<boolean>;
  logout: () => Promise<void>;
  refreshUser: () => Promise<void>;

  setView: (view: string, params?: any) => void;
  setSidebarOpen: (open: boolean) => void;
  toggleSidebarCollapsed: () => void;
  setError: (err: string | null) => void;
}

export const useAppStore = create<AppState>((set, get) => ({
  user: null,
  loading: true,
  error: null,
  brand: 'DeUp-VPS',
  branding: DEFAULT_BRANDING,
  refreshBrand: async () => {
    const r = await api.get('/api/settings');
    if (r.success && r.data) {
      const d = r.data as Record<string, string>;
      if (d['site.name']) {
        set({ brand: d['site.name'] });
        if (typeof document !== 'undefined') {
          document.title = `${d['site.name']} — VPS Platform`;
        }
      }
      // Owner branding — keys are optional; keep the previous value when absent,
      // hide (empty string) when explicitly cleared in Settings
      set({
        branding: {
          youtubeUrl: d['site.youtube_url'] !== undefined ? d['site.youtube_url'] : get().branding.youtubeUrl,
          discordUrl: d['site.discord_url'] !== undefined ? d['site.discord_url'] : get().branding.discordUrl,
          watermarkText: d['site.watermark_text'] !== undefined ? d['site.watermark_text'] : get().branding.watermarkText,
          ownerCredit: d['site.owner_credit'] !== undefined ? d['site.owner_credit'] : get().branding.ownerCredit,
          madeByUrl: d['site.made_by_url'] !== undefined ? d['site.made_by_url'] : get().branding.madeByUrl,
          heroTop: d['auth.hero_top'] !== undefined ? d['auth.hero_top'] : get().branding.heroTop,
          heroBottom: d['auth.hero_bottom'] !== undefined ? d['auth.hero_bottom'] : get().branding.heroBottom,
          heroDescription: d['auth.hero_description'] !== undefined ? d['auth.hero_description'] : get().branding.heroDescription,
        },
      });
    }
  },
  view: 'dashboard',
  viewParams: null,
  sidebarOpen: false,
  sidebarCollapsed: false,

  init: async () => {
    set({ loading: true, error: null });
    const [res] = await Promise.all([
      authApi.me(),
      get().refreshBrand(),
    ]);
    // API returns { success, user, permissions } at top-level
    const user = (res as any).user;
    if (res.success && user) {
      set({ user: { ...user, permissions: (res as any).permissions || [] }, loading: false, view: 'dashboard' });
    } else {
      set({ user: null, loading: false });
    }
  },

  login: async (email, password) => {
    set({ error: null });
    const res = await authApi.login({ email, password });
    const user = (res as any).user;
    if (res.success && user) {
      set({ user: { ...user, permissions: (res as any).permissions || [] }, view: 'dashboard' });
      broadcastAuth('login');
      return true;
    }
    set({ error: res.error || 'LOGIN_FAILED' });
    return false;
  },

  register: async (data) => {
    set({ error: null });
    const res = await authApi.register(data);
    const user = (res as any).user;
    if (res.success && user) {
      set({ user, view: 'dashboard' });
      broadcastAuth('login');
      return true;
    }
    set({ error: res.error || 'REGISTER_FAILED' });
    return false;
  },

  logout: async () => {
    await authApi.logout();
    set({ user: null, view: 'dashboard' });
    broadcastAuth('logout');
  },

  refreshUser: async () => {
    const res = await authApi.me();
    const user = (res as any).user;
    if (res.success && user) {
      set({ user: { ...user, permissions: (res as any).permissions || [] } });
    }
  },

  setView: (view, params = null) => set({ view, viewParams: params, sidebarOpen: false }),
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
  toggleSidebarCollapsed: () => set(s => ({ sidebarCollapsed: !s.sidebarCollapsed })),
  setError: (err) => set({ error: err }),
}));

// ------------------------------------------------------------
// Cross-tab auth sync — keep sessions consistent across tabs
// ------------------------------------------------------------
function broadcastAuth(type: 'login' | 'logout'): void {
  try {
    localStorage.setItem('vps_auth_event', JSON.stringify({ type, at: Date.now() }));
  } catch { /* private mode — ignore */ }
}

if (typeof window !== 'undefined') {
  window.addEventListener('storage', (e) => {
    if (e.key !== 'vps_auth_event' || !e.newValue) return;
    try {
      const evt = JSON.parse(e.newValue);
      if (evt.type === 'logout' && useAppStore.getState().user) {
        useAppStore.setState({ user: null, view: 'dashboard', viewParams: null, loading: false });
      } else if (evt.type === 'login' && !useAppStore.getState().user) {
        // Another tab logged in — pick up the session
        useAppStore.getState().init();
      }
    } catch { /* malformed event — ignore */ }
  });
}

// Role helpers — work for built-in roles AND custom Role Editor roles.
// Accept either a bare role string (legacy) or the full user object.
const ADMIN_SIDEBAR_ROLES = ['ADMIN', 'SUPER_ADMIN', 'STAFF', 'SUPPORT'];

export function isAdmin(u?: { role?: string; permissions?: string[] } | string | null): boolean {
  const role = typeof u === 'string' ? u : u?.role;
  if (!role) return false;
  if (ADMIN_SIDEBAR_ROLES.includes(role)) return true;
  if (role === 'USER') return false;
  // Custom role — admin-side if it has any permissions at all
  const perms = typeof u === 'string' ? undefined : u?.permissions;
  return Array.isArray(perms) ? perms.length > 0 : true;
}

const PROVISIONING = [
  'vps.create', 'vps.deploy', 'vps.reinstall', 'vps.delete', 'vps.suspend',
  'vps.unsuspend', 'vps.resize', 'vps.migrate', 'vps.assign',
  'nodes.create', 'nodes.edit', 'nodes.delete',
  'plans.create', 'plans.edit', 'plans.delete',
  'os.create', 'os.edit', 'os.delete',
  'network.manage', 'ip.assign', 'ip.release', 'deployments.manage',
];

export function canProvision(u?: { role?: string; permissions?: string[] } | string | null): boolean {
  const role = typeof u === 'string' ? u : u?.role;
  if (!role) return false;
  if (['ADMIN', 'SUPER_ADMIN', 'STAFF'].includes(role)) return true;
  const perms = typeof u === 'string' ? [] : (u?.permissions || []);
  return perms.some(p => PROVISIONING.includes(p));
}

export function isSuperUser(u?: { role?: string; permissions?: string[] } | string | null): boolean {
  const role = typeof u === 'string' ? u : u?.role;
  if (role === 'ADMIN' || role === 'SUPER_ADMIN') return true;
  const perms = typeof u === 'string' ? [] : (u?.permissions || []);
  return perms.includes('staff.manage') || perms.includes('settings.edit');
}

export function userCan(u: { role?: string; permissions?: string[] } | null | undefined, permission: string): boolean {
  if (!u) return false;
  return (u.permissions || []).includes(permission);
}
