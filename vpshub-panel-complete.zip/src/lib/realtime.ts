// ============================================================
// Realtime emit — HTTP bridge to the socket.io mini-service
// ============================================================
// The Next.js API routes call this to push events to the
// socket mini-service, which fans them out to subscribers.
// ============================================================

import { DeploymentState } from '@prisma/client';

const SOCKET_SERVICE_URL = process.env.SOCKET_SERVICE_URL || 'http://localhost:3003';

export async function emitDeploymentProgress(
  jobId: string,
  state: DeploymentState | string,
  progress: number,
  message: string,
): Promise<void> {
  try {
    await fetch(`${SOCKET_SERVICE_URL}/emit`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        event: 'deployment.progress',
        room: `deployment:${jobId}`,
        payload: { jobId, state, progress, message, ts: Date.now() },
      }),
    });
  } catch {
    // non-fatal: realtime is best-effort
  }
}

export async function emitVpsStatus(vpsId: string, status: string): Promise<void> {
  try {
    await fetch(`${SOCKET_SERVICE_URL}/emit`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        event: 'vps.status.updated',
        room: `vps:${vpsId}`,
        payload: { vpsId, status, ts: Date.now() },
      }),
    });
  } catch {
    // non-fatal
  }
}

export async function emitVpsStats(vpsId: string, stats: Record<string, number>): Promise<void> {
  try {
    await fetch(`${SOCKET_SERVICE_URL}/emit`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        event: 'vps.stats.updated',
        room: `vps:${vpsId}`,
        payload: { vpsId, stats, ts: Date.now() },
      }),
    });
  } catch {
    // non-fatal
  }
}

export async function emitNotification(userId: string, notification: { type: string; title: string; message: string }): Promise<void> {
  try {
    await fetch(`${SOCKET_SERVICE_URL}/emit`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        event: 'notification.created',
        room: `user:${userId}`,
        payload: notification,
      }),
    });
  } catch {
    // non-fatal
  }
}

export async function emitConsoleOutput(vpsId: string, data: string): Promise<void> {
  try {
    await fetch(`${SOCKET_SERVICE_URL}/emit`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        event: 'console.output',
        room: `vps:${vpsId}:console`,
        payload: { vpsId, data, ts: Date.now() },
      }),
    });
  } catch {
    // non-fatal
  }
}
