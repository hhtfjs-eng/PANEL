// ============================================================
// Deployment Worker
// ============================================================
// Simulates a background worker that processes provisioning jobs.
// In production this would be BullMQ + Redis. Here we run an
// in-process async pipeline that steps through every deployment
// state and writes progress to the database.
// ============================================================

import { db } from '@/lib/db';
import { getProvider } from '@/lib/providers/proxmox';
import { DeploymentState, DeploymentStepStatus } from '@prisma/client';
import { emitDeploymentProgress } from '@/lib/realtime';

export interface DeploymentSteps {
  state: DeploymentState;
  stepName: string;
  message: string;
}

const PIPELINE: DeploymentSteps[] = [
  { state: 'VALIDATING',         stepName: 'validating',          message: 'Validating resources and customer' },
  { state: 'ALLOCATING',         stepName: 'allocating',          message: 'Allocating IP and node resources' },
  { state: 'CREATING_VM',        stepName: 'creating_vm',         message: 'Creating virtual machine on node' },
  { state: 'CONFIGURING',        stepName: 'configuring',        message: 'Configuring CPU/RAM/disk' },
  { state: 'INSTALLING_OS',      stepName: 'installing_os',      message: 'Installing operating system' },
  { state: 'CONFIGURING_NETWORK',stepName: 'configuring_network',message: 'Configuring networking' },
  { state: 'FINALIZING',         stepName: 'finalizing',         message: 'Finalizing configuration' },
  { state: 'HEALTH_CHECK',       stepName: 'health_check',       message: 'Running health check' },
];

const STEP_DELAY_MS = 1400;

export async function processDeployment(jobId: string): Promise<void> {
  const job = await db.deploymentJob.findUnique({
    where: { id: jobId },
    include: { vps: { include: { node: true, os: true } } },
  });
  if (!job) return;

  try {
    // Atomic claim — only proceeds if the job is still QUEUED. When the
    // panel runs in PM2 cluster mode (or a request is retried), multiple
    // instances may call processDeployment for the same jobId; this
    // conditional update ensures exactly one of them wins and the rest
    // return without touching the pipeline.
    const claimed = await db.deploymentJob.updateMany({
      where: { id: jobId, state: 'QUEUED' },
      data: { state: 'VALIDATING', startedAt: new Date() },
    });
    if (claimed.count === 0) {
      console.log(`[worker] job ${jobId} already claimed by another instance — skipping`);
      return;
    }
    emitDeploymentProgress(jobId, 'VALIDATING', 5, 'Validating resources');

    // Run each pipeline step
    let cumulativeProgress = 5;
    for (let i = 0; i < PIPELINE.length; i++) {
      const step = PIPELINE[i];
      cumulativeProgress = 5 + Math.round(((i + 1) / PIPELINE.length) * 90);

      // Create / update step record
      const stepRecord = await db.deploymentStep.create({
        data: {
          jobId,
          stepName: step.stepName,
          status: DeploymentStepStatus.RUNNING,
          message: step.message,
          startedAt: new Date(),
        },
      });

      // Update job state
      await db.deploymentJob.update({
        where: { id: jobId },
        data: { state: step.state, currentStep: step.stepName, progress: cumulativeProgress },
      });

      emitDeploymentProgress(jobId, step.state, cumulativeProgress, step.message);

      // Simulate the actual provider operation
      if (step.state === 'CREATING_VM' && job.vps.node) {
        const provider = getProvider(job.vps.node.provider, job.vps.node);
        const record = await provider.createVPS({
          name: job.vps.name,
          hostname: job.vps.hostname,
          cpu: job.vps.cpu,
          ramMb: job.vps.ramMb,
          diskGb: job.vps.diskGb,
          bandwidthMbps: job.vps.bandwidthMbps,
          osTemplateId: job.vps.os?.providerTemplateId || undefined,
          ipv4: job.vps.ipv4 || undefined,
          ipv6: job.vps.ipv6 || undefined,
          gateway: job.vps.gateway || undefined,
          dnsPrimary: job.vps.dnsPrimary || undefined,
          dnsSecondary: job.vps.dnsSecondary || undefined,
          autoStart: job.vps.autoStart,
        });
        await db.vps.update({
          where: { id: job.vps.id },
          data: {
            providerResourceId: record.providerResourceId,
            status: 'PROVISIONING',
          },
        });
      }

      if (step.state === 'INSTALLING_OS' && job.vps.providerResourceId && job.vps.os) {
        const provider = getProvider(job.vps.node?.provider || 'PROXMOX', job.vps.node);
        await provider.reinstallVPS(job.vps.providerResourceId, job.vps.os?.providerTemplateId || '');
      }

      await sleep(STEP_DELAY_MS + Math.random() * 600);

      // Mark step complete
      await db.deploymentStep.update({
        where: { id: stepRecord.id },
        data: {
          status: DeploymentStepStatus.COMPLETED,
          completedAt: new Date(),
          durationMs: Math.round(STEP_DELAY_MS + Math.random() * 600),
        },
      });
    }

    // Final state
    await db.deploymentJob.update({
      where: { id: jobId },
      data: {
        state: 'COMPLETED',
        progress: 100,
        currentStep: 'completed',
        completedAt: new Date(),
      },
    });

    await db.vps.update({
      where: { id: job.vps.id },
      data: {
        status: job.vps.autoStart ? 'RUNNING' : 'STOPPED',
        lastBootedAt: job.vps.autoStart ? new Date() : null,
        uptimeSeconds: 0,
      },
    });

    emitDeploymentProgress(jobId, 'COMPLETED', 100, 'VPS deployed successfully');

    // Notification + audit handled by caller
  } catch (err: any) {
    await db.deploymentJob.update({
      where: { id: jobId },
      data: {
        state: 'FAILED',
        errorMessage: err?.message || 'Unknown error',
        completedAt: new Date(),
      },
    });
    await db.vps.update({
      where: { id: job.vps.id },
      data: { status: 'ERROR' },
    });
    emitDeploymentProgress(jobId, 'FAILED', 0, err?.message || 'Deployment failed');
  }
}

function sleep(ms: number): Promise<void> {
  return new Promise(r => setTimeout(r, ms));
}
