import { db } from '@/lib/db';
import { writeAudit } from '@/lib/auth';
import { emitNotification, emitVpsStatus } from '@/lib/realtime';

// =================================================================
// AUTO-SUSPEND SCHEDULER
// =================================================================
// Suspends VPS whose admin-configured suspendAt date has passed.
// Runs every 60s inside the Next.js server process (started from
// instrumentation.ts). Only touches VPS in a stable running/stopped
// state — never interrupts an in-flight deployment.
// =================================================================

const CHECK_INTERVAL_MS = 60 * 1000;

declare global {
  // eslint-disable-next-line no-var
  var __autoSuspendTimer: ReturnType<typeof setInterval> | undefined;
}

export function startAutoSuspendScheduler(): void {
  if (globalThis.__autoSuspendTimer) return; // already running (dev HMR safe)
  console.log('[auto-suspend] scheduler started (checks every 60s)');
  globalThis.__autoSuspendTimer = setInterval(() => {
    runAutoSuspendSweep().catch(err => {
      console.error('[auto-suspend] sweep failed:', err);
    });
  }, CHECK_INTERVAL_MS);
}

export async function runAutoSuspendSweep(): Promise<number> {
  const now = new Date();
  // Stable states only — skip QUEUED/PROVISIONING/REINSTALLING/DELETING
  const due = await db.vps.findMany({
    where: {
      autoSuspendAt: { lte: now },
      status: { in: ['RUNNING', 'STOPPED', 'REBOOTING', 'ERROR', 'PENDING'] },
    },
    take: 50,
  });

  for (const vps of due) {
    try {
      await db.vps.update({
        where: { id: vps.id },
        data: {
          status: 'SUSPENDED',
          suspendReason: `Auto-suspended (scheduled for ${vps.autoSuspendAt!.toISOString()})`,
        },
      });
      emitVpsStatus(vps.id, 'SUSPENDED');

      await db.vpsActivity.create({
        data: {
          vpsId: vps.id,
          action: 'VPS_SUSPENDED',
          actor: 'system (auto-suspend)',
          message: `Automatically suspended — scheduled suspend date reached (${vps.autoSuspendAt!.toLocaleString()})`,
        },
      });

      await writeAudit({
        action: 'VPS_AUTO_SUSPENDED',
        targetId: vps.id,
        metadata: {
          scheduledFor: vps.autoSuspendAt!.toISOString(),
          reason: 'scheduled auto-suspend',
        },
      });

      if (vps.ownerId) {
        const n = await db.notification.create({
          data: {
            userId: vps.ownerId,
            type: 'VPS_SUSPENDED',
            title: 'VPS Auto-Suspended',
            message: `Your VPS "${vps.name}" was automatically suspended — its scheduled suspend date was reached.`,
          },
        });
        emitNotification(vps.ownerId, { type: 'VPS_SUSPENDED', title: n.title, message: n.message });
      }

      console.log(`[auto-suspend] suspended VPS ${vps.name} (${vps.id})`);
    } catch (err) {
      console.error(`[auto-suspend] failed to suspend VPS ${vps.id}:`, err);
    }
  }

  return due.length;
}
