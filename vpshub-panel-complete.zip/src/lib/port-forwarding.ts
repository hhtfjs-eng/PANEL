// ============================================================
// Port forwarding — shared server-side logic
// ============================================================
// Limit: 5 ACTIVE forwards per PERSON (owner), counted across all
// of that user's VPSes. External ports are unique per node+protocol.
// ============================================================

import { db } from '@/lib/db';
import { getProvider } from '@/lib/providers/proxmox';

export const PORT_FORWARD_LIMIT = 5;
export const PROTOCOLS = ['tcp', 'udp'] as const;
const AUTO_RANGE_MIN = 20000;
const AUTO_RANGE_MAX = 60999;

export interface ForwardInput {
  protocol?: string;
  externalPort?: number | string | null;
  internalPort: number | string;
  label?: string | null;
}

function toPort(v: number | string | undefined | null): number | null {
  if (v === undefined || v === null || v === '') return null;
  const n = typeof v === 'number' ? v : parseInt(String(v).trim(), 10);
  if (!Number.isInteger(n)) return null;
  return n;
}

/** Find a free external port on the node (auto-assign when omitted). */
async function pickExternalPort(
  nodeId: string, protocol: string, requested: number | null,
): Promise<number> {
  if (requested !== null) return requested;
  for (let attempt = 0; attempt < 40; attempt++) {
    const port = AUTO_RANGE_MIN + Math.floor(Math.random() * (AUTO_RANGE_MAX - AUTO_RANGE_MIN + 1));
    const clash = await db.portForward.findFirst({
      where: { nodeId, protocol, externalPort: port, status: 'ACTIVE' },
    });
    if (!clash) return port;
  }
  throw new Error('NO_FREE_PORT');
}

export type CreateForwardResult =
  | { ok: true; forward: any }
  | { ok: false; error: string; message?: string };

/**
 * Create a port forward on a VPS. Enforces:
 *  - protocol tcp|udp
 *  - internal port 1-65535
 *  - external port (manual) 1024-65535 (auto-assigned from 20000-60999 when omitted)
 *  - max 5 ACTIVE forwards per owner (PORT_FORWARD_LIMIT)
 *  - unique (node, protocol, externalPort)
 */
export async function createPortForward(
  vpsId: string,
  actor: { id: string; email: string; role: string },
  input: ForwardInput,
): Promise<CreateForwardResult> {
  const vps = await db.vps.findUnique({ where: { id: vpsId }, include: { node: true } });
  if (!vps) return { ok: false, error: 'NOT_FOUND' };
  if (!vps.node) return { ok: false, error: 'NO_NODE', message: 'VPS has no node assigned' };

  const protocol = (input.protocol || 'tcp').toLowerCase();
  if (!(PROTOCOLS as readonly string[]).includes(protocol)) {
    return { ok: false, error: 'INVALID_PROTOCOL' };
  }

  const internalPort = toPort(input.internalPort);
  if (internalPort === null || internalPort < 1 || internalPort > 65535) {
    return { ok: false, error: 'INVALID_INTERNAL_PORT' };
  }

  const extRaw = toPort(input.externalPort);
  if (input.externalPort !== undefined && input.externalPort !== null && input.externalPort !== '' && extRaw === null) {
    return { ok: false, error: 'INVALID_EXTERNAL_PORT' };
  }
  if (extRaw !== null && (extRaw < 1024 || extRaw > 65535)) {
    return { ok: false, error: 'INVALID_EXTERNAL_PORT', message: 'External port must be 1024-65535 (1-1023 reserved for node services)' };
  }

  // ---- PER-PERSON LIMIT: 5 active forwards per owner, across all their VPSes ----
  const used = await db.portForward.count({
    where: { ownerId: vps.ownerId, status: 'ACTIVE' },
  });
  if (used >= PORT_FORWARD_LIMIT) {
    return {
      ok: false,
      error: 'PORT_LIMIT_REACHED',
      message: `Limit reached — max ${PORT_FORWARD_LIMIT} port forwards per person. Delete one to add another.`,
    };
  }

  // ---- Resolve + validate the external port ----
  let externalPort: number;
  try {
    externalPort = await pickExternalPort(vps.nodeId!, protocol, extRaw);
  } catch {
    return { ok: false, error: 'NO_FREE_PORT' };
  }

  const clash = await db.portForward.findFirst({
    where: { nodeId: vps.nodeId!, protocol, externalPort, status: 'ACTIVE' },
  });
  if (clash) return { ok: false, error: 'PORT_IN_USE', message: `Port ${externalPort}/${protocol} is already in use on this node` };

  const label = (input.label || '').toString().trim().slice(0, 60) || null;

  // ---- Provider-side NAT rule (only when the VPS is actually provisioned) ----
  if (vps.providerResourceId && vps.node) {
    try {
      const provider = getProvider(vps.node.provider, vps.node);
      await provider.addPortForward(vps.providerResourceId, {
        protocol: protocol as 'tcp' | 'udp',
        externalPort,
        internalPort,
        containerIp: vps.ipv4 || undefined,
      });
    } catch (err: any) {
      return { ok: false, error: 'PROVIDER_ERROR', message: err?.message };
    }
  }

  const forward = await db.portForward.create({
    data: {
      vpsId: vps.id,
      ownerId: vps.ownerId,
      nodeId: vps.nodeId!,
      protocol,
      externalPort,
      internalPort,
      label,
      status: 'ACTIVE',
    },
  });

  await db.vpsActivity.create({
    data: {
      vpsId: vps.id,
      action: 'PORT_FORWARD_ADDED',
      actor: actor.email,
      message: `${externalPort}/${protocol} → :${internalPort}${label ? ` (${label})` : ''}`,
    },
  });

  return { ok: true, forward };
}

export interface DeleteForwardResult {
  ok: boolean;
  error?: string;
}

export async function deletePortForward(
  vpsId: string,
  forwardId: string,
  actor: { id: string; email: string; role: string },
): Promise<DeleteForwardResult> {
  const forward = await db.portForward.findUnique({ where: { id: forwardId } });
  if (!forward || forward.vpsId !== vpsId) return { ok: false, error: 'NOT_FOUND' };
  if (forward.status !== 'ACTIVE') return { ok: false, error: 'NOT_FOUND' };

  const vps = await db.vps.findUnique({ where: { id: vpsId }, include: { node: true } });

  // Remove the provider-side NAT rule (best-effort — DB row is deleted regardless)
  if (vps?.providerResourceId && vps.node) {
    try {
      const provider = getProvider(vps.node.provider, vps.node);
      await provider.removePortForward(vps.providerResourceId, {
        protocol: forward.protocol as 'tcp' | 'udp',
        externalPort: forward.externalPort,
        internalPort: forward.internalPort,
        containerIp: vps.ipv4 || undefined,
      });
    } catch { /* rule may already be gone */ }
  }

  // Delete the row (frees the per-node port slot immediately). The
  // VpsActivity + AuditLog entries below keep the audit trail.
  await db.portForward.delete({ where: { id: forwardId } });

  await db.vpsActivity.create({
    data: {
      vpsId,
      action: 'PORT_FORWARD_REMOVED',
      actor: actor.email,
      message: `${forward.externalPort}/${forward.protocol} → :${forward.internalPort}`,
    },
  });

  return { ok: true };
}

/** List forwards for a VPS + the owner's per-person usage. */
export async function listPortForwards(vpsId: string) {
  const vps = await db.vps.findUnique({ where: { id: vpsId }, include: { node: true } });
  if (!vps) return null;
  const [forwards, used] = await Promise.all([
    db.portForward.findMany({
      where: { vpsId, status: 'ACTIVE' },
      orderBy: { createdAt: 'desc' },
    }),
    db.portForward.count({ where: { ownerId: vps.ownerId, status: 'ACTIVE' } }),
  ]);
  return {
    forwards,
    nodeIp: vps.node?.ipAddress || null,
    nodeName: vps.node?.name || null,
    limit: PORT_FORWARD_LIMIT,
    used,
    remaining: Math.max(0, PORT_FORWARD_LIMIT - used),
  };
}
