import { z } from 'zod';

/**
 * Unicode-safe email schema.
 *
 * Zod's default `.email()` (and the browser's `type="email"` validation)
 * only accept ASCII, which silently blocks perfectly valid international
 * email addresses — e.g. "nøctis@gmail.com" (Danish ø). Users could not
 * log in or register with such addresses at all.
 *
 * This validator is deliberately permissive on Unicode while still
 * enforcing the structural rules that matter:
 *   - exactly one "@"
 *   - non-empty local part and domain
 *   - no whitespace
 *   - a dot in the domain with a TLD of 2+ characters
 *
 * Real deliverability is verified by the account lookup (login) or the
 * verification email (register) — not by this regex.
 */
export const emailSchema = z
  .string()
  .min(3)
  .max(254)
  .regex(/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/, 'EMAIL_INVALID');

/** Helper: normalize an email for storage/lookup (trim + lowercase). */
export function normalizeEmail(email: string): string {
  return email.trim().toLowerCase();
}
