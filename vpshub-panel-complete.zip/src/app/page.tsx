'use client';

import { useEffect, useState, type ComponentType } from 'react';
import { useAppStore } from '@/lib/frontend/store';
import dynamic from 'next/dynamic';
import { Loader2 } from 'lucide-react';

function Loader() {
  return (
    <div className="flex items-center justify-center py-20">
      <Loader2 className="w-6 h-6 text-rose-400 animate-spin" />
    </div>
  );
}

// Dynamically import each view so memory is spread across requests
const AuthView = dynamic(() => import('@/components/auth/auth-view').then(m => ({ default: m.AuthView })), { loading: () => <Loader /> });
const CustomerShell = dynamic(() => import('@/components/customer/customer-shell').then(m => ({ default: m.CustomerShell })), { loading: () => <Loader /> });
const CustomerDashboard = dynamic(() => import('@/components/customer/customer-dashboard').then(m => ({ default: m.CustomerDashboard })), { loading: () => <Loader /> });
const CustomerVpsList = dynamic(() => import('@/components/customer/customer-vps-list').then(m => ({ default: m.CustomerVpsList })), { loading: () => <Loader /> });
const CustomerVpsDetail = dynamic(() => import('@/components/customer/customer-vps-detail').then(m => ({ default: m.CustomerVpsDetail })), { loading: () => <Loader /> });
const CustomerNotifications = dynamic(() => import('@/components/customer/customer-notifications').then(m => ({ default: m.CustomerNotifications })), { loading: () => <Loader /> });
const CustomerSshKeys = dynamic(() => import('@/components/customer/customer-ssh-keys').then(m => ({ default: m.CustomerSshKeys })), { loading: () => <Loader /> });
const CustomerApiKeys = dynamic(() => import('@/components/customer/customer-api-keys').then(m => ({ default: m.CustomerApiKeys })), { loading: () => <Loader /> });
const CustomerSupport = dynamic(() => import('@/components/customer/customer-support').then(m => ({ default: m.CustomerSupport })), { loading: () => <Loader /> });
const AdminShell = dynamic(() => import('@/components/admin/admin-shell').then(m => ({ default: m.AdminShell })), { loading: () => <Loader /> });
const AdminDashboard = dynamic(() => import('@/components/admin/admin-dashboard').then(m => ({ default: m.AdminDashboard })), { loading: () => <Loader /> });
const AdminVps = dynamic(() => import('@/components/admin/admin-vps').then(m => ({ default: m.AdminVps })), { loading: () => <Loader /> });
const AdminVpsDetail = dynamic(() => import('@/components/admin/admin-vps-detail').then(m => ({ default: m.AdminVpsDetail })), { loading: () => <Loader /> });
const AdminUsers = dynamic(() => import('@/components/admin/admin-users').then(m => ({ default: m.AdminUsers })), { loading: () => <Loader /> });
const AdminNodes = dynamic(() => import('@/components/admin/admin-nodes').then(m => ({ default: m.AdminNodes })), { loading: () => <Loader /> });
const AdminSupport = dynamic(() => import('@/components/admin/admin-support').then(m => ({ default: m.AdminSupport })), { loading: () => <Loader /> });
const AdminRoles = dynamic(() => import('@/components/admin/admin-roles').then(m => ({ default: m.AdminRoles })), { loading: () => <Loader /> });
const ProfilePage = dynamic(() => import('@/components/shared/profile-page').then(m => ({ default: m.ProfilePage })), { loading: () => <Loader /> });

// AdminManage holds Plans/OS/IPs/Deployments/Audit/Settings/Staff/Health
function AdminManageComponent({ name }: { name: string }) {
  const [Comp, setComp] = useState<ComponentType<any> | null>(null);
  useEffect(() => {
    let mounted = true;
    import('@/components/admin/admin-manage').then((m: any) => {
      if (mounted && m[name]) setComp(() => m[name]);
    });
    return () => { mounted = false; };
  }, [name]);
  if (!Comp) return <Loader />;
  return <Comp />;
}

export default function Home() {
  const { user, loading, view, init, brand } = useAppStore();

  useEffect(() => { init(); }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-zinc-950">
        <div className="flex flex-col items-center gap-3">
          <Loader2 className="w-8 h-8 text-rose-500 animate-spin" />
          <p className="text-sm text-zinc-500">Loading {brand}…</p>
        </div>
      </div>
    );
  }

  // Login page — the owner-identity row (YT Owner / Discord / Made by YT
  // link) is rendered inside the auth card. The bottom-right global watermark
  // was removed per the user's request ("remove that watermark of YT").
  if (!user) {
    return <AuthView />;
  }

  const isCustomer = user.role === 'USER';

  if (isCustomer) {
    let content: React.ReactNode = <CustomerDashboard />;
    switch (view) {
      case 'dashboard': content = <CustomerDashboard />; break;
      case 'profile': content = <ProfilePage />; break;
      case 'vps': content = <CustomerVpsList />; break;
      case 'vps-detail': content = <CustomerVpsDetail />; break;
      case 'notifications': content = <CustomerNotifications />; break;
      case 'ssh-keys': content = <CustomerSshKeys />; break;
      case 'api-keys': content = <CustomerApiKeys />; break;
      case 'support': content = <CustomerSupport />; break;
    }
    return <CustomerShell user={user}>{content}</CustomerShell>;
  }

  // Admin/staff views
  let content: React.ReactNode = <AdminDashboard />;
  switch (view) {
    case 'admin-dashboard': content = <AdminDashboard />; break;
    case 'admin-profile': content = <ProfilePage />; break;
    case 'admin-users': content = <AdminUsers />; break;
    case 'admin-vps': content = <AdminVps />; break;
    case 'admin-vps-detail': content = <AdminVpsDetail />; break;
    case 'admin-deployments': content = <AdminManageComponent name="AdminDeployments" />; break;
    case 'admin-nodes': content = <AdminNodes />; break;
    case 'admin-support': content = <AdminSupport />; break;
    case 'admin-plans': content = <AdminManageComponent name="AdminPlans" />; break;
    case 'admin-os': content = <AdminManageComponent name="AdminOs" />; break;
    case 'admin-ips': content = <AdminManageComponent name="AdminIps" />; break;
    case 'admin-audit': content = <AdminManageComponent name="AdminAudit" />; break;
    case 'admin-settings': content = <AdminManageComponent name="AdminSettings" />; break;
    case 'admin-staff': content = <AdminManageComponent name="AdminStaff" />; break;
    case 'admin-roles': content = <AdminRoles />; break;
    case 'admin-health': content = <AdminManageComponent name="AdminHealth" />; break;
  }
  return <AdminShell user={user}>{content}</AdminShell>;
}
