import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';

const VerifySchema = z.object({ token: z.string().min(8) });

export async function POST(req: NextRequest) {
  const body = await req.json();
  const parsed = VerifySchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ success: false, error: 'VALIDATION_ERROR' }, { status: 400 });
  }
  const user = await db.user.findFirst({ where: { emailVerifyToken: parsed.data.token } });
  if (!user) {
    return NextResponse.json({ success: false, error: 'INVALID_TOKEN' }, { status: 404 });
  }
  await db.user.update({
    where: { id: user.id },
    data: { emailVerified: true, emailVerifyToken: null },
  });
  return NextResponse.json({ success: true });
}
