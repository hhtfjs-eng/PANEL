import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { requireAuth, writeAudit, hashPassword, verifyPassword } from '@/lib/auth';
import { emailSchema, normalizeEmail } from '@/lib/validators';
import { resolveRolePermissions } from '@/lib/permissions';

const ProfileSchema = z.object({
  name: z.string().min(1).max(100).optional(),
  username: z.string().min(3).max(30).regex(/^[a-zA-Z0-9_]+$/).optional(),
  email: emailSchema.optional(),
  currentPassword: z.string().max(128).optional(),
  newPassword: z.string().min(8).max(128).optional(),
});

// GET — own profile (any authenticated user)
export async function GET() {
  const auth = await requireAuth();
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const u = await db.user.findUnique({
    where: { id: auth.user!.id },
    select: {
      id: true, name: true, username: true, email: true, role: true,
      status: true, emailVerified: true, lastLogin: true, createdAt: true,
    },
  });
  if (!u) return NextResponse.json({ success: false, error: 'NOT_FOUND' }, { status: 404 });
  return NextResponse.json({ success: true, data: u });
}

// PATCH — update own profile. Password changes require the current password.
export async function PATCH(req: NextRequest) {
  const auth = await requireAuth();
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });

  const body = await req.json().catch(() => null);
  const parsed = ProfileSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ success: false, error: 'VALIDATION_ERROR', details: parsed.error.flatten() }, { status: 400 });
  }
  const { name, username, email, currentPassword, newPassword } = parsed.data;

  const user = await db.user.findUnique({ where: { id: auth.user!.id } });
  if (!user) return NextResponse.json({ success: false, error: 'NOT_FOUND' }, { status: 404 });

  const patch: any = {};
  if (name !== undefined && name !== user.name) patch.name = name.trim();

  if (username !== undefined && username !== user.username) {
    const taken = await db.user.findUnique({ where: { username } });
    if (taken) return NextResponse.json({ success: false, error: 'USERNAME_TAKEN' }, { status: 409 });
    patch.username = username;
  }

  if (email !== undefined) {
    const normalized = normalizeEmail(email);
    if (normalized !== user.email) {
      const taken = await db.user.findUnique({ where: { email: normalized } });
      if (taken) return NextResponse.json({ success: false, error: 'EMAIL_TAKEN' }, { status: 409 });
      patch.email = normalized;
      // Email changed → require re-verification
      patch.emailVerified = false;
    }
  }

  if (newPassword) {
    if (!currentPassword) {
      return NextResponse.json({ success: false, error: 'CURRENT_PASSWORD_REQUIRED' }, { status: 400 });
    }
    const ok = await verifyPassword(currentPassword, user.passwordHash);
    if (!ok) {
      return NextResponse.json({ success: false, error: 'CURRENT_PASSWORD_WRONG' }, { status: 403 });
    }
    patch.passwordHash = await hashPassword(newPassword);
  }

  if (Object.keys(patch).length === 0) {
    return NextResponse.json({ success: true, data: { unchanged: true } });
  }

  const updated = await db.user.update({ where: { id: user.id }, data: patch });

  await writeAudit({
    actorId: user.id,
    actorRole: user.role,
    targetId: user.id,
    action: 'OWN_PROFILE_UPDATED',
    metadata: { fields: Object.keys(patch).filter(f => f !== 'passwordHash') },
  });

  const permissions = await resolveRolePermissions(updated.role);
  return NextResponse.json({
    success: true,
    user: {
      id: updated.id, email: updated.email, username: updated.username,
      name: updated.name, role: updated.role, emailVerified: updated.emailVerified,
      status: updated.status,
    },
    permissions,
  });
}
