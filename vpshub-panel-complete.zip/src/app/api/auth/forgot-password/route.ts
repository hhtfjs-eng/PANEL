import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { generateToken } from '@/lib/auth';
import { emailSchema } from '@/lib/validators';

const ForgotSchema = z.object({ email: emailSchema });

export async function POST(req: NextRequest) {
  const body = await req.json();
  const parsed = ForgotSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ success: false, error: 'VALIDATION_ERROR' }, { status: 400 });
  }
  const { email } = parsed.data;
  const user = await db.user.findUnique({ where: { email: email.trim().toLowerCase() } });
  if (user) {
    const token = generateToken(32);
    await db.user.update({
      where: { id: user.id },
      data: { passwordResetToken: token, passwordResetExpires: new Date(Date.now() + 3600000) },
    });
    // In production: send email via SMTP queue.
    // Sandbox: return token for dev convenience.
    return NextResponse.json({ success: true, resetToken: token });
  }
  // Always return success to avoid account enumeration
  return NextResponse.json({ success: true });
}
