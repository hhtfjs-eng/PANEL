import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { hashPassword } from '@/lib/auth';

const ResetSchema = z.object({
  token: z.string().min(8),
  password: z.string().min(8).max(128),
});

export async function POST(req: NextRequest) {
  const body = await req.json();
  const parsed = ResetSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ success: false, error: 'VALIDATION_ERROR' }, { status: 400 });
  }
  const { token, password } = parsed.data;
  const user = await db.user.findFirst({
    where: {
      passwordResetToken: token,
      passwordResetExpires: { gt: new Date() },
    },
  });
  if (!user) {
    return NextResponse.json({ success: false, error: 'INVALID_OR_EXPIRED_TOKEN' }, { status: 404 });
  }
  const passwordHash = await hashPassword(password);
  await db.user.update({
    where: { id: user.id },
    data: {
      passwordHash,
      passwordResetToken: null,
      passwordResetExpires: null,
    },
  });
  return NextResponse.json({ success: true });
}
