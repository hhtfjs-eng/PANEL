import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { hashPassword, setSessionCookie, generateToken, writeAudit } from '@/lib/auth';
import { emailSchema, normalizeEmail } from '@/lib/validators';

const RegisterSchema = z.object({
  name: z.string().min(1).max(100),
  username: z.string().min(3).max(30).regex(/^[a-zA-Z0-9_]+$/, 'Username must be alphanumeric'),
  email: emailSchema,
  password: z.string().min(8).max(128),
  confirmPassword: z.string(),
}).refine(d => d.password === d.confirmPassword, { message: 'Passwords do not match', path: ['confirmPassword'] });

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = RegisterSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { success: false, error: 'VALIDATION_ERROR', details: parsed.error.flatten() },
        { status: 400 }
      );
    }
    const { name, username, email, password } = parsed.data;
    const normalizedEmail = normalizeEmail(email);

    // Check uniqueness
    const existingEmail = await db.user.findUnique({ where: { email: normalizedEmail } });
    if (existingEmail) {
      return NextResponse.json(
        { success: false, error: 'EMAIL_TAKEN' },
        { status: 409 }
      );
    }
    const existingUsername = await db.user.findUnique({ where: { username } });
    if (existingUsername) {
      return NextResponse.json(
        { success: false, error: 'USERNAME_TAKEN' },
        { status: 409 }
      );
    }

    const passwordHash = await hashPassword(password);
    const verifyToken = generateToken(32);

    const user = await db.user.create({
      data: {
        name,
        username,
        email: normalizedEmail,
        passwordHash,
        role: 'USER',
        status: 'ACTIVE',
        emailVerified: false,
        emailVerifyToken: verifyToken,
      },
    });

    await setSessionCookie({
      userId: user.id,
      role: user.role,
      email: user.email,
      username: user.username,
    });

    await writeAudit({
      actorId: user.id,
      actorRole: user.role,
      action: 'USER_REGISTERED',
      ipAddress: req.headers.get('x-forwarded-for') || undefined,
      userAgent: req.headers.get('user-agent') || undefined,
      metadata: { email, username },
    });

    return NextResponse.json({
      success: true,
      user: {
        id: user.id, email: user.email, username: user.username,
        name: user.name, role: user.role, emailVerified: user.emailVerified,
      },
      verifyToken,
    });
  } catch (err: any) {
    console.error('Register error:', err);
    return NextResponse.json(
      { success: false, error: 'INTERNAL_ERROR', message: err?.message },
      { status: 500 }
    );
  }
}
