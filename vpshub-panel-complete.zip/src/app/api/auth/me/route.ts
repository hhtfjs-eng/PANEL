import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { resolveRolePermissions } from '@/lib/permissions';

export async function GET() {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ success: false, error: 'UNAUTHENTICATED' }, { status: 401 });
  }
  const permissions = await resolveRolePermissions(user.role);
  return NextResponse.json({
    success: true,
    user: {
      id: user.id, email: user.email, username: user.username,
      name: user.name, role: user.role, emailVerified: user.emailVerified,
      status: user.status,
    },
    permissions,
  });
}
