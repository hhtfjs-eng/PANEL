import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { verifyPassword, setSessionCookie, writeAudit, touchUserActivity } from '@/lib/auth';
import { emailSchema } from '@/lib/validators';
import { resolveRolePermissions } from '@/lib/permissions';

// Login accepts either an email or a username in the `email` field.
// The lookup normalizes emails (trim+toLowerCase) and falls back to a
// case-insensitive username lookup when the input is not a valid email.
const LoginSchema = z.object({
  email: z.string().min(1).max(200), // accept email OR username — refined below
  password: z.string().min(1).max(128),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = LoginSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ success: false, error: 'VALIDATION_ERROR' }, { status: 400 });
    }

    const { email: raw, password } = parsed.data;
    const trimmed = raw.trim();

    // First, try email lookup (unicode-safe, normalized).
    // If the input passes our email schema, look it up by email; otherwise
    // fall back to a case-insensitive username lookup.
    let user: any = null;
    const emailCheck = emailSchema.safeParse(trimmed);
    if (emailCheck.success) {
      user = await db.user.findUnique({ where: { email: emailCheck.data.trim().toLowerCase() } });
    }
    if (!user) {
      // Fall back to a case-insensitive username lookup. SQLite (sandbox)
      // supports COLLATE NOCASE — works regardless of how the user typed it.
      // Production on PostgreSQL should use Prisma's mode:'insensitive'.
      const rows: any[] = await db.$queryRaw`SELECT * FROM User WHERE username = ${trimmed} COLLATE NOCASE LIMIT 1`;
      user = Array.isArray(rows) && rows.length > 0 ? rows[0] : null;
    }

    if (!user) {
      return NextResponse.json({ success: false, error: 'INVALID_CREDENTIALS' }, { status: 401 });
    }
    if (user.status !== 'ACTIVE') {
      return NextResponse.json({ success: false, error: 'ACCOUNT_SUSPENDED' }, { status: 403 });
    }

    const ok = await verifyPassword(password, user.passwordHash);
    if (!ok) {
      await writeAudit({
        actorId: user.id,
        action: 'LOGIN_FAILED',
        success: false,
        ipAddress: req.headers.get('x-forwarded-for') || undefined,
        userAgent: req.headers.get('user-agent') || undefined,
      });
      return NextResponse.json({ success: false, error: 'INVALID_CREDENTIALS' }, { status: 401 });
    }

    await db.user.update({
      where: { id: user.id },
      data: { lastLogin: new Date(), lastActivity: new Date() },
    });

    await setSessionCookie({
      userId: user.id,
      role: user.role,
      email: user.email,
      username: user.username,
    });

    await writeAudit({
      actorId: user.id,
      actorRole: user.role,
      action: 'LOGIN_SUCCESS',
      ipAddress: req.headers.get('x-forwarded-for') || undefined,
      userAgent: req.headers.get('user-agent') || undefined,
    });

    const permissions = await resolveRolePermissions(user.role);

    return NextResponse.json({
      success: true,
      user: {
        id: user.id, email: user.email, username: user.username,
        name: user.name, role: user.role, emailVerified: user.emailVerified,
      },
      permissions,
    });
  } catch (err: any) {
    console.error('Login error:', err);
    return NextResponse.json({ success: false, error: 'INTERNAL_ERROR' }, { status: 500 });
  }
}
