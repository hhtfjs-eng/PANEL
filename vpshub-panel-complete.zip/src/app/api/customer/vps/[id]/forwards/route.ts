import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireAuth, writeAudit } from '@/lib/auth';
import { createPortForward, deletePortForward, listPortForwards } from '@/lib/port-forwarding';

// Customer self-service port forwarding. The owner (or assigned user) of a
// VPS can manage NAT forwards on it — limit: 5 active forwards per person.

interface RouteParams { params: Promise<{ id: string }> }

async function guard(ctx: RouteParams) {
  const auth = await requireAuth();
  if (!auth.ok) return { auth, vps: null, allowed: false } as const;
  const { id } = await ctx.params;
  const vps = await db.vps.findUnique({ where: { id }, select: { id: true, ownerId: true, assignedToId: true, status: true } });
  if (!vps) return { auth, vps: null, allowed: false } as const;
  const isAdmin = ['ADMIN', 'SUPER_ADMIN', 'STAFF'].includes(auth.user!.role);
  const allowed = vps.ownerId === auth.user!.id || vps.assignedToId === auth.user!.id || isAdmin;
  return { auth, vps, allowed } as const;
}

// GET — list this VPS's forwards + per-person usage
export async function GET(_req: NextRequest, ctx: RouteParams) {
  const { auth, vps, allowed } = await guard(ctx);
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  if (!vps) return NextResponse.json({ success: false, error: 'NOT_FOUND' }, { status: 404 });
  if (!allowed) return NextResponse.json({ success: false, error: 'INSUFFICIENT_PERMISSIONS' }, { status: 403 });

  const data = await listPortForwards(vps.id);
  if (!data) return NextResponse.json({ success: false, error: 'NOT_FOUND' }, { status: 404 });
  return NextResponse.json({ success: true, data });
}

// POST — add a forward { protocol, externalPort?, internalPort, label? }
export async function POST(req: NextRequest, ctx: RouteParams) {
  const { auth, vps, allowed } = await guard(ctx);
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  if (!vps) return NextResponse.json({ success: false, error: 'NOT_FOUND' }, { status: 404 });
  if (!allowed) return NextResponse.json({ success: false, error: 'INSUFFICIENT_PERMISSIONS' }, { status: 403 });
  if (vps.status === 'SUSPENDED') return NextResponse.json({ success: false, error: 'VPS_SUSPENDED' }, { status: 403 });
  if (vps.status === 'PROVISIONING') return NextResponse.json({ success: false, error: 'VPS_PROVISIONING' }, { status: 400 });

  const body = await req.json().catch(() => ({}));
  const result = await createPortForward(vps.id, auth.user!, body);
  if (!result.ok) {
    const status = ['NOT_FOUND', 'NO_NODE'].includes(result.error) ? 404 :
      ['PORT_LIMIT_REACHED', 'PORT_IN_USE', 'INVALID_PROTOCOL', 'INVALID_INTERNAL_PORT', 'INVALID_EXTERNAL_PORT', 'NO_FREE_PORT'].includes(result.error) ? 400 : 502;
    return NextResponse.json({ success: false, error: result.error, message: (result as any).message }, { status });
  }

  await writeAudit({
    actorId: auth.user!.id, actorRole: auth.user!.role,
    targetId: vps.id, action: 'PORT_FORWARD_ADDED',
    metadata: { protocol: result.forward.protocol, externalPort: result.forward.externalPort, internalPort: result.forward.internalPort },
  });

  return NextResponse.json({ success: true, data: result.forward });
}

// DELETE ?forwardId= — remove a forward
export async function DELETE(req: NextRequest, ctx: RouteParams) {
  const { auth, vps, allowed } = await guard(ctx);
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  if (!vps) return NextResponse.json({ success: false, error: 'NOT_FOUND' }, { status: 404 });
  if (!allowed) return NextResponse.json({ success: false, error: 'INSUFFICIENT_PERMISSIONS' }, { status: 403 });

  const forwardId = new URL(req.url).searchParams.get('forwardId') || '';
  if (!forwardId) return NextResponse.json({ success: false, error: 'MISSING_FORWARD_ID' }, { status: 400 });

  const result = await deletePortForward(vps.id, forwardId, auth.user!);
  if (!result.ok) return NextResponse.json({ success: false, error: result.error }, { status: 404 });

  await writeAudit({
    actorId: auth.user!.id, actorRole: auth.user!.role,
    targetId: vps.id, action: 'PORT_FORWARD_REMOVED',
    metadata: { forwardId },
  });

  return NextResponse.json({ success: true });
}
