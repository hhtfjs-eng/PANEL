import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireAuth, writeAudit } from '@/lib/auth';
import { getProvider } from '@/lib/providers/proxmox';
import { emitVpsStatus } from '@/lib/realtime';

interface RouteParams { params: Promise<{ id: string }> }

export async function POST(req: NextRequest, ctx: RouteParams) {
  const auth = await requireAuth();
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const { id } = await ctx.params;

  const vps = await db.vps.findUnique({ where: { id }, include: { node: true } });
  if (!vps) return NextResponse.json({ success: false, error: 'NOT_FOUND' }, { status: 404 });

  const isOwner = vps.ownerId === auth.user!.id;
  const isAssigned = vps.assignedToId === auth.user!.id;
  const isAdmin = ['ADMIN', 'SUPER_ADMIN', 'STAFF'].includes(auth.user!.role);
  if (!isOwner && !isAssigned && !isAdmin) {
    return NextResponse.json({ success: false, error: 'INSUFFICIENT_PERMISSIONS' }, { status: 403 });
  }
  if (vps.status === 'SUSPENDED' && !isAdmin) {
    return NextResponse.json({ success: false, error: 'VPS_SUSPENDED' }, { status: 403 });
  }

  if (vps.providerResourceId && vps.node) {
    try { await getProvider(vps.node.provider, vps.node).stopVPS(vps.providerResourceId); }
    catch (err: any) { return NextResponse.json({ success: false, error: 'PROVIDER_ERROR' }, { status: 502 }); }
  }

  await db.vps.update({ where: { id }, data: { status: 'STOPPED' } });
  await db.vpsActivity.create({ data: { vpsId: id, action: 'POWER_STOP', actor: auth.user!.email, message: 'stop' } });
  emitVpsStatus(id, 'STOPPED');
  await writeAudit({ actorId: auth.user!.id, actorRole: auth.user!.role, targetId: id, action: 'VPS_STOPPED' });

  return NextResponse.json({ success: true, status: 'STOPPED' });
}
