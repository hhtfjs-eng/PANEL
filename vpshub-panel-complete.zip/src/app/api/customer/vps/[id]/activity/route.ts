import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireAuth } from '@/lib/auth';

interface RouteParams { params: Promise<{ id: string }> }

export async function GET(req: NextRequest, ctx: RouteParams) {
  const auth = await requireAuth();
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const { id } = await ctx.params;

  const vps = await db.vps.findUnique({ where: { id } });
  if (!vps) return NextResponse.json({ success: false, error: 'NOT_FOUND' }, { status: 404 });

  const isOwner = vps.ownerId === auth.user!.id;
  const isAssigned = vps.assignedToId === auth.user!.id;
  const isAdmin = ['ADMIN', 'SUPER_ADMIN', 'STAFF'].includes(auth.user!.role);
  if (!isOwner && !isAssigned && !isAdmin) {
    return NextResponse.json({ success: false, error: 'INSUFFICIENT_PERMISSIONS' }, { status: 403 });
  }

  const activity = await db.vpsActivity.findMany({
    where: { vpsId: id },
    orderBy: { createdAt: 'desc' },
    take: 100,
  });

  return NextResponse.json({ success: true, data: activity });
}
