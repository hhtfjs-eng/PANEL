import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireAuth, writeAudit } from '@/lib/auth';
import { getProvider } from '@/lib/providers/proxmox';
import { emitNotification, emitVpsStatus } from '@/lib/realtime';

// Customer-facing reinstall — the owner (or assigned user) of a VPS can
// reinstall its OS without admin involvement. Mirrors the admin route
// (/api/admin/vps/[id]/reinstall) but gates on ownership instead of the
// vps.reinstall permission, exactly like the customer power actions.

interface RouteParams { params: Promise<{ id: string }> }

// GET — list the OS templates the customer may reinstall with
export async function GET(_req: NextRequest, ctx: RouteParams) {
  const auth = await requireAuth();
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const { id } = await ctx.params;

  const vps = await db.vps.findUnique({ where: { id }, select: { id: true, ownerId: true, assignedToId: true } });
  if (!vps) return NextResponse.json({ success: false, error: 'NOT_FOUND' }, { status: 404 });

  const isOwner = vps.ownerId === auth.user!.id;
  const isAssigned = vps.assignedToId === auth.user!.id;
  const isAdmin = ['ADMIN', 'SUPER_ADMIN', 'STAFF'].includes(auth.user!.role);
  if (!isOwner && !isAssigned && !isAdmin) {
    return NextResponse.json({ success: false, error: 'INSUFFICIENT_PERMISSIONS' }, { status: 403 });
  }

  const osList = await db.operatingSystem.findMany({
    where: { available: true },
    select: { id: true, name: true, distribution: true, version: true, architecture: true },
    orderBy: { name: 'asc' },
  });
  return NextResponse.json({ success: true, data: osList });
}

// POST — run the reinstall (body: { osId? } — omit to keep the current OS)
export async function POST(req: NextRequest, ctx: RouteParams) {
  const auth = await requireAuth();
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const { id } = await ctx.params;
  const body = await req.json().catch(() => ({}));
  const osId = body.osId as string | undefined;

  const vps = await db.vps.findUnique({ where: { id }, include: { node: true, os: true } });
  if (!vps) return NextResponse.json({ success: false, error: 'NOT_FOUND' }, { status: 404 });

  const isOwner = vps.ownerId === auth.user!.id;
  const isAssigned = vps.assignedToId === auth.user!.id;
  const isAdmin = ['ADMIN', 'SUPER_ADMIN', 'STAFF'].includes(auth.user!.role);
  if (!isOwner && !isAssigned && !isAdmin) {
    return NextResponse.json({ success: false, error: 'INSUFFICIENT_PERMISSIONS' }, { status: 403 });
  }
  if (vps.status === 'SUSPENDED' && !isAdmin) {
    return NextResponse.json({ success: false, error: 'VPS_SUSPENDED' }, { status: 403 });
  }
  if (vps.status === 'PROVISIONING') {
    return NextResponse.json({ success: false, error: 'VPS_PROVISIONING' }, { status: 400 });
  }

  const targetOs = osId ? await db.operatingSystem.findUnique({ where: { id: osId } }) : vps.os;
  if (!targetOs) return NextResponse.json({ success: false, error: 'OS_NOT_FOUND' }, { status: 404 });

  await db.vps.update({ where: { id }, data: { status: 'REINSTALLING' } });
  emitVpsStatus(id, 'REINSTALLING');

  try {
    if (vps.providerResourceId && vps.node) {
      await getProvider(vps.node.provider, vps.node).reinstallVPS(vps.providerResourceId, targetOs.providerTemplateId || targetOs.id);
    }
    await db.vps.update({ where: { id }, data: { status: 'RUNNING', osId: targetOs.id, lastBootedAt: new Date() } });
    emitVpsStatus(id, 'RUNNING');
  } catch (err: any) {
    await db.vps.update({ where: { id }, data: { status: 'ERROR' } });
    emitVpsStatus(id, 'ERROR');
    return NextResponse.json({ success: false, error: 'REINSTALL_FAILED', message: err?.message }, { status: 502 });
  }

  await db.vpsActivity.create({
    data: { vpsId: id, action: 'VPS_REINSTALLED', actor: auth.user!.email, message: `Reinstalled with ${targetOs.name} (self-service)` },
  });
  await writeAudit({
    actorId: auth.user!.id, actorRole: auth.user!.role,
    targetId: id, action: 'VPS_REINSTALLED_SELF',
    metadata: { os: targetOs.name },
  });

  if (vps.ownerId) {
    const n = await db.notification.create({
      data: {
        userId: vps.ownerId,
        type: 'VPS_REINSTALLED',
        title: 'VPS Reinstalled',
        message: `Your VPS "${vps.name}" was reinstalled with ${targetOs.name}.`,
      },
    });
    emitNotification(vps.ownerId, { type: 'VPS_REINSTALLED', title: n.title, message: n.message });
  }

  return NextResponse.json({ success: true });
}
