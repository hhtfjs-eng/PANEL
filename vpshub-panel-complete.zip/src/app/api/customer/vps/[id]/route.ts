import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireAuth, writeAudit, generateSshKeyPair, generateRootPassword } from '@/lib/auth';
import { getProvider } from '@/lib/providers/proxmox';
import { emitVpsStatus } from '@/lib/realtime';

interface RouteParams { params: Promise<{ id: string }> }

export async function GET(req: NextRequest, { params }: RouteParams) {
  const auth = await requireAuth();
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const { id } = await params;

  let vps = await db.vps.findUnique({
    where: { id },
    include: { node: true, os: true, plan: true, ips: true },
  });
  if (!vps) return NextResponse.json({ success: false, error: 'NOT_FOUND' }, { status: 404 });

  // DATA ISOLATION — must own or be assigned, no IDOR
  const isOwner = vps.ownerId === auth.user!.id;
  const isAssigned = vps.assignedToId === auth.user!.id;
  const isAdmin = ['ADMIN', 'SUPER_ADMIN', 'STAFF'].includes(auth.user!.role);
  if (!isOwner && !isAssigned && !isAdmin) {
    return NextResponse.json({ success: false, error: 'INSUFFICIENT_PERMISSIONS' }, { status: 403 });
  }

  // Lazy backfill — VPS created before SSH credentials were auto-generated
  // gets a full set now: public key, initial root password, login username,
  // and an ownername-derived hostname so SSH reads root@ownername.
  const needsBackfill = !vps.sshPublicKey || !vps.rootPasswordPlain || !vps.sshUsername;
  if (needsBackfill) {
    const sshKey = generateSshKeyPair(vps.hostname || 'vps');
    const owner = await db.user.findUnique({ where: { id: vps.ownerId } });
    const ownerHostname = (owner?.name || 'vps').trim().replace(/\s+/g, '') || 'vps';
    vps = await db.vps.update({
      where: { id: vps.id },
      data: {
        sshPublicKey: vps.sshPublicKey || sshKey.publicKey,
        sshKeyFingerprint: vps.sshKeyFingerprint || sshKey.fingerprint,
        // One-time migration: legacy VPS hostname switches to the
        // ownername-derived hostname so the SSH login reads root@ownername.
        hostname: ownerHostname,
        rootPasswordPlain: vps.rootPasswordPlain || generateRootPassword(24),
        sshUsername: vps.sshUsername || 'root',
      },
      include: { node: true, os: true, plan: true, ips: true },
    });
  }

  // Never leak the password hash to any client
  const { rootPasswordHash, ...safeVps } = vps as any;
  return NextResponse.json({ success: true, data: safeVps });
}

// Power operations — admin can do all, customer can do basic (start/stop/restart/shutdown)
// if they own the VPS and it's not suspended.
export async function POST(req: NextRequest, { params }: RouteParams) {
  const auth = await requireAuth();
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const { id } = await params;
  const body = await req.json();
  const action = body.action as string;

  const validActions = ['start', 'stop', 'restart', 'shutdown', 'force_stop', 'force_restart'];
  if (!validActions.includes(action)) {
    return NextResponse.json({ success: false, error: 'INVALID_ACTION' }, { status: 400 });
  }

  const vps = await db.vps.findUnique({ where: { id }, include: { node: true } });
  if (!vps) return NextResponse.json({ success: false, error: 'NOT_FOUND' }, { status: 404 });

  const isOwner = vps.ownerId === auth.user!.id;
  const isAssigned = vps.assignedToId === auth.user!.id;
  const isAdmin = ['ADMIN', 'SUPER_ADMIN', 'STAFF'].includes(auth.user!.role);

  if (!isOwner && !isAssigned && !isAdmin) {
    return NextResponse.json({ success: false, error: 'INSUFFICIENT_PERMISSIONS' }, { status: 403 });
  }

  if (vps.status === 'SUSPENDED' && !isAdmin) {
    return NextResponse.json({ success: false, error: 'VPS_SUSPENDED' }, { status: 403 });
  }

  // Map action to status transition
  const transitions: Record<string, string> = {
    start: 'RUNNING',
    stop: 'STOPPED',
    restart: 'RUNNING',
    shutdown: 'STOPPED',
    force_stop: 'STOPPED',
    force_restart: 'RUNNING',
  };

  // Call provider (server-side only)
  if (vps.providerResourceId && vps.node) {
    const provider = getProvider(vps.node.provider, vps.node);
    try {
      switch (action) {
        case 'start': await provider.startVPS(vps.providerResourceId); break;
        case 'stop': await provider.stopVPS(vps.providerResourceId); break;
        case 'restart': await provider.restartVPS(vps.providerResourceId); break;
        case 'shutdown': await provider.shutdownVPS(vps.providerResourceId); break;
        case 'force_stop': await provider.forceStopVPS(vps.providerResourceId); break;
        case 'force_restart': await provider.restartVPS(vps.providerResourceId); break;
      }
    } catch (err: any) {
      return NextResponse.json({ success: false, error: 'PROVIDER_ERROR', message: err?.message }, { status: 502 });
    }
  }

  await db.vps.update({
    where: { id },
    data: {
      status: transitions[action] as any,
      lastBootedAt: action === 'start' || action === 'restart' ? new Date() : vps.lastBootedAt,
    },
  });

  await db.vpsActivity.create({
    data: {
      vpsId: id,
      action: `POWER_${action.toUpperCase()}`,
      actor: auth.user!.email,
      message: `Power action: ${action}`,
    },
  });

  emitVpsStatus(id, transitions[action]);

  await writeAudit({
    actorId: auth.user!.id,
    actorRole: auth.user!.role,
    targetId: id,
    action: `VPS_${action.toUpperCase()}`,
    metadata: { vpsId: id, vpsName: vps.name },
  });

  return NextResponse.json({ success: true, status: transitions[action] });
}
