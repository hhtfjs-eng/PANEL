import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireAuth, writeAudit } from '@/lib/auth';
import { getProvider } from '@/lib/providers/proxmox';

interface RouteParams { params: Promise<{ id: string }> }

export async function GET(req: NextRequest, ctx: RouteParams) {
  const auth = await requireAuth();
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const { id } = await ctx.params;

  const vps = await db.vps.findUnique({ where: { id }, include: { node: true } });
  if (!vps) return NextResponse.json({ success: false, error: 'NOT_FOUND' }, { status: 404 });

  const isOwner = vps.ownerId === auth.user!.id;
  const isAssigned = vps.assignedToId === auth.user!.id;
  const isAdmin = ['ADMIN', 'SUPER_ADMIN', 'STAFF'].includes(auth.user!.role);
  if (!isOwner && !isAssigned && !isAdmin) {
    return NextResponse.json({ success: false, error: 'INSUFFICIENT_PERMISSIONS' }, { status: 403 });
  }

  // Get real infrastructure metrics where available
  let stats: Awaited<ReturnType<ReturnType<typeof getProvider>['getStats']>> | null = null;
  if (vps.providerResourceId && vps.node) {
    try {
      stats = await getProvider(vps.node.provider, vps.node).getStats(vps.providerResourceId);
      // Persist metrics for history
      await db.vpsMetric.create({
        data: {
          vpsId: id,
          cpuUsage: stats.cpuUsage,
          ramUsage: stats.ramUsage,
          diskUsage: stats.diskUsage,
          netInKbps: stats.netInKbps,
          netOutKbps: stats.netOutKbps,
        },
      });
    } catch {
      stats = null;
    }
  }

  // Also fetch historical metrics for charts
  const history = await db.vpsMetric.findMany({
    where: { vpsId: id },
    orderBy: { collectedAt: 'desc' },
    take: 30,
  });
  history.reverse();

  return NextResponse.json({ success: true, data: { current: stats, history } });
}
