import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireAuth, writeAudit } from '@/lib/auth';
import { getProvider } from '@/lib/providers/proxmox';
import { emitVpsStatus } from '@/lib/realtime';

interface RouteParams { params: Promise<{ id: string }> }

async function powerAction(
  req: NextRequest,
  ctx: { params: Promise<{ id: string }> },
  action: 'start' | 'stop' | 'restart' | 'shutdown' | 'force_stop' | 'force_restart'
) {
  const auth = await requireAuth();
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const { id } = await ctx.params;

  const vps = await db.vps.findUnique({ where: { id }, include: { node: true } });
  if (!vps) return NextResponse.json({ success: false, error: 'NOT_FOUND' }, { status: 404 });

  const isOwner = vps.ownerId === auth.user!.id;
  const isAssigned = vps.assignedToId === auth.user!.id;
  const isAdmin = ['ADMIN', 'SUPER_ADMIN', 'STAFF'].includes(auth.user!.role);

  // DATA ISOLATION
  if (!isOwner && !isAssigned && !isAdmin) {
    return NextResponse.json({ success: false, error: 'INSUFFICIENT_PERMISSIONS' }, { status: 403 });
  }
  if (vps.status === 'SUSPENDED' && !isAdmin) {
    return NextResponse.json({ success: false, error: 'VPS_SUSPENDED' }, { status: 403 });
  }

  if (vps.providerResourceId && vps.node) {
    const provider = getProvider(vps.node.provider, vps.node);
    try {
      switch (action) {
        case 'start': await provider.startVPS(vps.providerResourceId); break;
        case 'stop': await provider.stopVPS(vps.providerResourceId); break;
        case 'restart':
        case 'force_restart': await provider.restartVPS(vps.providerResourceId); break;
        case 'shutdown': await provider.shutdownVPS(vps.providerResourceId); break;
        case 'force_stop': await provider.forceStopVPS(vps.providerResourceId); break;
      }
    } catch (err: any) {
      return NextResponse.json({ success: false, error: 'PROVIDER_ERROR', message: err?.message }, { status: 502 });
    }
  }

  const newStatus = action === 'start' || action.includes('restart') ? 'RUNNING' : 'STOPPED';
  await db.vps.update({
    where: { id },
    data: {
      status: newStatus as any,
      lastBootedAt: action === 'start' || action.includes('restart') ? new Date() : vps.lastBootedAt,
    },
  });

  await db.vpsActivity.create({
    data: {
      vpsId: id,
      action: `POWER_${action.toUpperCase()}`,
      actor: auth.user!.email,
      message: `${action} requested`,
    },
  });

  emitVpsStatus(id, newStatus);

  await writeAudit({
    actorId: auth.user!.id,
    actorRole: auth.user!.role,
    targetId: id,
    action: `VPS_${action.toUpperCase()}`,
    metadata: { vpsId: id, vpsName: vps.name },
  });

  return NextResponse.json({ success: true, status: newStatus });
}

export async function POST(req: NextRequest, ctx: RouteParams) {
  return powerAction(req, ctx, 'start');
}
