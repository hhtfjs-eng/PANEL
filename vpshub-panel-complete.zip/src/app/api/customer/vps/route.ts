import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireAuth } from '@/lib/auth';

export async function GET(req: NextRequest) {
  const auth = await requireAuth();
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });

  const url = new URL(req.url);
  const search = url.searchParams.get('search') || '';
  const status = url.searchParams.get('status') || '';
  const page = parseInt(url.searchParams.get('page') || '1');
  const pageSize = parseInt(url.searchParams.get('pageSize') || '20');
  const sort = url.searchParams.get('sort') || 'createdAt';

  // CUSTOMERS SEE ONLY VPS ASSIGNED TO THEM (data isolation).
  // Built with AND[] so the ownership OR can never be clobbered by the
  // search OR (duplicate object keys would silently drop the ownership
  // filter and leak other customers' VPS into search results).
  const where = {
    AND: [
      { OR: [{ ownerId: auth.user!.id }, { assignedToId: auth.user!.id }] },
      // Never show deleted VPS in the default list
      status ? { status: status as any } : { status: { notIn: ['DELETED'] as any[] } },
      ...(search ? [{
        OR: [{ name: { contains: search } }, { hostname: { contains: search } }],
      }] : []),
    ],
  };

  const [total, vpsList] = await Promise.all([
    db.vps.count({ where }),
    db.vps.findMany({
      where,
      include: {
        node: true,
        os: true,
        plan: true,
      },
      orderBy: sort === 'name' ? { name: 'asc' } : { createdAt: 'desc' },
      skip: (page - 1) * pageSize,
      take: pageSize,
    }),
  ]);

  return NextResponse.json({
    success: true,
    data: vpsList.map(v => ({
      id: v.id,
      name: v.name,
      hostname: v.hostname,
      description: v.description,
      status: v.status,
      ipv4: v.ipv4,
      ipv6: v.ipv6,
      os: v.os ? { name: v.os.name, version: v.os.version, distribution: v.os.distribution } : null,
      cpu: v.cpu,
      ramMb: v.ramMb,
      diskGb: v.diskGb,
      bandwidthMbps: v.bandwidthMbps,
      node: v.node ? {
        id: v.node.id, name: v.node.name, region: v.node.region,
        datacenter: v.node.datacenter, health: v.node.health,
      } : null,
      plan: v.plan ? { id: v.plan.id, name: v.plan.name } : null,
      createdAt: v.createdAt,
      updatedAt: v.updatedAt,
      lastBootedAt: v.lastBootedAt,
      monitoringEnabled: v.monitoringEnabled,
      suspendReason: v.suspendReason,
    })),
    pagination: { page, pageSize, total, totalPages: Math.ceil(total / pageSize) },
  });
}
