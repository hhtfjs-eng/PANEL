import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { requireAuth } from '@/lib/auth';
import crypto from 'crypto';

export async function GET(req: NextRequest) {
  const auth = await requireAuth();
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const keys = await db.sshKey.findMany({
    where: { userId: auth.user!.id },
    orderBy: { createdAt: 'desc' },
  });
  return NextResponse.json({ success: true, data: keys });
}

const SshKeySchema = z.object({
  name: z.string().min(1).max(100),
  publicKey: z.string().min(1),
});

function fingerprintKey(pub: string): string {
  const hash = crypto.createHash('sha256').update(pub).digest('base64');
  return `SHA256:${hash}`;
}

export async function POST(req: NextRequest) {
  const auth = await requireAuth();
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const body = await req.json();
  const parsed = SshKeySchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ success: false, error: 'VALIDATION_ERROR' }, { status: 400 });
  const key = await db.sshKey.create({
    data: {
      userId: auth.user!.id,
      name: parsed.data.name,
      publicKey: parsed.data.publicKey,
      fingerprint: fingerprintKey(parsed.data.publicKey),
    },
  });
  return NextResponse.json({ success: true, data: { id: key.id } });
}

export async function DELETE(req: NextRequest) {
  const auth = await requireAuth();
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const url = new URL(req.url);
  const id = url.searchParams.get('id');
  if (!id) return NextResponse.json({ success: false, error: 'MISSING_ID' }, { status: 400 });
  await db.sshKey.deleteMany({ where: { id, userId: auth.user!.id } });
  return NextResponse.json({ success: true });
}
