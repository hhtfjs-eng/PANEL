import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireAuth } from '@/lib/auth';

export async function GET(req: NextRequest) {
  const auth = await requireAuth();
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const url = new URL(req.url);
  const unreadOnly = url.searchParams.get('unreadOnly') === 'true';
  const list = await db.notification.findMany({
    where: { userId: auth.user!.id, ...(unreadOnly ? { read: false } : {}) },
    orderBy: { createdAt: 'desc' },
    take: 100,
  });
  return NextResponse.json({ success: true, data: list });
}

export async function POST(req: NextRequest) {
  const auth = await requireAuth();
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const body = await req.json();
  const action = body.action;
  if (action === 'mark_read') {
    await db.notification.updateMany({
      where: { id: body.id, userId: auth.user!.id },
      data: { read: true },
    });
    return NextResponse.json({ success: true });
  }
  if (action === 'mark_all_read') {
    await db.notification.updateMany({
      where: { userId: auth.user!.id, read: false },
      data: { read: true },
    });
    return NextResponse.json({ success: true });
  }
  return NextResponse.json({ success: false, error: 'INVALID_ACTION' }, { status: 400 });
}
