import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { requireAuth, generateToken } from '@/lib/auth';
import crypto from 'crypto';

export async function GET(req: NextRequest) {
  const auth = await requireAuth();
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const keys = await db.apiKey.findMany({
    where: { userId: auth.user!.id, revoked: false },
    orderBy: { createdAt: 'desc' },
  });
  return NextResponse.json({ success: true, data: keys.map(k => ({ ...k, tokenHash: undefined })) });
}

const CreateSchema = z.object({
  name: z.string().min(1).max(100),
  scopes: z.string().default('vps.view,vps.power,vps.stats'),
  expiresAt: z.string().optional(),
});

export async function POST(req: NextRequest) {
  const auth = await requireAuth();
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const body = await req.json();
  const parsed = CreateSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ success: false, error: 'VALIDATION_ERROR' }, { status: 400 });
  const token = generateToken(40);
  const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
  const key = await db.apiKey.create({
    data: {
      userId: auth.user!.id,
      name: parsed.data.name,
      tokenHash,
      scopes: parsed.data.scopes,
      expiresAt: parsed.data.expiresAt ? new Date(parsed.data.expiresAt) : null,
    },
  });
  // Only return the raw token once at creation
  return NextResponse.json({ success: true, data: { id: key.id, token } });
}

export async function DELETE(req: NextRequest) {
  const auth = await requireAuth();
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const url = new URL(req.url);
  const id = url.searchParams.get('id');
  if (!id) return NextResponse.json({ success: false, error: 'MISSING_ID' }, { status: 400 });
  await db.apiKey.updateMany({
    where: { id, userId: auth.user!.id },
    data: { revoked: true },
  });
  return NextResponse.json({ success: true });
}
