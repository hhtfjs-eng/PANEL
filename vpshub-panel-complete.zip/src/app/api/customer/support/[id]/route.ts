import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { requireAuth } from '@/lib/auth';

interface RouteParams { params: Promise<{ id: string }> }

// GET /api/customer/support/[id] — own ticket + message thread
export async function GET(req: NextRequest, ctx: RouteParams) {
  const auth = await requireAuth();
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });

  const { id } = await ctx.params;
  const ticket = await db.supportTicket.findFirst({
    where: { id, userId: auth.user!.id },
    include: {
      messages: {
        orderBy: { createdAt: 'asc' },
        include: { user: { select: { name: true, role: true } } },
      },
    },
  });
  if (!ticket) return NextResponse.json({ success: false, error: 'NOT_FOUND' }, { status: 404 });
  return NextResponse.json({ success: true, data: ticket });
}

const ReplySchema = z.object({ body: z.string().min(1).max(8000) });

// POST /api/customer/support/[id] — customer reply in the thread
export async function POST(req: NextRequest, ctx: RouteParams) {
  const auth = await requireAuth();
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });

  const { id } = await ctx.params;
  const ticket = await db.supportTicket.findFirst({ where: { id, userId: auth.user!.id } });
  if (!ticket) return NextResponse.json({ success: false, error: 'NOT_FOUND' }, { status: 404 });
  if (ticket.status === 'closed') {
    return NextResponse.json({ success: false, error: 'TICKET_CLOSED' }, { status: 400 });
  }

  const body = await req.json();
  const parsed = ReplySchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ success: false, error: 'VALIDATION_ERROR' }, { status: 400 });

  const message = await db.supportMessage.create({
    data: { ticketId: id, userId: auth.user!.id, body: parsed.data.body, isStaff: false },
  });
  // Customer replied → mark open so staff sees activity again
  await db.supportTicket.update({ where: { id }, data: { status: 'open' } });
  return NextResponse.json({ success: true, data: { messageId: message.id } });
}

// DELETE /api/customer/support/[id] — delete one of MY OWN tickets (thread cascades)
export async function DELETE(req: NextRequest, ctx: RouteParams) {
  const auth = await requireAuth();
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });

  const { id } = await ctx.params;
  const ticket = await db.supportTicket.findFirst({ where: { id, userId: auth.user!.id } });
  if (!ticket) return NextResponse.json({ success: false, error: 'NOT_FOUND' }, { status: 404 });

  await db.supportTicket.delete({ where: { id } });
  return NextResponse.json({ success: true });
}
