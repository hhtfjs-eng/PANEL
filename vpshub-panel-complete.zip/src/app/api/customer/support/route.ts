import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { requireAuth } from '@/lib/auth';

export async function GET(req: NextRequest) {
  const auth = await requireAuth();
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const tickets = await db.supportTicket.findMany({
    where: { userId: auth.user!.id },
    include: { _count: { select: { messages: true } } },
    orderBy: { createdAt: 'desc' },
  });
  return NextResponse.json({ success: true, data: tickets });
}

const CreateSchema = z.object({
  subject: z.string().min(1).max(200),
  category: z.string().default('general'),
  priority: z.enum(['low', 'normal', 'high', 'urgent']).default('normal'),
  message: z.string().min(1),
});

export async function POST(req: NextRequest) {
  const auth = await requireAuth();
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const body = await req.json();
  const parsed = CreateSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ success: false, error: 'VALIDATION_ERROR' }, { status: 400 });
  const ticket = await db.supportTicket.create({
    data: {
      userId: auth.user!.id,
      subject: parsed.data.subject,
      category: parsed.data.category,
      priority: parsed.data.priority,
    },
  });
  await db.supportMessage.create({
    data: {
      ticketId: ticket.id,
      userId: auth.user!.id,
      body: parsed.data.message,
      isStaff: false,
    },
  });
  return NextResponse.json({ success: true, data: { id: ticket.id } });
}
