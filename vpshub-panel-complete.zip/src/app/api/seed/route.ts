import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { hashPassword, generateRootPassword, generateToken, generateSshKeyPair } from '@/lib/auth';

// One-time seeding endpoint. In production this would be locked to bootstrap.
export async function POST(req: NextRequest) {
  try {
  // Check if already seeded
  const adminExists = await db.user.findFirst({ where: { role: 'SUPER_ADMIN' } });
  if (adminExists) {
    return NextResponse.json({ success: false, error: 'ALREADY_SEEDED' }, { status: 400 });
  }

  // Create super admin
  const passwordHash = await hashPassword('Admin@2024!');
  const superAdmin = await db.user.create({
    data: {
      name: 'Super Admin', username: 'superadmin', email: 'admin@vps-platform.local',
      passwordHash, role: 'SUPER_ADMIN', status: 'ACTIVE', emailVerified: true,
    },
  });

  // Create a couple of demo staff
  const staffHash = await hashPassword('Staff@2024!');
  const staff = await db.user.create({
    data: { name: 'Demo Staff', username: 'staff', email: 'staff@vps-platform.local',
      passwordHash: staffHash, role: 'STAFF', status: 'ACTIVE', emailVerified: true },
  });

  // Create a demo customer
  const customerHash = await hashPassword('Customer@2024!');
  const customer = await db.user.create({
    data: { name: 'Demo Customer', username: 'customer', email: 'customer@vps-platform.local',
      passwordHash: customerHash, role: 'USER', status: 'ACTIVE', emailVerified: true },
  });

  // Create IP pool and some IPs
  const pool = await db.ipPool.create({
    data: {
      name: 'main-v4', family: 4, cidr: '10.0.0.0/24',
      gateway: '10.0.0.1', dnsPrimary: '1.1.1.1', dnsSecondary: '8.8.8.8',
    },
  });
  for (let i = 2; i < 30; i++) {
    await db.ipAddress.create({
      data: { poolId: pool.id, address: `10.0.0.${i}`, family: 4, state: 'AVAILABLE' },
    });
  }
  const pool6 = await db.ipPool.create({
    data: {
      name: 'main-v6', family: 6, cidr: 'fd00::/64',
      gateway: 'fd00::1', dnsPrimary: '2606:4700:4700::1111', dnsSecondary: '2606:4700:4700::1001',
    },
  });
  for (let i = 2; i < 12; i++) {
    await db.ipAddress.create({
      data: { poolId: pool6.id, address: `fd00::${i}`, family: 6, state: 'AVAILABLE' },
    });
  }

  // Create nodes
  const nodes = [
    { name: 'in-mum-01', hostname: 'node01.dc-mumbai.local', ipAddress: '10.10.0.11',
      apiEndpoint: 'https://node01.dc-mumbai.local:8006', region: 'Mumbai', datacenter: 'Mumbai-DC1',
      provider: 'PROXMOX' as const, cpuCapacity: 96, ramCapacityMb: 256 * 1024, storageCapacityGb: 4096, bandwidthMbps: 10000 },
    { name: 'in-del-02', hostname: 'node02.dc-delhi.local', ipAddress: '10.10.0.12',
      apiEndpoint: 'https://node02.dc-delhi.local:8006', region: 'Delhi', datacenter: 'Delhi-DC1',
      provider: 'PROXMOX' as const, cpuCapacity: 64, ramCapacityMb: 192 * 1024, storageCapacityGb: 2048, bandwidthMbps: 10000 },
    { name: 'us-tx-01', hostname: 'node03.dc-dallas.local', ipAddress: '10.10.0.13',
      apiEndpoint: 'https://node03.dc-dallas.local:8006', region: 'Dallas', datacenter: 'Dallas-DC1',
      provider: 'PROXMOX' as const, cpuCapacity: 128, ramCapacityMb: 384 * 1024, storageCapacityGb: 8192, bandwidthMbps: 40000 },
  ];
  for (const n of nodes) {
    await db.node.create({ data: { ...n, enabled: true, maintenanceMode: false, health: 'ONLINE', lastHeartbeat: new Date() } });
  }

  // Create plans
  const plans = [
    { name: 'Starter VPS', cpu: 2, ramMb: 4096, diskGb: 80, bandwidthMbps: 2000, priceMonthly: 5.0, setupFee: 0 },
    { name: 'Standard VPS', cpu: 4, ramMb: 8192, diskGb: 160, bandwidthMbps: 4000, priceMonthly: 15.0, setupFee: 0 },
    { name: 'Performance VPS', cpu: 8, ramMb: 16384, diskGb: 320, bandwidthMbps: 8000, priceMonthly: 35.0, setupFee: 0 },
    { name: 'Enterprise VPS', cpu: 16, ramMb: 32768, diskGb: 640, bandwidthMbps: 16000, priceMonthly: 75.0, setupFee: 0 },
  ];
  for (const p of plans) {
    await db.vpsPlan.create({
      data: { ...p, ipv4Included: true, ipv6Included: true, region: 'global', enabled: true },
    });
  }

  // Create OS templates
  const osList = [
    { name: 'Ubuntu 24.04 LTS', distribution: 'ubuntu', version: '24.04', providerTemplateId: 'ubuntu-2404' },
    { name: 'Ubuntu 22.04 LTS', distribution: 'ubuntu', version: '22.04', providerTemplateId: 'ubuntu-2204' },
    { name: 'Debian 13', distribution: 'debian', version: '13', providerTemplateId: 'debian-13' },
    { name: 'Debian 12', distribution: 'debian', version: '12', providerTemplateId: 'debian-12' },
    { name: 'AlmaLinux 9', distribution: 'almalinux', version: '9', providerTemplateId: 'almalinux-9' },
    { name: 'Rocky Linux 9', distribution: 'rocky', version: '9', providerTemplateId: 'rocky-9' },
    { name: 'Windows Server 2022', distribution: 'windows', version: '2022', providerTemplateId: 'win-2022' },
    // Proxmox provider templates
    { name: 'Proxmox VE 8.2', distribution: 'proxmox', version: '8.2', providerTemplateId: 'pve-ve-8.2' },
    { name: 'Proxmox VE 8.1', distribution: 'proxmox', version: '8.1', providerTemplateId: 'pve-ve-8.1' },
    { name: 'Ubuntu 24.04 Cloud-Init (Proxmox)', distribution: 'ubuntu', version: '24.04', providerTemplateId: 'pve-ubuntu-2404-cloudinit' },
    { name: 'Ubuntu 22.04 Cloud-Init (Proxmox)', distribution: 'ubuntu', version: '22.04', providerTemplateId: 'pve-ubuntu-2204-cloudinit' },
    { name: 'Debian 12 Cloud-Init (Proxmox)', distribution: 'debian', version: '12', providerTemplateId: 'pve-debian-12-cloudinit' },
    { name: 'AlmaLinux 9 Cloud-Init (Proxmox)', distribution: 'almalinux', version: '9', providerTemplateId: 'pve-almalinux-9-cloudinit' },
    { name: 'Rocky Linux 9 Cloud-Init (Proxmox)', distribution: 'rocky', version: '9', providerTemplateId: 'pve-rocky-9-cloudinit' },
    { name: 'Windows Server 2022 VirtIO (Proxmox)', distribution: 'windows', version: '2022', providerTemplateId: 'pve-win-2022-virtio' },
  ];
  for (const os of osList) {
    await db.operatingSystem.create({ data: { ...os, architecture: 'x86_64', available: true } });
  }

  // Create a pre-existing VPS for the demo customer (so the customer dashboard isn't empty)
  const n1 = await db.node.findFirst({ where: { name: 'in-mum-01' } });
  const ubuntu = await db.operatingSystem.findFirst({ where: { name: 'Ubuntu 24.04 LTS' } });
  const starterPlan = await db.vpsPlan.findFirst({ where: { name: 'Starter VPS' } });
  const ip = await db.ipAddress.findFirst({ where: { state: 'AVAILABLE', family: 4 } });

  if (n1 && ubuntu && starterPlan && ip) {
    const rootPassword = generateRootPassword(24);
    const rootPasswordHash = await hashPassword(rootPassword);
    const sshKey = generateSshKeyPair('web-prod-01');
    const vps = await db.vps.create({
      data: {
        name: 'web-prod-01',
        hostname: 'web-prod-01',
        description: 'Customer production web server',
        ownerId: customer.id,
        assignedToId: customer.id,
        planId: starterPlan.id,
        nodeId: n1.id,
        osId: ubuntu.id,
        cpu: 2, ramMb: 4096, diskGb: 80, bandwidthMbps: 2000,
        ipv4: ip.address,
        gateway: '10.0.0.1',
        dnsPrimary: '1.1.1.1',
        dnsSecondary: '8.8.8.8',
        reverseDns: 'web-prod-01.vps-platform.local',
        rootPasswordHash,
        sshKeyFingerprint: sshKey.fingerprint,
        sshPublicKey: sshKey.publicKey,
        status: 'RUNNING',
        autoStart: true,
        monitoringEnabled: true,
        providerResourceId: `qemu-existing-${Date.now()}`,
        lastBootedAt: new Date(Date.now() - 86400 * 1000 * 3),
        uptimeSeconds: 86400 * 3,
      },
    });
    await db.ipAddress.update({ where: { id: ip.id }, data: { state: 'ASSIGNED', vpsId: vps.id } });

    await db.notification.create({
      data: {
        userId: customer.id, type: 'VPS_ASSIGNED',
        title: 'Welcome to your VPS Platform',
        message: 'A VPS "web-prod-01" has been provisioned for your account and is now running. Use the panel to start, stop, restart, monitor, or open the console.',
      },
    });

    // Seed some metrics for charts
    const now = Date.now();
    for (let i = 30; i >= 0; i--) {
      const t = now - i * 60 * 1000;
      await db.vpsMetric.create({
        data: {
          vpsId: vps.id,
          cpuUsage: 15 + 25 * Math.sin(t / 1000000) + Math.random() * 10,
          ramUsage: 35 + 15 * Math.sin(t / 2000000) + Math.random() * 8,
          diskUsage: 42 + Math.random() * 5,
          netInKbps: 500 + 300 * Math.sin(t / 1000000) + Math.random() * 200,
          netOutKbps: 250 + 200 * Math.cos(t / 1000000) + Math.random() * 150,
          collectedAt: new Date(t),
        },
      });
    }
  }

  // Settings defaults
  const defaultSettings = [
    { key: 'site.name', value: 'DeUp-VPS Platform' },
    { key: 'site.support_email', value: 'support@vps-platform.local' },
    { key: 'customer.no_provision_message', value: 'VPS provisioning is managed by administrators. Contact support or your hosting administrator to request a VPS.' },
    { key: 'auth.registration_enabled', value: 'true' },
    { key: 'auth.email_verification_required', value: 'true' },
  ];
  for (const s of defaultSettings) {
    await db.setting.upsert({ where: { key: s.key }, update: { value: s.value }, create: s });
  }

  return NextResponse.json({
    success: true,
    message: 'Database seeded',
    credentials: {
      superAdmin: { email: 'admin@vps-platform.local', password: 'Admin@2024!' },
      staff: { email: 'staff@vps-platform.local', password: 'Staff@2024!' },
      customer: { email: 'customer@vps-platform.local', password: 'Customer@2024!' },
    },
  });
  } catch (err: any) {
    console.error('SEED ERROR:', err?.message, err?.stack);
    return NextResponse.json({ success: false, error: 'INTERNAL_ERROR', message: err?.message, stack: err?.stack }, { status: 500 });
  }
}
