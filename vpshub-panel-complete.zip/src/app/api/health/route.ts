import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET() {
  const health: Record<string, { status: string }> = {};
  try {
    await db.$queryRaw`SELECT 1`;
    health.db = { status: 'OK' };
  } catch {
    health.db = { status: 'ERROR' };
  }
  try {
    const r = await fetch('http://localhost:3003/health');
    if (r.ok) health.realtime = { status: 'OK' };
    else health.realtime = { status: 'DEGRADED' };
  } catch {
    health.realtime = { status: 'OFFLINE' };
  }
  const allOk = Object.values(health).every(h => h.status === 'OK');
  return NextResponse.json({ status: allOk ? 'ok' : 'degraded', services: health, ts: Date.now() },
    { status: allOk ? 200 : 503 });
}
