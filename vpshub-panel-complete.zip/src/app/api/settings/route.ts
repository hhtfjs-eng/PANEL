import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// PUBLIC settings — safe to expose without authentication (powers the brand
// name on the login page, shells, and page title). Only whitelisted keys are
// returned; everything else stays behind /api/admin/settings (auth required).
const PUBLIC_KEYS = new Set([
  'site.name',
  'site.support_email',
  'site.youtube_url',
  'site.discord_url',
  'site.watermark_text',
  'site.owner_credit',
  'site.made_by_url',
  'auth.hero_top',
  'auth.hero_bottom',
  'auth.hero_description',
  'customer.no_provision_message',
  'auth.registration_enabled',
  'auth.email_verification_required',
]);

export async function GET() {
  try {
    const settings = await db.setting.findMany({ where: { key: { in: [...PUBLIC_KEYS] } } });
    const map: Record<string, string> = {};
    for (const s of settings) map[s.key] = s.value;
    return NextResponse.json({ success: true, data: map }, {
      headers: { 'Cache-Control': 'no-store' },
    });
  } catch {
    return NextResponse.json({ success: true, data: {} }, {
      headers: { 'Cache-Control': 'no-store' },
    });
  }
}
