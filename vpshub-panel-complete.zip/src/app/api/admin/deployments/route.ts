import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requirePermission } from '@/lib/auth';

export async function GET(req: NextRequest) {
  const auth = await requirePermission('deployments.view');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });

  const url = new URL(req.url);
  const state = url.searchParams.get('state') || '';
  const page = parseInt(url.searchParams.get('page') || '1');
  const pageSize = parseInt(url.searchParams.get('pageSize') || '20');

  const where = state ? { state: state as any } : {};

  const [total, jobs] = await Promise.all([
    db.deploymentJob.count({ where }),
    db.deploymentJob.findMany({
      where,
      include: {
        vps: { select: { id: true, name: true, hostname: true, owner: { select: { email: true } } } },
        initiatedBy: { select: { email: true, username: true } },
        steps: { orderBy: { createdAt: 'asc' } },
      },
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * pageSize,
      take: pageSize,
    }),
  ]);

  return NextResponse.json({
    success: true,
    data: jobs,
    pagination: { page, pageSize, total, totalPages: Math.ceil(total / pageSize) },
  });
}
