import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requirePermission } from '@/lib/auth';

interface RouteParams { params: Promise<{ id: string }> }

export async function GET(req: NextRequest, ctx: RouteParams) {
  const auth = await requirePermission('deployments.view');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const { id } = await ctx.params;

  const job = await db.deploymentJob.findUnique({
    where: { id },
    include: {
      vps: { select: { id: true, name: true, hostname: true, owner: { select: { email: true } } } },
      initiatedBy: { select: { email: true, username: true } },
      steps: { orderBy: { createdAt: 'asc' } },
    },
  });
  if (!job) return NextResponse.json({ success: false, error: 'NOT_FOUND' }, { status: 404 });

  return NextResponse.json({ success: true, data: job });
}
