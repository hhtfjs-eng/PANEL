import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { requirePermission, writeAudit } from '@/lib/auth';

export async function GET() {
  const auth = await requirePermission('os.view');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const list = await db.operatingSystem.findMany({ orderBy: { createdAt: 'desc' } });
  return NextResponse.json({ success: true, data: list });
}

const OsSchema = z.object({
  name: z.string().min(1).max(100),
  distribution: z.string().min(1),
  version: z.string().min(1),
  providerTemplateId: z.string().optional(),
  architecture: z.string().default('x86_64'),
  available: z.boolean().default(true),
  regionRestrictions: z.string().optional(),
  nodeRestrictions: z.string().optional(),
});

export async function POST(req: NextRequest) {
  const auth = await requirePermission('os.create');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const body = await req.json();

  // Bulk-add the Proxmox template catalog (idempotent upserts by name)
  if (body.action === 'seed_proxmox') {
    const templates = [
      { name: 'Proxmox VE 8.2', distribution: 'proxmox', version: '8.2', providerTemplateId: 'pve-ve-8.2' },
      { name: 'Proxmox VE 8.1', distribution: 'proxmox', version: '8.1', providerTemplateId: 'pve-ve-8.1' },
      { name: 'Ubuntu 24.04 Cloud-Init (Proxmox)', distribution: 'ubuntu', version: '24.04', providerTemplateId: 'pve-ubuntu-2404-cloudinit' },
      { name: 'Ubuntu 22.04 Cloud-Init (Proxmox)', distribution: 'ubuntu', version: '22.04', providerTemplateId: 'pve-ubuntu-2204-cloudinit' },
      { name: 'Debian 12 Cloud-Init (Proxmox)', distribution: 'debian', version: '12', providerTemplateId: 'pve-debian-12-cloudinit' },
      { name: 'AlmaLinux 9 Cloud-Init (Proxmox)', distribution: 'almalinux', version: '9', providerTemplateId: 'pve-almalinux-9-cloudinit' },
      { name: 'Rocky Linux 9 Cloud-Init (Proxmox)', distribution: 'rocky', version: '9', providerTemplateId: 'pve-rocky-9-cloudinit' },
      { name: 'Windows Server 2022 VirtIO (Proxmox)', distribution: 'windows', version: '2022', providerTemplateId: 'pve-win-2022-virtio' },
    ];
    let added = 0;
    for (const t of templates) {
      const existing = await db.operatingSystem.findUnique({ where: { name: t.name } });
      if (!existing) {
        await db.operatingSystem.create({ data: { ...t, architecture: 'x86_64', available: true } });
        added++;
      }
    }
    await writeAudit({
      actorId: auth.user!.id, actorRole: auth.user!.role,
      action: 'OS_PROXMOX_TEMPLATES_SEEDED', metadata: { added, total: templates.length },
    });
    return NextResponse.json({ success: true, data: { added, total: templates.length } });
  }

  const parsed = OsSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ success: false, error: 'VALIDATION_ERROR' }, { status: 400 });
  const os = await db.operatingSystem.create({ data: parsed.data });
  await writeAudit({
    actorId: auth.user!.id, actorRole: auth.user!.role,
    targetId: os.id, action: 'OS_CREATED', metadata: { name: os.name },
  });
  return NextResponse.json({ success: true, data: { id: os.id } });
}
