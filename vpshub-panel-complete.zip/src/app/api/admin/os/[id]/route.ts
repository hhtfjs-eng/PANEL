import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requirePermission, writeAudit } from '@/lib/auth';

interface RouteParams { params: Promise<{ id: string }> }

export async function PATCH(req: NextRequest, ctx: RouteParams) {
  const auth = await requirePermission('os.edit');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const { id } = await ctx.params;
  const body = await req.json();
  const allowed = ['name', 'distribution', 'version', 'providerTemplateId',
    'architecture', 'available', 'regionRestrictions', 'nodeRestrictions'];
  const patch: any = {};
  for (const f of allowed) if (body[f] !== undefined) patch[f] = body[f];
  const os = await db.operatingSystem.update({ where: { id }, data: patch });
  await writeAudit({
    actorId: auth.user!.id, actorRole: auth.user!.role,
    targetId: id, action: 'OS_UPDATED', metadata: patch,
  });
  return NextResponse.json({ success: true, data: { id: os.id } });
}

export async function DELETE(req: NextRequest, ctx: RouteParams) {
  const auth = await requirePermission('os.delete');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const { id } = await ctx.params;
  const vpsCount = await db.vps.count({ where: { osId: id, status: { notIn: ['DELETED'] } } });
  if (vpsCount > 0) return NextResponse.json({ success: false, error: 'OS_IN_USE' }, { status: 400 });
  await db.operatingSystem.delete({ where: { id } });
  await writeAudit({
    actorId: auth.user!.id, actorRole: auth.user!.role,
    targetId: id, action: 'OS_DELETED',
  });
  return NextResponse.json({ success: true });
}
