import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { requirePermission, writeAudit } from '@/lib/auth';

export async function GET() {
  const auth = await requirePermission('plans.view');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const plans = await db.vpsPlan.findMany({ orderBy: { createdAt: 'desc' } });
  return NextResponse.json({ success: true, data: plans });
}

const PlanSchema = z.object({
  name: z.string().min(1).max(100),
  cpu: z.number().int().min(1).max(64),
  ramMb: z.number().int().min(512).max(262144),
  diskGb: z.number().int().min(10).max(2048),
  bandwidthMbps: z.number().int().min(10).max(10000),
  ipv4Included: z.boolean().default(true),
  ipv6Included: z.boolean().default(true),
  region: z.string().optional(),
  priceMonthly: z.number().min(0).default(0),
  setupFee: z.number().min(0).default(0),
  enabled: z.boolean().default(true),
});

export async function POST(req: NextRequest) {
  const auth = await requirePermission('plans.create');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const body = await req.json();
  const parsed = PlanSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ success: false, error: 'VALIDATION_ERROR' }, { status: 400 });
  const plan = await db.vpsPlan.create({ data: parsed.data });
  await writeAudit({
    actorId: auth.user!.id, actorRole: auth.user!.role,
    targetId: plan.id, action: 'PLAN_CREATED', metadata: { name: plan.name },
  });
  return NextResponse.json({ success: true, data: { id: plan.id } });
}
