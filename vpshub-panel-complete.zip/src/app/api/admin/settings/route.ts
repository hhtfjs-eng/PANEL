import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requirePermission, writeAudit } from '@/lib/auth';

export async function GET() {
  const auth = await requirePermission('settings.view');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const settings = await db.setting.findMany();
  const map: Record<string, string> = {};
  for (const s of settings) map[s.key] = s.value;
  return NextResponse.json({ success: true, data: map });
}

export async function PATCH(req: NextRequest) {
  const auth = await requirePermission('settings.edit');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const body = await req.json();
  // body: { key, value } | { updates: { key: value, ... } }
  if (body.updates && typeof body.updates === 'object') {
    for (const [k, v] of Object.entries(body.updates)) {
      await db.setting.upsert({ where: { key: k }, update: { value: String(v) }, create: { key: k, value: String(v) } });
    }
  } else if (body.key && body.value !== undefined) {
    await db.setting.upsert({
      where: { key: body.key },
      update: { value: String(body.value) },
      create: { key: body.key, value: String(body.value) },
    });
  }
  await writeAudit({
    actorId: auth.user!.id, actorRole: auth.user!.role,
    action: 'SETTINGS_CHANGED',
    metadata: body,
  });
  return NextResponse.json({ success: true });
}
