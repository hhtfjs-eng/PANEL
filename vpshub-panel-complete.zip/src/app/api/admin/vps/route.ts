import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { requirePermission, writeAudit, generateToken, generateRootPassword, hashPassword, generateSshKeyPair } from '@/lib/auth';
import { processDeployment } from '@/lib/workers/deployment-worker';
import { emitNotification } from '@/lib/realtime';

// =================================================================
// ADMIN-ONLY VPS CREATION
// =================================================================
// Customers are FORBIDDEN from creating VPS — backend rejects
// any non-admin/non-staff caller with INSUFFICIENT_PERMISSIONS,
// regardless of any "hidden" UI state.
// =================================================================

const CreateVpsSchema = z.object({
  ownerId: z.string().min(1),
  name: z.string().min(1).max(100),
  // Optional — when omitted, derived from the owner's name (no spaces,
  // lowercase) so SSH shows root@ownername as the owner requested.
  hostname: z.string().max(100).optional(),
  description: z.string().optional(),
  planId: z.string().optional(),
  cpu: z.number().int().min(1).max(64),
  ramMb: z.number().int().min(512).max(262144),
  diskGb: z.number().int().min(10).max(2048),
  bandwidthMbps: z.number().int().min(10).max(10000),
  nodeId: z.string().min(1),
  osId: z.string().min(1),
  ipv4: z.string().optional(),
  ipv6: z.string().optional(),
  gateway: z.string().optional(),
  dnsPrimary: z.string().optional(),
  dnsSecondary: z.string().optional(),
  reverseDns: z.string().optional(),
  rootPassword: z.string().optional(),
  sshKeyFingerprint: z.string().optional(),
  autoStart: z.boolean().default(true),
  monitoringEnabled: z.boolean().default(true),
  // Auto-suspend policy: null/0/undefined = Lifetime; N = suspend in N days
  autoSuspendDays: z.number().int().min(1).max(3650).nullable().optional(),
  idempotencyKey: z.string().optional(),
});

export async function GET(req: NextRequest) {
  const auth = await requirePermission('vps.view');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });

  const url = new URL(req.url);
  const search = url.searchParams.get('search') || '';
  const status = url.searchParams.get('status') || '';
  const ownerId = url.searchParams.get('ownerId') || '';
  const page = parseInt(url.searchParams.get('page') || '1');
  const pageSize = parseInt(url.searchParams.get('pageSize') || '20');

  // Never show deleted VPS in the default list
  const where = {
    ...(status ? { status: status as any } : { status: { notIn: ['DELETED'] } }),
    ...(ownerId ? { ownerId } : {}),
    ...(search ? {
      OR: [
        { name: { contains: search } },
        { hostname: { contains: search } },
        { ipv4: { contains: search } },
      ],
    } : {}),
  };

  const [total, vpsList] = await Promise.all([
    db.vps.count({ where }),
    db.vps.findMany({
      where,
      include: {
        node: true, os: true, plan: true,
        owner: { select: { id: true, name: true, email: true, username: true } },
      },
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * pageSize,
      take: pageSize,
    }),
  ]);

  return NextResponse.json({
    success: true,
    data: vpsList,
    pagination: { page, pageSize, total, totalPages: Math.ceil(total / pageSize) },
  });
}

// =================================================================
// CREATE VPS — admin/staff only
// =================================================================
export async function POST(req: NextRequest) {
  // CRITICAL — this check is what enforces "admin-only provisioning"
  try {
    const auth = await requirePermission('vps.create');
    if (!auth.ok) {
      return NextResponse.json({ success: false, error: 'INSUFFICIENT_PERMISSIONS' }, { status: 403 });
    }

    const body = await req.json();
    const parsed = CreateVpsSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { success: false, error: 'VALIDATION_ERROR', details: parsed.error.flatten() },
        { status: 400 }
      );
    }
    const data = parsed.data;

    // Coerce empty strings to undefined for optional / foreign-key fields so
    // Prisma doesn't trip on FK violations (e.g. planId='' would fail P2003).
    // Also normalizes empty optionals so the DB stores NULL, not ''.
    const cleanStr = (v: string | undefined | null): string | undefined =>
      (v === undefined || v === null || v.trim() === '') ? undefined : v;
    const planId = cleanStr(data.planId);
    const ipv4 = cleanStr(data.ipv4);
    const ipv6 = cleanStr(data.ipv6);
    const gateway = cleanStr(data.gateway);
    const dnsPrimary = cleanStr(data.dnsPrimary);
    const dnsSecondary = cleanStr(data.dnsSecondary);
    const reverseDns = cleanStr(data.reverseDns);
    const sshKeyFingerprint = cleanStr(data.sshKeyFingerprint);
    const rootPasswordPlain = cleanStr(data.rootPassword);

    // Validate owner
    const owner = await db.user.findUnique({ where: { id: data.ownerId } });
    if (!owner) return NextResponse.json({ success: false, error: 'OWNER_NOT_FOUND' }, { status: 404 });
    if (owner.status !== 'ACTIVE') return NextResponse.json({ success: false, error: 'OWNER_NOT_ACTIVE' }, { status: 400 });

    // Hostname — defaults to the owner's name with all spaces removed
    // (kept verbatim otherwise) so the SSH login reads root@ownername.
    const sanitizeHostname = (s: string) => s.trim().replace(/\s+/g, '') || 'vps';
    const hostname = sanitizeHostname(cleanStr(data.hostname) || owner.name);

    // Validate node (online, enabled, not in maintenance)
    const node = await db.node.findUnique({ where: { id: data.nodeId } });
    if (!node) return NextResponse.json({ success: false, error: 'NODE_NOT_FOUND' }, { status: 404 });
    if (!node.enabled) return NextResponse.json({ success: false, error: 'NODE_DISABLED' }, { status: 400 });
    if (node.maintenanceMode) return NextResponse.json({ success: false, error: 'NODE_MAINTENANCE' }, { status: 400 });
    if (node.health === 'OFFLINE') return NextResponse.json({ success: false, error: 'NODE_OFFLINE' }, { status: 400 });

    // Validate OS availability
    const os = await db.operatingSystem.findUnique({ where: { id: data.osId } });
    if (!os) return NextResponse.json({ success: false, error: 'OS_NOT_FOUND' }, { status: 404 });
    if (!os.available) return NextResponse.json({ success: false, error: 'OS_UNAVAILABLE' }, { status: 400 });

    // Validate node capacity (sum of VPS on node vs node capacity)
    const vpsOnNode = await db.vps.aggregate({
      where: { nodeId: node.id, status: { notIn: ['DELETED'] } },
      _sum: { cpu: true, ramMb: true, diskGb: true },
    });
    const usedCpu = vpsOnNode._sum.cpu || 0;
    const usedRam = vpsOnNode._sum.ramMb || 0;
    const usedDisk = vpsOnNode._sum.diskGb || 0;
    if (usedCpu + data.cpu > node.cpuCapacity) {
      return NextResponse.json({ success: false, error: 'NODE_CPU_FULL' }, { status: 400 });
    }
    if (usedRam + data.ramMb > node.ramCapacityMb) {
      return NextResponse.json({ success: false, error: 'NODE_RAM_FULL' }, { status: 400 });
    }
    if (usedDisk + data.diskGb > node.storageCapacityGb) {
      return NextResponse.json({ success: false, error: 'NODE_STORAGE_FULL' }, { status: 400 });
    }

    // Idempotency — prevent duplicate creation from double-clicks
    const idempotencyKey = data.idempotencyKey || generateToken(16);
    const existingJob = await db.deploymentJob.findUnique({ where: { idempotencyKey } });
    if (existingJob) {
      return NextResponse.json({
        success: true, data: { vpsId: existingJob.vpsId, jobId: existingJob.id, idempotent: true },
      });
    }

    // Generate root password if not supplied (cleaned empty string → undefined → auto-generate)
    const rootPassword = rootPasswordPlain || generateRootPassword(24);
    const rootPasswordHash = await hashPassword(rootPassword);

    // Auto-generate an ED25519 SSH keypair for this VPS (shown in the customer overview)
    const sshKey = generateSshKeyPair(`${hostname}`);

    // Create the VPS record FIRST, then queue the deployment job.
    // Cleaned values: empty strings → undefined so Prisma doesn't trip on FK
    // constraints or insert '' where NULL is expected.
    const vps = await db.vps.create({
      data: {
        name: data.name,
        hostname,
        description: cleanStr(data.description),
        ownerId: owner.id,
        assignedToId: owner.id,
        planId,
        nodeId: node.id,
        osId: os.id,
        cpu: data.cpu,
        ramMb: data.ramMb,
        diskGb: data.diskGb,
        bandwidthMbps: data.bandwidthMbps,
        ipv4,
        ipv6,
        gateway: gateway || (node.region ? '10.0.0.1' : undefined),
        dnsPrimary: dnsPrimary || '1.1.1.1',
        dnsSecondary: dnsSecondary || '8.8.8.8',
        reverseDns,
        rootPasswordHash,
        // Initial root password kept retrievable so the owner/admin can see
        // it in the panel's SSH Access card (auto-generated at creation).
        rootPasswordPlain: rootPassword,
        sshUsername: 'root',
        sshKeyFingerprint: sshKeyFingerprint || sshKey.fingerprint,
        sshPublicKey: sshKey.publicKey,
        status: 'QUEUED',
        autoStart: data.autoStart,
        monitoringEnabled: data.monitoringEnabled,
        autoSuspendAt: data.autoSuspendDays
          ? new Date(Date.now() + data.autoSuspendDays * 86400 * 1000)
          : null, // Lifetime
      },
    });

    // Create deployment job
    const job = await db.deploymentJob.create({
      data: {
        vpsId: vps.id,
        initiatedById: auth.user!.id,
        state: 'QUEUED',
        idempotencyKey,
      },
    });

    // Initial activity log
    await db.vpsActivity.create({
      data: {
        vpsId: vps.id,
        action: 'VPS_CREATED',
        actor: auth.user!.email,
        message: `VPS created by ${auth.user!.email} for ${owner.email}`,
      },
    });

    // Audit
    await writeAudit({
      actorId: auth.user!.id,
      actorRole: auth.user!.role,
      targetId: vps.id,
      action: 'VPS_CREATED',
      metadata: { vpsName: vps.name, ownerId: owner.id, ownerEmail: owner.email, jobId: job.id },
    });

    // Notify the customer
    const notification = await db.notification.create({
      data: {
        userId: owner.id,
        type: 'VPS_ASSIGNED',
        title: 'New VPS Assigned to Your Account',
        message: `A VPS "${vps.name}" has been assigned to your account and is now provisioning. You will be notified when deployment completes.`,
        metadata: JSON.stringify({ vpsId: vps.id, jobId: job.id }),
      },
    });
    // Realtime emit is best-effort — never let socket.io downtime break a deploy
    emitNotification(owner.id, {
      type: 'VPS_ASSIGNED',
      title: notification.title,
      message: notification.message,
    }).catch(() => {});

    // Kick off background deployment — fire and forget
    processDeployment(job.id).catch(err => {
      console.error('Deployment worker error:', err);
    });

    return NextResponse.json({
      success: true,
      data: {
        vpsId: vps.id,
        jobId: job.id,
        idempotencyKey,
        status: 'QUEUED',
      },
    });
  } catch (err: any) {
    // Defensive: ANY error in the deploy flow must return a JSON response,
    // never an HTML 500 page (which the frontend api client would surface
    // as a misleading "server is briefly unavailable" message).
    console.error('Deploy POST error:', err);
    const code = (typeof err?.code === 'string' && err.code.startsWith('P2')) ? 'INTERNAL_ERROR' : 'INTERNAL_ERROR';
    const message = err?.message || 'Unexpected error during VPS creation';
    return NextResponse.json(
      { success: false, error: code, message, details: err?.code ? { prismaCode: err.code } : undefined },
      { status: 500 }
    );
  }
}
