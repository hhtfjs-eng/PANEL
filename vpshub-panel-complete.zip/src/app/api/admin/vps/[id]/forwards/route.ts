import { NextRequest, NextResponse } from 'next/server';
import { requirePermission, writeAudit } from '@/lib/auth';
import { createPortForward, deletePortForward, listPortForwards } from '@/lib/port-forwarding';

// Admin-side port forwarding for any VPS. Same 5-per-person limit applies
// (counted on the VPS owner), so admins can manage but not inflate.

interface RouteParams { params: Promise<{ id: string }> }

// GET — list forwards + owner usage
export async function GET(_req: NextRequest, ctx: RouteParams) {
  const auth = await requirePermission('vps.view');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const { id } = await ctx.params;

  const data = await listPortForwards(id);
  if (!data) return NextResponse.json({ success: false, error: 'NOT_FOUND' }, { status: 404 });
  return NextResponse.json({ success: true, data });
}

// POST — add a forward
export async function POST(req: NextRequest, ctx: RouteParams) {
  const auth = await requirePermission('vps.view');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const { id } = await ctx.params;

  const body = await req.json().catch(() => ({}));
  const result = await createPortForward(id, auth.user!, body);
  if (!result.ok) {
    const status = ['NOT_FOUND', 'NO_NODE'].includes(result.error) ? 404 :
      ['PORT_LIMIT_REACHED', 'PORT_IN_USE', 'INVALID_PROTOCOL', 'INVALID_INTERNAL_PORT', 'INVALID_EXTERNAL_PORT', 'NO_FREE_PORT'].includes(result.error) ? 400 : 502;
    return NextResponse.json({ success: false, error: result.error, message: (result as any).message }, { status });
  }

  await writeAudit({
    actorId: auth.user!.id, actorRole: auth.user!.role,
    targetId: id, action: 'PORT_FORWARD_ADDED',
    metadata: { protocol: result.forward.protocol, externalPort: result.forward.externalPort, internalPort: result.forward.internalPort },
  });

  return NextResponse.json({ success: true, data: result.forward });
}

// DELETE ?forwardId= — remove a forward
export async function DELETE(req: NextRequest, ctx: RouteParams) {
  const auth = await requirePermission('vps.view');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const { id } = await ctx.params;

  const forwardId = new URL(req.url).searchParams.get('forwardId') || '';
  if (!forwardId) return NextResponse.json({ success: false, error: 'MISSING_FORWARD_ID' }, { status: 400 });

  const result = await deletePortForward(id, forwardId, auth.user!);
  if (!result.ok) return NextResponse.json({ success: false, error: result.error }, { status: 404 });

  await writeAudit({
    actorId: auth.user!.id, actorRole: auth.user!.role,
    targetId: id, action: 'PORT_FORWARD_REMOVED',
    metadata: { forwardId },
  });

  return NextResponse.json({ success: true });
}
