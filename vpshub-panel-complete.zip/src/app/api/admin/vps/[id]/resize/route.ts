import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { requirePermission, writeAudit } from '@/lib/auth';
import { getProvider } from '@/lib/providers/proxmox';
import { emitNotification, emitVpsStatus } from '@/lib/realtime';

interface RouteParams { params: Promise<{ id: string }> }

const ResizeSchema = z.object({
  cpu: z.number().int().min(1).max(64).optional(),
  ramMb: z.number().int().min(512).max(262144).optional(),
  diskGb: z.number().int().min(10).max(2048).optional(),
  bandwidthMbps: z.number().int().min(10).max(10000).optional(),
});

export async function POST(req: NextRequest, ctx: RouteParams) {
  const auth = await requirePermission('vps.resize');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const { id } = await ctx.params;

  const body = await req.json();
  const parsed = ResizeSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ success: false, error: 'VALIDATION_ERROR' }, { status: 400 });
  }

  const vps = await db.vps.findUnique({ where: { id }, include: { node: true } });
  if (!vps) return NextResponse.json({ success: false, error: 'NOT_FOUND' }, { status: 404 });
  if (!vps.providerResourceId || !vps.node) {
    return NextResponse.json({ success: false, error: 'VPS_NOT_PROVISIONED' }, { status: 400 });
  }

  const newCpu = parsed.data.cpu ?? vps.cpu;
  const newRam = parsed.data.ramMb ?? vps.ramMb;
  const newDisk = parsed.data.diskGb ?? vps.diskGb;

  // Validate node capacity (delta-aware)
  const totalOnNode = await db.vps.aggregate({
    where: { nodeId: vps.node.id, status: { notIn: ['DELETED'] } },
    _sum: { cpu: true, ramMb: true, diskGb: true },
  });
  const usedCpu = (totalOnNode._sum.cpu || 0) - vps.cpu + newCpu;
  const usedRam = (totalOnNode._sum.ramMb || 0) - vps.ramMb + newRam;
  const usedDisk = (totalOnNode._sum.diskGb || 0) - vps.diskGb + newDisk;
  if (usedCpu > vps.node.cpuCapacity || usedRam > vps.node.ramCapacityMb || usedDisk > vps.node.storageCapacityGb) {
    return NextResponse.json({ success: false, error: 'NODE_CAPACITY_EXCEEDED' }, { status: 400 });
  }

  try {
    await getProvider(vps.node.provider, vps.node).resizeVPS(vps.providerResourceId, newCpu, newRam, newDisk);
  } catch (err: any) {
    return NextResponse.json({ success: false, error: 'PROVIDER_RESIZE_FAILED' }, { status: 502 });
  }

  await db.vps.update({
    where: { id },
    data: {
      cpu: newCpu,
      ramMb: newRam,
      diskGb: newDisk,
      bandwidthMbps: parsed.data.bandwidthMbps ?? vps.bandwidthMbps,
    },
  });

  await db.vpsActivity.create({
    data: { vpsId: id, action: 'VPS_RESIZED', actor: auth.user!.email,
      message: `Resized to ${newCpu} CPU / ${newRam}MB RAM / ${newDisk}GB disk` },
  });

  await writeAudit({
    actorId: auth.user!.id, actorRole: auth.user!.role,
    targetId: id, action: 'VPS_RESIZED',
    metadata: { from: { cpu: vps.cpu, ramMb: vps.ramMb, diskGb: vps.diskGb },
                to: { cpu: newCpu, ramMb: newRam, diskGb: newDisk } },
  });

  emitVpsStatus(id, vps.status);
  if (vps.ownerId) {
    const n = await db.notification.create({
      data: { userId: vps.ownerId, type: 'VPS_RESIZED',
        title: 'VPS Resized', message: `Your VPS "${vps.name}" resources have been updated.` },
    });
    emitNotification(vps.ownerId, { type: 'VPS_RESIZED', title: n.title, message: n.message });
  }

  return NextResponse.json({ success: true });
}
