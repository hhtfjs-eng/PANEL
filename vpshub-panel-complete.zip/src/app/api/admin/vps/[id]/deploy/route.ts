import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requirePermission, writeAudit } from '@/lib/auth';
import { processDeployment } from '@/lib/workers/deployment-worker';
import { emitNotification } from '@/lib/realtime';

interface RouteParams { params: Promise<{ id: string }> }

// Redeploy (kick off the deployment pipeline again, e.g. after a failure)
export async function POST(req: NextRequest, ctx: RouteParams) {
  const auth = await requirePermission('vps.deploy');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const { id } = await ctx.params;

  const vps = await db.vps.findUnique({ where: { id } });
  if (!vps) return NextResponse.json({ success: false, error: 'NOT_FOUND' }, { status: 404 });

  if (vps.status === 'PROVISIONING' || vps.status === 'QUEUED') {
    return NextResponse.json({ success: false, error: 'VPS_ALREADY_DEPLOYING' }, { status: 409 });
  }

  // Create a new deployment job
  const job = await db.deploymentJob.create({
    data: {
      vpsId: vps.id,
      initiatedById: auth.user!.id,
      state: 'QUEUED',
      idempotencyKey: `deploy-${vps.id}-${Date.now()}`,
    },
  });

  await db.vps.update({ where: { id: vps.id }, data: { status: 'QUEUED' } });

  await writeAudit({
    actorId: auth.user!.id, actorRole: auth.user!.role,
    targetId: vps.id, action: 'VPS_DEPLOYMENT_STARTED',
    metadata: { jobId: job.id },
  });

  processDeployment(job.id).catch(err => console.error('Deploy worker err:', err));

  return NextResponse.json({ success: true, data: { jobId: job.id } });
}
