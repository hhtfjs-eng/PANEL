import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requirePermission, writeAudit } from '@/lib/auth';
import { emitNotification, emitVpsStatus } from '@/lib/realtime';

interface RouteParams { params: Promise<{ id: string }> }

export async function POST(req: NextRequest, ctx: RouteParams) {
  const auth = await requirePermission('vps.unsuspend');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const { id } = await ctx.params;

  const vps = await db.vps.findUnique({ where: { id } });
  if (!vps) return NextResponse.json({ success: false, error: 'NOT_FOUND' }, { status: 404 });

  await db.vps.update({
    where: { id },
    data: { status: 'STOPPED', suspendReason: null },
  });
  emitVpsStatus(id, 'STOPPED');

  await db.vpsActivity.create({
    data: { vpsId: id, action: 'VPS_UNSUSPENDED', actor: auth.user!.email, message: 'Unsuspended' },
  });

  await writeAudit({
    actorId: auth.user!.id, actorRole: auth.user!.role,
    targetId: id, action: 'VPS_UNSUSPENDED',
  });

  if (vps.ownerId) {
    const n = await db.notification.create({
      data: {
        userId: vps.ownerId,
        type: 'VPS_UNSUSPENDED',
        title: 'VPS Unsuspended',
        message: `Your VPS "${vps.name}" has been unsuspended. You can now start it from your panel.`,
      },
    });
    emitNotification(vps.ownerId, { type: 'VPS_UNSUSPENDED', title: n.title, message: n.message });
  }

  return NextResponse.json({ success: true, status: 'STOPPED' });
}
