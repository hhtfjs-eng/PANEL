import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requirePermission, writeAudit } from '@/lib/auth';
import { emitNotification, emitVpsStatus } from '@/lib/realtime';

interface RouteParams { params: Promise<{ id: string }> }

export async function POST(req: NextRequest, ctx: RouteParams) {
  const auth = await requirePermission('vps.suspend');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const { id } = await ctx.params;
  const body = await req.json();
  const reason = body.reason as string;

  const vps = await db.vps.findUnique({ where: { id } });
  if (!vps) return NextResponse.json({ success: false, error: 'NOT_FOUND' }, { status: 404 });

  await db.vps.update({
    where: { id },
    data: { status: 'SUSPENDED', suspendReason: reason },
  });
  emitVpsStatus(id, 'SUSPENDED');

  await db.vpsActivity.create({
    data: { vpsId: id, action: 'VPS_SUSPENDED', actor: auth.user!.email, message: `Suspended: ${reason}` },
  });

  await writeAudit({
    actorId: auth.user!.id, actorRole: auth.user!.role,
    targetId: id, action: 'VPS_SUSPENDED',
    metadata: { reason },
  });

  if (vps.ownerId) {
    const n = await db.notification.create({
      data: {
        userId: vps.ownerId,
        type: 'VPS_SUSPENDED',
        title: 'VPS Suspended',
        message: `Your VPS "${vps.name}" has been suspended. Reason: ${reason}`,
      },
    });
    emitNotification(vps.ownerId, { type: 'VPS_SUSPENDED', title: n.title, message: n.message });
  }

  return NextResponse.json({ success: true, status: 'SUSPENDED' });
}
