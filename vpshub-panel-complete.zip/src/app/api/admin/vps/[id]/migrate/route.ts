import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requirePermission, writeAudit } from '@/lib/auth';
import { getProvider } from '@/lib/providers/proxmox';
import { emitNotification, emitVpsStatus } from '@/lib/realtime';

interface RouteParams { params: Promise<{ id: string }> }

export async function POST(req: NextRequest, ctx: RouteParams) {
  const auth = await requirePermission('vps.migrate');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const { id } = await ctx.params;
  const body = await req.json();
  const destNodeId = body.destNodeId as string;

  const vps = await db.vps.findUnique({ where: { id }, include: { node: true } });
  if (!vps) return NextResponse.json({ success: false, error: 'NOT_FOUND' }, { status: 404 });
  if (!vps.providerResourceId || !vps.node) {
    return NextResponse.json({ success: false, error: 'VPS_NOT_PROVISIONED' }, { status: 400 });
  }

  const destNode = await db.node.findUnique({ where: { id: destNodeId } });
  if (!destNode) return NextResponse.json({ success: false, error: 'NODE_NOT_FOUND' }, { status: 404 });
  if (!destNode.enabled || destNode.maintenanceMode || destNode.health === 'OFFLINE') {
    return NextResponse.json({ success: false, error: 'DESTINATION_NODE_UNAVAILABLE' }, { status: 400 });
  }

  // Validate destination capacity
  const totalOnDest = await db.vps.aggregate({
    where: { nodeId: destNode.id, status: { notIn: ['DELETED'] } },
    _sum: { cpu: true, ramMb: true, diskGb: true },
  });
  if ((totalOnDest._sum.cpu || 0) + vps.cpu > destNode.cpuCapacity ||
      (totalOnDest._sum.ramMb || 0) + vps.ramMb > destNode.ramCapacityMb ||
      (totalOnDest._sum.diskGb || 0) + vps.diskGb > destNode.storageCapacityGb) {
    return NextResponse.json({ success: false, error: 'DEST_NODE_CAPACITY_EXCEEDED' }, { status: 400 });
  }

  // Perform provider migration FIRST, then update DB (per spec)
  try {
    await getProvider(vps.node.provider, vps.node).migrateVPS(vps.providerResourceId, destNode.apiEndpoint || destNode.hostname);
  } catch (err: any) {
    return NextResponse.json({ success: false, error: 'MIGRATION_FAILED', message: err?.message }, { status: 502 });
  }

  await db.vps.update({ where: { id }, data: { nodeId: destNode.id } });
  emitVpsStatus(id, vps.status);

  await db.vpsActivity.create({
    data: { vpsId: id, action: 'VPS_MIGRATED', actor: auth.user!.email,
      message: `Migrated from ${vps.node.name} to ${destNode.name}` },
  });

  await writeAudit({
    actorId: auth.user!.id, actorRole: auth.user!.role,
    targetId: id, action: 'VPS_MIGRATED',
    metadata: { from: vps.node.name, to: destNode.name },
  });

  if (vps.ownerId) {
    const n = await db.notification.create({
      data: { userId: vps.ownerId, type: 'VPS_MIGRATED',
        title: 'VPS Migrated', message: `Your VPS "${vps.name}" was migrated to ${destNode.name}.` },
    });
    emitNotification(vps.ownerId, { type: 'VPS_MIGRATED', title: n.title, message: n.message });
  }

  return NextResponse.json({ success: true });
}
