import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requirePermission, writeAudit, generateRootPassword, hashPassword, generateSshKeyPair } from '@/lib/auth';
import { processDeployment } from '@/lib/workers/deployment-worker';
import { emitNotification } from '@/lib/realtime';
import { getProvider } from '@/lib/providers/proxmox';

interface RouteParams { params: Promise<{ id: string }> }

export async function GET(req: NextRequest, ctx: RouteParams) {
  const auth = await requirePermission('vps.view');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const { id } = await ctx.params;

  let vps = await db.vps.findUnique({
    where: { id },
    include: {
      node: true, os: true, plan: true,
      owner: { select: { id: true, name: true, email: true, username: true } },
      assignedTo: { select: { id: true, name: true, email: true, username: true } },
      ips: true,
    },
  });
  if (!vps) return NextResponse.json({ success: false, error: 'NOT_FOUND' }, { status: 404 });

  // Lazy backfill — legacy VPS created before auto SSH credentials: generate
  // keypair + initial root password + ownername hostname (root@ownername).
  if (!vps.sshPublicKey || !vps.rootPasswordPlain || !vps.sshUsername) {
    const sshKey = generateSshKeyPair(vps.hostname || 'vps');
    const ownerHostname = (vps.owner?.name || 'vps').trim().replace(/\s+/g, '') || 'vps';
    vps = await db.vps.update({
      where: { id: vps.id },
      data: {
        sshPublicKey: vps.sshPublicKey || sshKey.publicKey,
        sshKeyFingerprint: vps.sshKeyFingerprint || sshKey.fingerprint,
        hostname: ownerHostname,
        rootPasswordPlain: vps.rootPasswordPlain || generateRootPassword(24),
        sshUsername: vps.sshUsername || 'root',
      },
      include: {
        node: true, os: true, plan: true,
        owner: { select: { id: true, name: true, email: true, username: true } },
        assignedTo: { select: { id: true, name: true, email: true, username: true } },
        ips: true,
      },
    });
  }

  // Never leak the password hash to any client
  const { rootPasswordHash, ...safeVps } = vps as any;
  return NextResponse.json({ success: true, data: safeVps });
}

// Update hostname / description / owner / IP
export async function PATCH(req: NextRequest, ctx: RouteParams) {
  const auth = await requirePermission('vps.assign');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const { id } = await ctx.params;
  const body = await req.json();

  const patch: any = {};
  if (body.hostname !== undefined) patch.hostname = body.hostname;
  if (body.description !== undefined) patch.description = body.description;
  if (body.name !== undefined) patch.name = body.name;
  if (body.ipv4 !== undefined) patch.ipv4 = body.ipv4;
  if (body.ipv6 !== undefined) patch.ipv6 = body.ipv6;
  if (body.reverseDns !== undefined) patch.reverseDns = body.reverseDns;

  // Auto-suspend policy: null = Lifetime, N days = future timestamp
  if (body.autoSuspendDays !== undefined) {
    patch.autoSuspendAt = body.autoSuspendDays === null || body.autoSuspendDays === 0
      ? null
      : new Date(Date.now() + Number(body.autoSuspendDays) * 86400 * 1000);
  }
  if (body.autoSuspendAt !== undefined) {
    patch.autoSuspendAt = body.autoSuspendAt ? new Date(body.autoSuspendAt) : null;
  }

  // Change owner (reassign)
  if (body.assignedToId !== undefined) {
    const newOwner = await db.user.findUnique({ where: { id: body.assignedToId } });
    if (!newOwner) return NextResponse.json({ success: false, error: 'OWNER_NOT_FOUND' }, { status: 404 });
    patch.assignedToId = newOwner.id;
    patch.ownerId = newOwner.id;
    await writeAudit({
      actorId: auth.user!.id, actorRole: auth.user!.role,
      targetId: id, action: 'VPS_OWNER_CHANGED',
      metadata: { newOwnerId: newOwner.id, newOwnerEmail: newOwner.email },
    });
  }

  const vps = await db.vps.update({ where: { id }, data: patch });
  await writeAudit({
    actorId: auth.user!.id, actorRole: auth.user!.role,
    targetId: id, action: 'VPS_UPDATED', metadata: patch,
  });
  return NextResponse.json({ success: true, data: { id: vps.id } });
}

// Delete — hard delete. Related activity/metrics/deployment jobs/console
// sessions are removed by cascade; audit logs survive (plain string targetId).
export async function DELETE(req: NextRequest, ctx: RouteParams) {
  const auth = await requirePermission('vps.delete');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const { id } = await ctx.params;

  const vps = await db.vps.findUnique({ where: { id }, include: { node: true, ips: true } });
  if (!vps) return NextResponse.json({ success: false, error: 'NOT_FOUND' }, { status: 404 });

  // Stop the VPS via provider
  if (vps.providerResourceId && vps.node) {
    try { await getProvider(vps.node.provider, vps.node).deleteVPS(vps.providerResourceId); }
    catch (err) { console.error('Provider delete failed:', err); }
  }

  // Release IPs back to the pool
  await db.ipAddress.updateMany({
    where: { vpsId: vps.id },
    data: { state: 'AVAILABLE', vpsId: null },
  });

  // Hard-delete the VPS row (cascades: activity, metrics, deployment jobs,
  // console sessions, state history). Lists refresh with the row gone.
  await db.vps.delete({ where: { id } });

  await writeAudit({
    actorId: auth.user!.id, actorRole: auth.user!.role,
    targetId: id, action: 'VPS_DELETED',
  });

  // Notify owner
  if (vps.ownerId) {
    const n = await db.notification.create({
      data: {
        userId: vps.ownerId,
        type: 'VPS_DELETED',
        title: 'VPS Deleted',
        message: `Your VPS "${vps.name}" has been deleted by an administrator.`,
      },
    });
    emitNotification(vps.ownerId, { type: 'VPS_DELETED', title: n.title, message: n.message });
  }

  return NextResponse.json({ success: true });
}
