import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requirePermission, writeAudit } from '@/lib/auth';
import { getProvider } from '@/lib/providers/proxmox';
import { emitNotification, emitVpsStatus } from '@/lib/realtime';

interface RouteParams { params: Promise<{ id: string }> }

export async function POST(req: NextRequest, ctx: RouteParams) {
  const auth = await requirePermission('vps.reinstall');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const { id } = await ctx.params;
  const body = await req.json();
  const osId = body.osId as string;

  const vps = await db.vps.findUnique({ where: { id }, include: { node: true, os: true } });
  if (!vps) return NextResponse.json({ success: false, error: 'NOT_FOUND' }, { status: 404 });
  if (!vps.providerResourceId || !vps.node) {
    return NextResponse.json({ success: false, error: 'VPS_NOT_PROVISIONED' }, { status: 400 });
  }

  const targetOs = osId ? await db.operatingSystem.findUnique({ where: { id: osId } }) : vps.os;
  if (!targetOs) return NextResponse.json({ success: false, error: 'OS_NOT_FOUND' }, { status: 404 });

  await db.vps.update({ where: { id }, data: { status: 'REINSTALLING' } });
  emitVpsStatus(id, 'REINSTALLING');

  try {
    await getProvider(vps.node.provider, vps.node).reinstallVPS(vps.providerResourceId, targetOs.providerTemplateId || targetOs.id);
    await db.vps.update({ where: { id }, data: { status: 'RUNNING', osId: targetOs.id, lastBootedAt: new Date() } });
    emitVpsStatus(id, 'RUNNING');
  } catch (err: any) {
    await db.vps.update({ where: { id }, data: { status: 'ERROR' } });
    return NextResponse.json({ success: false, error: 'REINSTALL_FAILED', message: err?.message }, { status: 502 });
  }

  await db.vpsActivity.create({
    data: { vpsId: id, action: 'VPS_REINSTALLED', actor: auth.user!.email, message: `Reinstalled with ${targetOs.name}` },
  });
  await writeAudit({
    actorId: auth.user!.id, actorRole: auth.user!.role,
    targetId: id, action: 'VPS_REINSTALLED',
    metadata: { os: targetOs.name },
  });

  if (vps.ownerId) {
    const n = await db.notification.create({
      data: {
        userId: vps.ownerId,
        type: 'VPS_REINSTALLED',
        title: 'VPS Reinstalled',
        message: `Your VPS "${vps.name}" was reinstalled with ${targetOs.name}.`,
      },
    });
    emitNotification(vps.ownerId, { type: 'VPS_REINSTALLED', title: n.title, message: n.message });
  }

  return NextResponse.json({ success: true });
}
