import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requirePermission } from '@/lib/auth';

// GET /api/admin/support — list all tickets with customer info + last message
export async function GET(req: NextRequest) {
  const auth = await requirePermission('support.view');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });

  const url = new URL(req.url);
  const status = url.searchParams.get('status') || 'all';
  const priority = url.searchParams.get('priority') || 'all';

  const where: any = {};
  if (status !== 'all') where.status = status;
  if (priority !== 'all') where.priority = priority;

  const tickets = await db.supportTicket.findMany({
    where,
    include: {
      user: { select: { id: true, name: true, email: true, username: true, role: true } },
      assignedTo: { select: { id: true, name: true } },
      _count: { select: { messages: true } },
      messages: {
        orderBy: { createdAt: 'desc' },
        take: 1,
        select: { body: true, isStaff: true, createdAt: true },
      },
    },
    orderBy: { updatedAt: 'desc' },
  });

  return NextResponse.json({ success: true, data: tickets });
}
