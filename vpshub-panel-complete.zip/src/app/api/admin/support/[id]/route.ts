import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { requirePermission, writeAudit } from '@/lib/auth';

interface RouteParams { params: Promise<{ id: string }> }

// GET /api/admin/support/[id] — ticket detail with full message thread
export async function GET(req: NextRequest, ctx: RouteParams) {
  const auth = await requirePermission('support.view');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });

  const { id } = await ctx.params;
  const ticket = await db.supportTicket.findUnique({
    where: { id },
    include: {
      user: { select: { id: true, name: true, email: true, username: true, role: true } },
      assignedTo: { select: { id: true, name: true } },
      messages: {
        orderBy: { createdAt: 'asc' },
        include: { user: { select: { name: true, role: true } } },
      },
    },
  });
  if (!ticket) return NextResponse.json({ success: false, error: 'NOT_FOUND' }, { status: 404 });
  return NextResponse.json({ success: true, data: ticket });
}

const ActionSchema = z.object({
  action: z.enum(['reply', 'status', 'assign', 'priority']),
  body: z.string().min(1).max(8000).optional(),
  status: z.enum(['open', 'pending', 'resolved', 'closed']).optional(),
  priority: z.enum(['low', 'normal', 'high', 'urgent']).optional(),
});

// POST /api/admin/support/[id] — staff reply / status / assignment
export async function POST(req: NextRequest, ctx: RouteParams) {
  const auth = await requirePermission('support.manage');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });

  const { id } = await ctx.params;
  const ticket = await db.supportTicket.findUnique({ where: { id }, include: { user: { select: { id: true, name: true } } } });
  if (!ticket) return NextResponse.json({ success: false, error: 'NOT_FOUND' }, { status: 404 });

  const body = await req.json();
  const parsed = ActionSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ success: false, error: 'VALIDATION_ERROR' }, { status: 400 });

  const { action } = parsed.data;

  if (action === 'reply') {
    if (!parsed.data.body) return NextResponse.json({ success: false, error: 'VALIDATION_ERROR' }, { status: 400 });
    const message = await db.supportMessage.create({
      data: {
        ticketId: id,
        userId: auth.user!.id,
        body: parsed.data.body,
        isStaff: true,
      },
    });
    // Re-open the thread so the customer sees the staff response; assign to responder
    await db.supportTicket.update({
      where: { id },
      data: { status: 'pending', assignedToId: auth.user!.id },
    });
    // Notify the customer about the staff reply
    await db.notification.create({
      data: {
        userId: ticket.userId,
        type: 'SUPPORT_REPLY',
        title: `Support reply: ${ticket.subject}`,
        message: `Support staff responded to your ticket "${ticket.subject}". Open Support → Tickets to read the reply and continue the conversation.`,
        metadata: JSON.stringify({ ticketId: id }),
      },
    });
    await writeAudit({
      actorId: auth.user!.id, actorRole: auth.user!.role,
      targetId: id, action: 'TICKET_REPLIED', metadata: { messageId: message.id },
    });
    return NextResponse.json({ success: true, data: { messageId: message.id } });
  }

  if (action === 'status') {
    if (!parsed.data.status) return NextResponse.json({ success: false, error: 'VALIDATION_ERROR' }, { status: 400 });
    await db.supportTicket.update({ where: { id }, data: { status: parsed.data.status } });
    await writeAudit({
      actorId: auth.user!.id, actorRole: auth.user!.role,
      targetId: id, action: 'TICKET_STATUS_CHANGED', metadata: { status: parsed.data.status },
    });
    return NextResponse.json({ success: true, data: { status: parsed.data.status } });
  }

  if (action === 'priority') {
    if (!parsed.data.priority) return NextResponse.json({ success: false, error: 'VALIDATION_ERROR' }, { status: 400 });
    await db.supportTicket.update({ where: { id }, data: { priority: parsed.data.priority } });
    return NextResponse.json({ success: true, data: { priority: parsed.data.priority } });
  }

  if (action === 'assign') {
    await db.supportTicket.update({ where: { id }, data: { assignedToId: auth.user!.id } });
    return NextResponse.json({ success: true, data: { assignedToId: auth.user!.id } });
  }

  return NextResponse.json({ success: false, error: 'INVALID_ACTION' }, { status: 400 });
}

// DELETE /api/admin/support/[id] — permanently delete a ticket and its thread
export async function DELETE(req: NextRequest, ctx: RouteParams) {
  const auth = await requirePermission('support.manage');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });

  const { id } = await ctx.params;
  const ticket = await db.supportTicket.findUnique({
    where: { id },
    include: { _count: { select: { messages: true } } },
  });
  if (!ticket) return NextResponse.json({ success: false, error: 'NOT_FOUND' }, { status: 404 });

  // SupportMessage rows cascade-delete with the ticket (schema onDelete: Cascade)
  await db.supportTicket.delete({ where: { id } });
  await writeAudit({
    actorId: auth.user!.id, actorRole: auth.user!.role,
    targetId: id, action: 'TICKET_DELETED',
    metadata: { subject: ticket.subject, messages: ticket._count.messages, owner: ticket.userId },
  });
  return NextResponse.json({ success: true });
}
