import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { requirePermission, writeAudit, generateToken } from '@/lib/auth';

export async function GET() {
  const auth = await requirePermission('nodes.view');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });

  const nodes = await db.node.findMany({
    include: {
      _count: { select: { vps: { where: { status: { notIn: ['DELETED'] } } } } },
    },
    orderBy: { createdAt: 'desc' },
  });

  // Compute per-node capacity usage
  const nodesWithStats = await Promise.all(nodes.map(async (n) => {
    const usage = await db.vps.aggregate({
      where: { nodeId: n.id, status: { notIn: ['DELETED'] } },
      _sum: { cpu: true, ramMb: true, diskGb: true },
    });
    return {
      id: n.id, name: n.name, hostname: n.hostname, ipAddress: n.ipAddress,
      provider: n.provider, apiEndpoint: n.apiEndpoint, region: n.region,
      datacenter: n.datacenter,
      cpuCapacity: n.cpuCapacity, ramCapacityMb: n.ramCapacityMb,
      storageCapacityGb: n.storageCapacityGb, bandwidthMbps: n.bandwidthMbps,
      enabled: n.enabled, maintenanceMode: n.maintenanceMode,
      health: n.health, lastHeartbeat: n.lastHeartbeat,
      vpsCount: n._count.vps,
      usedCpu: usage._sum.cpu || 0,
      usedRamMb: usage._sum.ramMb || 0,
      usedDiskGb: usage._sum.diskGb || 0,
      createdAt: n.createdAt,
    };
  }));

  return NextResponse.json({ success: true, data: nodesWithStats });
}

const CreateNodeSchema = z.object({
  name: z.string().min(1).max(100),
  hostname: z.string().min(1),
  ipAddress: z.string().min(1),
  provider: z.string().default('PROXMOX'),
  apiEndpoint: z.string().optional(),
  region: z.string().optional(),
  datacenter: z.string().optional(),
  cpuCapacity: z.number().int().min(1).max(1024),
  ramCapacityMb: z.number().int().min(1024).max(1048576),
  storageCapacityGb: z.number().int().min(10).max(32768),
  bandwidthMbps: z.number().int().min(100).max(100000),
  enabled: z.boolean().default(true),
  maintenanceMode: z.boolean().default(false),
});

export async function POST(req: NextRequest) {
  const auth = await requirePermission('nodes.create');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });

  const body = await req.json();
  const parsed = CreateNodeSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ success: false, error: 'VALIDATION_ERROR', details: parsed.error.flatten() }, { status: 400 });
  }
  const data = parsed.data;
  const existing = await db.node.findUnique({ where: { name: data.name } });
  if (existing) return NextResponse.json({ success: false, error: 'NODE_NAME_TAKEN' }, { status: 409 });

  const node = await db.node.create({
    data: {
      ...data,
      provider: data.provider as any,
      health: 'ONLINE',
      lastHeartbeat: new Date(),
    },
  });
  await writeAudit({
    actorId: auth.user!.id, actorRole: auth.user!.role,
    targetId: node.id, action: 'NODE_CREATED',
    metadata: { name: node.name, region: node.region },
  });
  return NextResponse.json({ success: true, data: { id: node.id } });
}
