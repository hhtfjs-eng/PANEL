import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requirePermission, writeAudit } from '@/lib/auth';

interface RouteParams { params: Promise<{ id: string }> }

export async function GET(req: NextRequest, ctx: RouteParams) {
  const auth = await requirePermission('nodes.view');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const { id } = await ctx.params;
  const node = await db.node.findUnique({ where: { id } });
  if (!node) return NextResponse.json({ success: false, error: 'NOT_FOUND' }, { status: 404 });
  return NextResponse.json({ success: true, data: node });
}

export async function PATCH(req: NextRequest, ctx: RouteParams) {
  const auth = await requirePermission('nodes.edit');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const { id } = await ctx.params;
  const body = await req.json();
  const allowed = ['name', 'hostname', 'ipAddress', 'provider', 'apiEndpoint', 'region', 'datacenter',
                   'cpuCapacity', 'ramCapacityMb', 'storageCapacityGb', 'bandwidthMbps',
                   'enabled', 'maintenanceMode'];
  const patch: any = {};
  for (const f of allowed) if (body[f] !== undefined) patch[f] = body[f];

  const node = await db.node.update({ where: { id }, data: patch });
  await writeAudit({
    actorId: auth.user!.id, actorRole: auth.user!.role,
    targetId: id, action: 'NODE_UPDATED', metadata: patch,
  });
  return NextResponse.json({ success: true, data: { id: node.id } });
}

export async function DELETE(req: NextRequest, ctx: RouteParams) {
  const auth = await requirePermission('nodes.delete');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const { id } = await ctx.params;
  // Prevent deletion if VPS still on it
  const vpsCount = await db.vps.count({ where: { nodeId: id, status: { notIn: ['DELETED'] } } });
  if (vpsCount > 0) {
    return NextResponse.json({ success: false, error: 'NODE_HAS_VPS' }, { status: 400 });
  }
  await db.node.delete({ where: { id } });
  await writeAudit({
    actorId: auth.user!.id, actorRole: auth.user!.role,
    targetId: id, action: 'NODE_DELETED',
  });
  return NextResponse.json({ success: true });
}

// Maintenance toggle / heartbeat ping
export async function POST(req: NextRequest, ctx: RouteParams) {
  const { id } = await ctx.params;
  const body = await req.json();
  const action = body.action as string;

  if (action === 'maintenance') {
    const auth = await requirePermission('nodes.edit');
    if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
    const node = await db.node.update({
      where: { id }, data: { maintenanceMode: body.enabled, health: body.enabled ? 'MAINTENANCE' : 'ONLINE' },
    });
    await writeAudit({
      actorId: auth.user!.id, actorRole: auth.user!.role,
      targetId: id, action: body.enabled ? 'NODE_MAINTENANCE_ENABLED' : 'NODE_MAINTENANCE_DISABLED',
    });
    return NextResponse.json({ success: true, data: { maintenanceMode: node.maintenanceMode, health: node.health } });
  }

  if (action === 'heartbeat') {
    // Internal call from monitoring system or admin
    const auth = await requirePermission('nodes.edit');
    if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
    const node = await db.node.update({
      where: { id }, data: { lastHeartbeat: new Date(), health: 'ONLINE' },
    });
    return NextResponse.json({ success: true, data: { lastHeartbeat: node.lastHeartbeat } });
  }

  if (action === 'toggle_enabled') {
    const auth = await requirePermission('nodes.edit');
    if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
    const node = await db.node.update({
      where: { id }, data: { enabled: body.enabled },
    });
    await writeAudit({
      actorId: auth.user!.id, actorRole: auth.user!.role,
      targetId: id, action: body.enabled ? 'NODE_ENABLED' : 'NODE_DISABLED',
    });
    return NextResponse.json({ success: true, data: { enabled: node.enabled } });
  }

  return NextResponse.json({ success: false, error: 'INVALID_ACTION' }, { status: 400 });
}
