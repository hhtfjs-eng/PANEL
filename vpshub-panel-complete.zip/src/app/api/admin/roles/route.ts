import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { requirePermission, writeAudit } from '@/lib/auth';
import {
  ALL_PERMISSIONS, BUILTIN_ROLES, invalidateRoleCache,
  permissionsForRole, Permission,
} from '@/lib/permissions';

const PermissionArray = z.array(z.string().refine(
  (p): p is Permission => (ALL_PERMISSIONS as string[]).includes(p),
  { message: 'Unknown permission key' },
));

const RoleSchema = z.object({
  name: z.string().min(2).max(50),
  description: z.string().max(200).optional(),
  permissions: PermissionArray.min(1, 'A role needs at least one permission'),
});

// key derived from the display name: "Support Manager" → "SUPPORT_MANAGER"
function keyFor(name: string): string {
  return name.trim().toUpperCase().replace(/[^A-Z0-9]+/g, '_').replace(/^_+|_+$/g, '') || 'CUSTOM_ROLE';
}

// GET — every role: the 5 built-ins (read-only) + custom roles from the editor
export async function GET() {
  const auth = await requirePermission('staff.manage');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });

  const custom = await db.role.findMany({ where: { isSystem: false }, orderBy: { createdAt: 'asc' } });

  const builtins = BUILTIN_ROLES.map(key => ({
    id: null,
    key,
    name: key.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase()),
    description: key === 'USER' ? 'Customer role (built-in)' : 'Built-in role',
    permissions: permissionsForRole(key as any),
    isSystem: true,
    memberCount: 0, // filled below (count per key)
  }));

  for (const b of builtins) {
    b.memberCount = await db.user.count({ where: { role: b.key } });
  }

  const customs: any[] = [];
  for (const r of custom) {
    let perms: string[] = [];
    try { perms = JSON.parse(r.permissions); } catch { /* ignore */ }
    customs.push({
      id: r.id,
      key: r.key, name: r.name, description: r.description,
      permissions: perms, isSystem: false,
      memberCount: await db.user.count({ where: { role: r.key } }),
    });
  }

  return NextResponse.json({ success: true, data: [...builtins, ...customs] });
}

// POST — create a custom role
export async function POST(req: NextRequest) {
  const auth = await requirePermission('staff.manage');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });

  const parsed = RoleSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ success: false, error: 'VALIDATION_ERROR', details: parsed.error.flatten() }, { status: 400 });
  }

  let key = keyFor(parsed.data.name);
  // Ensure key uniqueness — append a counter if taken
  const clash = await db.role.findUnique({ where: { key } });
  if (clash || BUILTIN_ROLES.includes(key)) {
    let i = 2;
    while (await db.role.findUnique({ where: { key: `${key}_${i}` } })) i++;
    key = `${key}_${i}`;
  }

  const role = await db.role.create({
    data: {
      key,
      name: parsed.data.name.trim(),
      description: parsed.data.description?.trim() || null,
      permissions: JSON.stringify(parsed.data.permissions),
      isSystem: false,
    },
  });
  invalidateRoleCache();

  await writeAudit({
    actorId: auth.user!.id, actorRole: auth.user!.role,
    targetId: role.id, action: 'ROLE_CREATED',
    metadata: { key: role.key, permissions: parsed.data.permissions },
  });

  return NextResponse.json({ success: true, data: { id: role.id, key: role.key } });
}
