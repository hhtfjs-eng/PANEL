import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { requirePermission, writeAudit } from '@/lib/auth';
import { ALL_PERMISSIONS, invalidateRoleCache, Permission } from '@/lib/permissions';

interface RouteParams { params: Promise<{ id: string }> }

const PermissionArray = z.array(z.string().refine(
  (p): p is Permission => (ALL_PERMISSIONS as string[]).includes(p),
  { message: 'Unknown permission key' },
));

const UpdateSchema = z.object({
  name: z.string().min(2).max(50).optional(),
  description: z.string().max(200).optional(),
  permissions: PermissionArray.min(1).optional(),
});

// PATCH — update a custom role (built-ins cannot be edited)
export async function PATCH(req: NextRequest, ctx: RouteParams) {
  const auth = await requirePermission('staff.manage');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const { id } = await ctx.params;

  const role = await db.role.findUnique({ where: { id } });
  if (!role) return NextResponse.json({ success: false, error: 'NOT_FOUND' }, { status: 404 });
  if (role.isSystem) return NextResponse.json({ success: false, error: 'ROLE_IS_SYSTEM' }, { status: 400 });

  const parsed = UpdateSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ success: false, error: 'VALIDATION_ERROR', details: parsed.error.flatten() }, { status: 400 });
  }

  const patch: any = {};
  if (parsed.data.name !== undefined) patch.name = parsed.data.name.trim();
  if (parsed.data.description !== undefined) patch.description = parsed.data.description.trim() || null;
  if (parsed.data.permissions !== undefined) patch.permissions = JSON.stringify(parsed.data.permissions);

  const updated = await db.role.update({ where: { id }, data: patch });
  invalidateRoleCache();

  await writeAudit({
    actorId: auth.user!.id, actorRole: auth.user!.role,
    targetId: id, action: 'ROLE_UPDATED',
    metadata: { key: updated.key, fields: Object.keys(patch) },
  });

  return NextResponse.json({ success: true, data: { id: updated.id, key: updated.key } });
}

// DELETE — remove a custom role. Members are moved back to the USER role first.
export async function DELETE(req: NextRequest, ctx: RouteParams) {
  const auth = await requirePermission('staff.manage');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const { id } = await ctx.params;

  const role = await db.role.findUnique({ where: { id } });
  if (!role) return NextResponse.json({ success: false, error: 'NOT_FOUND' }, { status: 404 });
  if (role.isSystem) return NextResponse.json({ success: false, error: 'ROLE_IS_SYSTEM' }, { status: 400 });

  const members = await db.user.findMany({ where: { role: role.key }, select: { id: true } });
  if (members.length > 0) {
    await db.user.updateMany({ where: { role: role.key }, data: { role: 'USER' } });
    for (const m of members) {
      await writeAudit({
        actorId: auth.user!.id, actorRole: auth.user!.role,
        targetId: m.id, action: 'USER_ROLE_CHANGED',
        metadata: { from: role.key, to: 'USER', reason: 'role deleted' },
      });
    }
  }

  await db.role.delete({ where: { id } });
  invalidateRoleCache();

  await writeAudit({
    actorId: auth.user!.id, actorRole: auth.user!.role,
    targetId: id, action: 'ROLE_DELETED',
    metadata: { key: role.key, movedMembers: members.length },
  });

  return NextResponse.json({ success: true });
}
