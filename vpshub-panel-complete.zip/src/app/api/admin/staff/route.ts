import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { requirePermission, writeAudit, hashPassword } from '@/lib/auth';
import { emailSchema, normalizeEmail } from '@/lib/validators';

export async function GET() {
  const auth = await requirePermission('staff.manage');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const staff = await db.user.findMany({
    where: { role: { in: ['SUPPORT', 'STAFF', 'ADMIN', 'SUPER_ADMIN'] } },
    select: {
      id: true, name: true, username: true, email: true,
      role: true, status: true, lastLogin: true, createdAt: true,
    },
    orderBy: { createdAt: 'asc' },
  });
  return NextResponse.json({ success: true, data: staff });
}

const CreateStaffSchema = z.object({
  name: z.string().min(1),
  username: z.string().min(3).max(30).regex(/^[a-zA-Z0-9_]+$/),
  email: emailSchema,
  role: z.enum(['SUPPORT', 'STAFF', 'ADMIN', 'SUPER_ADMIN']),
  password: z.string().min(8),
});

export async function POST(req: NextRequest) {
  const auth = await requirePermission('staff.manage');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const body = await req.json();
  const parsed = CreateStaffSchema.safeParse(body);
  if (!parsed.success) {
    // Map the FIRST failing field to a specific error code so the UI can say
    // exactly what is wrong instead of a generic "check your values" toast —
    // a silently-failed creation is why the owner later couldn't log in.
    const fields = new Set(parsed.error.issues.map(i => String(i.path[0])));
    const code =
      fields.has('password') ? 'PASSWORD_TOO_SHORT' :
      fields.has('username') ? 'USERNAME_INVALID' :
      fields.has('email') ? 'EMAIL_INVALID' :
      'VALIDATION_ERROR';
    return NextResponse.json({ success: false, error: code }, { status: 400 });
  }
  const { name, username, email, role, password } = parsed.data;
  const normalizedEmail = normalizeEmail(email);
  const exists = await db.user.findFirst({
    where: { OR: [{ email: normalizedEmail }, { username }] },
  });
  if (exists) return NextResponse.json({ success: false, error: 'EMAIL_OR_USERNAME_TAKEN' }, { status: 409 });
  const passwordHash = await hashPassword(password);
  const user = await db.user.create({
    data: { name, username, email: normalizedEmail, role,
      passwordHash, status: 'ACTIVE', emailVerified: true },
  });
  await writeAudit({
    actorId: auth.user!.id, actorRole: auth.user!.role,
    targetId: user.id, action: 'STAFF_CREATED',
    metadata: { email: user.email, role: user.role },
  });
  return NextResponse.json({ success: true, data: { id: user.id } });
}
