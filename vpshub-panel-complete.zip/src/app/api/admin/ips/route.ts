import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { requirePermission, writeAudit } from '@/lib/auth';

export async function GET() {
  const auth = await requirePermission('network.view');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const [pools, ips] = await Promise.all([
    db.ipPool.findMany({ include: { _count: { select: { ips: true } } } }),
    db.ipAddress.findMany({ include: { pool: true, vps: { select: { id: true, name: true } } }, orderBy: { address: 'asc' } }),
  ]);
  return NextResponse.json({ success: true, data: { pools, ips } });
}

const CreatePoolSchema = z.object({
  name: z.string().min(1),
  family: z.number().int().refine(n => n === 4 || n === 6),
  cidr: z.string().min(1),
  gateway: z.string().optional(),
  dnsPrimary: z.string().optional(),
  dnsSecondary: z.string().optional(),
});

const AddIpSchema = z.object({
  poolId: z.string().min(1),
  address: z.string().min(1),
  family: z.number().int(),
});

export async function POST(req: NextRequest) {
  const auth = await requirePermission('network.manage');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const body = await req.json();
  const action = body.action as string;

  if (action === 'create_pool') {
    const parsed = CreatePoolSchema.safeParse(body);
    if (!parsed.success) return NextResponse.json({ success: false, error: 'VALIDATION_ERROR' }, { status: 400 });
    const pool = await db.ipPool.create({ data: parsed.data });
    await writeAudit({
      actorId: auth.user!.id, actorRole: auth.user!.role,
      targetId: pool.id, action: 'IP_POOL_CREATED',
      metadata: { name: pool.name, cidr: pool.cidr },
    });
    return NextResponse.json({ success: true, data: { id: pool.id } });
  }

  if (action === 'add_ip') {
    const parsed = AddIpSchema.safeParse(body);
    if (!parsed.success) return NextResponse.json({ success: false, error: 'VALIDATION_ERROR' }, { status: 400 });
    const ip = await db.ipAddress.create({ data: { ...parsed.data, state: 'AVAILABLE' } });
    await writeAudit({
      actorId: auth.user!.id, actorRole: auth.user!.role,
      targetId: ip.id, action: 'IP_ADDED',
      metadata: { address: ip.address, family: ip.family },
    });
    return NextResponse.json({ success: true, data: { id: ip.id } });
  }

  if (action === 'release') {
    // Release IP from any VPS
    const ipId = body.ipId as string;
    if (!ipId) return NextResponse.json({ success: false, error: 'MISSING_IP_ID' }, { status: 400 });
    await db.ipAddress.update({ where: { id: ipId }, data: { state: 'AVAILABLE', vpsId: null } });
    await writeAudit({
      actorId: auth.user!.id, actorRole: auth.user!.role,
      targetId: ipId, action: 'IP_RELEASED',
    });
    return NextResponse.json({ success: true });
  }

  if (action === 'reserve' || action === 'block') {
    const ipId = body.ipId as string;
    const newState = action === 'reserve' ? 'RESERVED' : 'BLOCKED';
    await db.ipAddress.update({ where: { id: ipId }, data: { state: newState, reservedReason: body.reason } });
    await writeAudit({
      actorId: auth.user!.id, actorRole: auth.user!.role,
      targetId: ipId, action: action.toUpperCase() === 'RESERVE' ? 'IP_RESERVED' : 'IP_BLOCKED',
    });
    return NextResponse.json({ success: true });
  }

  return NextResponse.json({ success: false, error: 'INVALID_ACTION' }, { status: 400 });
}
