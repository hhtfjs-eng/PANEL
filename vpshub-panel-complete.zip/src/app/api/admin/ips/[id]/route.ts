import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requirePermission, writeAudit } from '@/lib/auth';

interface RouteParams { params: Promise<{ id: string }> }

export async function PATCH(req: NextRequest, ctx: RouteParams) {
  const auth = await requirePermission('network.manage');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const { id } = await ctx.params;
  const body = await req.json();
  const patch: any = {};
  if (body.reverseDns !== undefined) patch.reverseDns = body.reverseDns;
  if (body.state !== undefined) patch.state = body.state;
  const ip = await db.ipAddress.update({ where: { id }, data: patch });
  await writeAudit({
    actorId: auth.user!.id, actorRole: auth.user!.role,
    targetId: id, action: 'IP_UPDATED', metadata: patch,
  });
  return NextResponse.json({ success: true, data: { id: ip.id } });
}

export async function DELETE(req: NextRequest, ctx: RouteParams) {
  const auth = await requirePermission('network.manage');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const { id } = await ctx.params;
  await db.ipAddress.delete({ where: { id } });
  await writeAudit({
    actorId: auth.user!.id, actorRole: auth.user!.role,
    targetId: id, action: 'IP_DELETED',
  });
  return NextResponse.json({ success: true });
}
