import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requirePermission, writeAudit } from '@/lib/auth';

export async function GET(req: NextRequest) {
  const auth = await requirePermission('users.view');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });

  const url = new URL(req.url);
  const search = url.searchParams.get('search') || '';
  const status = url.searchParams.get('status') || '';
  const role = url.searchParams.get('role') || '';
  const page = parseInt(url.searchParams.get('page') || '1');
  const pageSize = parseInt(url.searchParams.get('pageSize') || '20');

  const where = {
    ...(status ? { status: status as any } : {}),
    ...(role ? { role: role as any } : {}),
    ...(search ? {
      OR: [
        { name: { contains: search } },
        { username: { contains: search } },
        { email: { contains: search } },
      ],
    } : {}),
  };

  const [total, users] = await Promise.all([
    db.user.count({ where }),
    db.user.findMany({
      where,
      select: {
        id: true, name: true, username: true, email: true,
        role: true, status: true, emailVerified: true,
        lastLogin: true, lastActivity: true, createdAt: true,
        _count: { select: { vpsOwned: true } },
      },
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * pageSize,
      take: pageSize,
    }),
  ]);

  return NextResponse.json({
    success: true,
    data: users.map(u => ({ ...u, vpsCount: u._count.vpsOwned, _count: undefined })),
    pagination: { page, pageSize, total, totalPages: Math.ceil(total / pageSize) },
  });
}

// Admin create user (staff)
export async function POST(req: NextRequest) {
  const auth = await requirePermission('staff.manage');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });

  const body = await req.json();
  const { name, username, email, role, password } = body;
  if (!name || !username || !email || !role || !password) {
    return NextResponse.json({ success: false, error: 'VALIDATION_ERROR' }, { status: 400 });
  }
  const exists = await db.user.findFirst({
    where: { OR: [{ email: email.toLowerCase() }, { username }] },
  });
  if (exists) {
    return NextResponse.json({ success: false, error: 'EMAIL_OR_USERNAME_TAKEN' }, { status: 409 });
  }
  const { hashPassword } = await import('@/lib/auth');
  const passwordHash = await hashPassword(password);
  const user = await db.user.create({
    data: { name, username, email: email.toLowerCase(), role, passwordHash, emailVerified: true, status: 'ACTIVE' },
  });
  await writeAudit({
    actorId: auth.user!.id, actorRole: auth.user!.role,
    targetId: user.id, action: 'STAFF_CREATED',
    metadata: { email, username, role },
  });
  return NextResponse.json({ success: true, data: { id: user.id } });
}
