import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requirePermission, writeAudit, hashPassword, generateToken } from '@/lib/auth';
import { BUILTIN_ROLES } from '@/lib/permissions';
import { emitNotification } from '@/lib/realtime';

interface RouteParams { params: Promise<{ id: string }> }

export async function GET(req: NextRequest, ctx: RouteParams) {
  const auth = await requirePermission('users.view');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const { id } = await ctx.params;

  const user = await db.user.findUnique({
    where: { id },
    select: {
      id: true, name: true, username: true, email: true,
      role: true, status: true, emailVerified: true,
      lastLogin: true, lastActivity: true, createdAt: true, updatedAt: true,
      _count: { select: { vpsOwned: true, vpsAssigned: true, sessions: true } },
    },
  });
  if (!user) return NextResponse.json({ success: false, error: 'NOT_FOUND' }, { status: 404 });

  return NextResponse.json({ success: true, data: user });
}

export async function PATCH(req: NextRequest, ctx: RouteParams) {
  const { id } = await ctx.params;
  const body = await req.json();

  // ── Role change — restricted to staff.manage holders (ADMIN / SUPER_ADMIN) ──
  // users.edit alone (SUPPORT / STAFF) must NEVER be able to grant roles.
  if (body.role !== undefined) {
    const auth = await requirePermission('staff.manage');
    if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });

    const newRole = String(body.role);

    // Role key must be a built-in or an existing custom role (Role Editor)
    const isBuiltin = BUILTIN_ROLES.includes(newRole);
    const customRole = isBuiltin ? null : await db.role.findUnique({ where: { key: newRole } });
    if (!isBuiltin && !customRole) {
      return NextResponse.json({ success: false, error: 'INVALID_ROLE' }, { status: 400 });
    }

    // Guard: you cannot change your own role (prevents accidental lockout)
    if (id === auth.user!.id) {
      return NextResponse.json({ success: false, error: 'CANNOT_CHANGE_OWN_ROLE' }, { status: 400 });
    }

    const target = await db.user.findUnique({ where: { id }, select: { id: true, role: true, name: true } });
    if (!target) return NextResponse.json({ success: false, error: 'NOT_FOUND' }, { status: 404 });

    // Guard: only a SUPER_ADMIN may assign SUPER_ADMIN or touch a SUPER_ADMIN account
    const actorIsSuper = auth.user!.role === 'SUPER_ADMIN';
    if (!actorIsSuper && (newRole === 'SUPER_ADMIN' || target.role === 'SUPER_ADMIN')) {
      return NextResponse.json({ success: false, error: 'ROLE_CHANGE_FORBIDDEN' }, { status: 403 });
    }

    if (target.role === newRole) {
      return NextResponse.json({ success: true, data: { id: target.id } }); // no-op
    }

    await db.user.update({ where: { id }, data: { role: newRole } });
    await writeAudit({
      actorId: auth.user!.id, actorRole: auth.user!.role,
      targetId: id, action: 'USER_ROLE_CHANGED',
      metadata: { from: target.role, to: newRole },
    });
    // Tell the affected user their access level changed
    await db.notification.create({
      data: {
        userId: id,
        type: 'ROLE_CHANGED',
        title: 'Your role was updated',
        message: `An administrator changed your account role from ${target.role} to ${newRole}.`,
      },
    }).catch(() => null);
    await emitNotification(id, {
      type: 'ROLE_CHANGED',
      title: 'Your role was updated',
      message: `An administrator changed your account role from ${target.role} to ${newRole}.`,
    });
    return NextResponse.json({ success: true, data: { id } });
  }

  // ── Other profile fields — users.edit ──
  const auth = await requirePermission('users.edit');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const allowedFields = ['name', 'username', 'email', 'status'];
  const patch: any = {};
  for (const f of allowedFields) if (body[f] !== undefined) patch[f] = body[f];

  const user = await db.user.update({ where: { id }, data: patch });
  await writeAudit({
    actorId: auth.user!.id, actorRole: auth.user!.role,
    targetId: id, action: 'USER_UPDATED',
    metadata: patch,
  });
  return NextResponse.json({ success: true, data: { id: user.id } });
}

export async function DELETE(req: NextRequest, ctx: RouteParams) {
  const auth = await requirePermission('users.delete');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  const { id } = await ctx.params;

  await db.user.update({ where: { id }, data: { status: 'DELETED' } });
  await writeAudit({
    actorId: auth.user!.id, actorRole: auth.user!.role,
    targetId: id, action: 'USER_DELETED',
  });
  return NextResponse.json({ success: true });
}

// Suspend / unsuspend / verify / reset-password action
export async function POST(req: NextRequest, ctx: RouteParams) {
  const { id } = await ctx.params;
  const body = await req.json();
  const action = body.action as string;

  if (action === 'suspend' || action === 'unsuspend') {
    const auth = await requirePermission('users.suspend');
    if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
    const newStatus = action === 'suspend' ? 'SUSPENDED' : 'ACTIVE';
    await db.user.update({ where: { id }, data: { status: newStatus } });
    await writeAudit({
      actorId: auth.user!.id, actorRole: auth.user!.role,
      targetId: id, action: action === 'suspend' ? 'USER_SUSPENDED' : 'USER_UNSUSPENDED',
      metadata: { reason: body.reason },
    });
    return NextResponse.json({ success: true, status: newStatus });
  }

  if (action === 'verify') {
    const auth = await requirePermission('users.edit');
    if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
    await db.user.update({ where: { id }, data: { emailVerified: true, emailVerifyToken: null } });
    await writeAudit({ actorId: auth.user!.id, actorRole: auth.user!.role, targetId: id, action: 'USER_VERIFIED' });
    return NextResponse.json({ success: true });
  }

  if (action === 'reset_password') {
    const auth = await requirePermission('users.reset_password');
    if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
    if (!body.password || body.password.length < 8) {
      return NextResponse.json({ success: false, error: 'PASSWORD_TOO_SHORT' }, { status: 400 });
    }
    const passwordHash = await hashPassword(body.password);
    await db.user.update({ where: { id }, data: { passwordHash } });
    await writeAudit({ actorId: auth.user!.id, actorRole: auth.user!.role, targetId: id, action: 'USER_PASSWORD_RESET' });
    return NextResponse.json({ success: true });
  }

  return NextResponse.json({ success: false, error: 'INVALID_ACTION' }, { status: 400 });
}
