import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requirePermission } from '@/lib/auth';
import { emitNotification } from '@/lib/realtime';

// Auto-suspend sweep — suspends any RUNNING VPS whose autoSuspendAt policy has
// elapsed. Runs inline on this admin-polled endpoint so the policy actually
// executes without an external cron. Cheap: one indexed-ish query on small data.
async function sweepAutoSuspend(): Promise<number> {
  const due = await db.vps.findMany({
    where: {
      autoSuspendAt: { lte: new Date() },
      status: { in: ['RUNNING', 'STOPPED'] },
    },
    select: { id: true, name: true, ownerId: true },
  });
  for (const v of due) {
    await db.vps.update({
      where: { id: v.id },
      data: { status: 'SUSPENDED', suspendReason: 'Auto-suspended — suspension policy elapsed' },
    });
    await db.vpsActivity.create({
      data: {
        vpsId: v.id, action: 'VPS_SUSPENDED', actor: 'system',
        message: 'VPS auto-suspended — suspension policy elapsed',
      },
    });
    if (v.ownerId) {
      const n = await db.notification.create({
        data: {
          userId: v.ownerId, type: 'VPS_SUSPENDED',
          title: 'VPS Auto-Suspended',
          message: `Your VPS "${v.name}" was suspended automatically — its suspension period elapsed. Contact support to renew.`,
        },
      });
      emitNotification(v.ownerId, { type: 'VPS_SUSPENDED', title: n.title, message: n.message });
    }
  }
  return due.length;
}

export async function GET() {
  const auth = await requirePermission('system.health');
  if (!auth.ok) return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });

  await sweepAutoSuspend().catch(() => 0); // never break stats on sweep failure

  const [
    totalNodes, onlineNodes, offlineNodes, maintenanceNodes,
    totalVps, runningVps, stoppedVps, suspendedVps, provisioningVps, failedVps,
    totalUsers, verifiedUsers, unverifiedUsers, suspendedUsers, recentRegistrations,
    activeDeployments, completedDeployments, failedDeployments, queuedDeployments,
  ] = await Promise.all([
    db.node.count(),
    db.node.count({ where: { health: 'ONLINE' } }),
    db.node.count({ where: { health: 'OFFLINE' } }),
    db.node.count({ where: { maintenanceMode: true } }),
    db.vps.count({ where: { status: { notIn: ['DELETED'] } } }),
    db.vps.count({ where: { status: 'RUNNING' } }),
    db.vps.count({ where: { status: 'STOPPED' } }),
    db.vps.count({ where: { status: 'SUSPENDED' } }),
    db.vps.count({ where: { status: { in: ['PROVISIONING', 'QUEUED', 'REINSTALLING', 'REBOOTING'] } } }),
    db.vps.count({ where: { status: 'ERROR' } }),
    db.user.count({ where: { status: { notIn: ['DELETED'] } } }),
    db.user.count({ where: { emailVerified: true } }),
    db.user.count({ where: { emailVerified: false } }),
    db.user.count({ where: { status: 'SUSPENDED' } }),
    db.user.findMany({
      where: { status: { notIn: ['DELETED'] } },
      orderBy: { createdAt: 'desc' },
      take: 5,
      select: { id: true, name: true, email: true, createdAt: true },
    }),
    db.deploymentJob.count({ where: { state: { in: ['QUEUED', 'VALIDATING', 'ALLOCATING', 'CREATING_VM',
      'CONFIGURING', 'INSTALLING_OS', 'CONFIGURING_NETWORK', 'FINALIZING', 'HEALTH_CHECK'] } } }),
    db.deploymentJob.count({ where: { state: 'COMPLETED' } }),
    db.deploymentJob.count({ where: { state: 'FAILED' } }),
    db.deploymentJob.count({ where: { state: 'QUEUED' } }),
  ]);

  // Infrastructure capacity
  const nodes = await db.node.findMany();
  const totalCpuCapacity = nodes.reduce((a, n) => a + n.cpuCapacity, 0);
  const totalRamCapacity = nodes.reduce((a, n) => a + n.ramCapacityMb, 0);
  const totalStorageCapacity = nodes.reduce((a, n) => a + n.storageCapacityGb, 0);

  // Current utilization
  const vpsAgg = await db.vps.aggregate({
    where: { status: { notIn: ['DELETED'] } },
    _sum: { cpu: true, ramMb: true, diskGb: true },
  });

  return NextResponse.json({
    success: true,
    data: {
      infrastructure: {
        totalNodes, onlineNodes, offlineNodes, maintenanceNodes,
        cpuCapacity: totalCpuCapacity, ramCapacityMb: totalRamCapacity, storageCapacityGb: totalStorageCapacity,
        usedCpu: vpsAgg._sum.cpu || 0, usedRamMb: vpsAgg._sum.ramMb || 0, usedDiskGb: vpsAgg._sum.diskGb || 0,
      },
      vps: {
        total: totalVps, running: runningVps, stopped: stoppedVps, suspended: suspendedVps,
        provisioning: provisioningVps, failed: failedVps,
      },
      users: {
        total: totalUsers, verified: verifiedUsers, unverified: unverifiedUsers,
        suspended: suspendedUsers, recentRegistrations,
      },
      deployments: {
        active: activeDeployments, completed: completedDeployments,
        failed: failedDeployments, queued: queuedDeployments,
      },
    },
  });
}
