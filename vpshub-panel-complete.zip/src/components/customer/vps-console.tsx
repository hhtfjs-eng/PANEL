'use client';

import { useEffect, useRef, useState } from 'react';
import { customerApi, friendlyMessage } from '@/lib/frontend/api';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Loader2, Maximize2, Terminal, RefreshCw, AlertCircle, Wifi, WifiOff } from 'lucide-react';
import { io, Socket } from 'socket.io-client';

interface Props {
  vpsId: string;
  running: boolean;
  suspended: boolean;
  hostname?: string;
}

export function VpsConsole({ vpsId, running, suspended, hostname }: Props) {
  const [loading, setLoading] = useState(true);
  const [session, setSession] = useState<{ consoleToken: string; sessionId: string; room: string } | null>(null);
  const [connected, setConnected] = useState(false);
  const [output, setOutput] = useState<string[]>([]);
  const [input, setInput] = useState('');
  const socketRef = useRef<Socket | null>(null);
  const termRef = useRef<HTMLDivElement | null>(null);

  const openSession = async () => {
    setLoading(true);
    setOutput([]);
    const r = await customerApi.console(vpsId);
    if (r.success && r.data) {
      setSession(r.data as any);
    } else {
      setOutput([`Failed to open console: ${friendlyMessage(r)}`]);
    }
    setLoading(false);
  };

  // Open the console session as soon as the VPS is running (mount),
  // so the terminal is live immediately — no manual "Reconnect" needed.
  useEffect(() => {
    if (running && !suspended) openSession();
  }, [vpsId, running, suspended]);

  useEffect(() => {
    if (!session) return;
    // Connect to the realtime mini-service on port 3003 via the gateway.
    // Path must be "/" so Caddy forwards correctly.
    const socket = io('/?XTransformPort=3003', { transports: ['websocket', 'polling'] });
    socketRef.current = socket;

    socket.on('connect', () => {
      setConnected(true);
      socket.emit('subscribe', session.room);
      setOutput(prev => [...prev, '\x1b[32m[connected] console session ready\x1b[0m']);
      setOutput(prev => [...prev, `Welcome to ${hostname || 'VPS'} serial console (root@${hostname || 'vps'}). Type "help" for available commands.`]);
      setOutput(prev => [...prev, '']);
    });

    socket.on('disconnect', () => {
      setConnected(false);
      setOutput(prev => [...prev, '\x1b[31m[disconnected]\x1b[0m']);
    });

    socket.on('console.output', (payload: { data: string }) => {
      setOutput(prev => [...prev, payload.data]);
    });

    return () => {
      socket.disconnect();
      setConnected(false);
    };
  }, [session]);

  // Simulate console output periodically (since the provider is a mock)
  useEffect(() => {
    if (!session || !connected) return;
    const lines = [
      `[${new Date().toISOString()}] systemd[1]: Started Session service.`,
      `[${new Date().toISOString()}] kernel: cpu: 2 cores online`,
      `[${new Date().toISOString()}] sshd[823]: Accepted publickey for root from 10.0.0.1`,
      `[${new Date().toISOString()}] systemd[1]: Started OpenBSD Secure Shell server.`,
      `[${new Date().toISOString()}] cron[712]: (root) CMD (/usr/local/bin/health-check.sh)`,
    ];
    const t = setInterval(() => {
      setOutput(prev => [...prev, lines[Math.floor(Math.random() * lines.length)]]);
    }, 8000);
    return () => clearInterval(t);
  }, [session, connected]);

  useEffect(() => {
    if (termRef.current) {
      termRef.current.scrollTop = termRef.current.scrollHeight;
    }
  }, [output]);

  const send = () => {
    if (!input || !socketRef.current) return;
    socketRef.current.emit('console.input', { vpsId, data: input });
    setOutput(prev => [...prev, `$ ${input}`]);
    // Simulate a response
    setTimeout(() => {
      const cmd = input.trim();
      let resp = '';
      if (cmd === 'help') {
        resp = 'Available commands: help, whoami, hostname, uptime, ls, df -h';
      } else if (cmd === 'whoami') {
        resp = 'root';
      } else if (cmd === 'hostname') {
        resp = hostname || 'vps';
      } else if (cmd === 'uptime') {
        resp = ` ${new Date().toLocaleString()}  up 3 days,  4:21,  1 user,  load average: 0.12, 0.08, 0.05`;
      } else if (cmd === 'ls') {
        resp = 'bin   dev  home  lib\tlost+found  mnt  opt  proc  root  run  sbin  srv  sys  tmp  usr  var';
      } else if (cmd === 'df -h') {
        resp = `Filesystem      Size  Used Avail Use% Mounted on\n/dev/vda1        78G   32G   42G  44% /\ntmpfs           2.0G     0  2.0G   0% /dev/shm`;
      } else if (cmd.startsWith('echo ')) {
        resp = cmd.slice(5);
      } else {
        resp = `${cmd}: command not found`;
      }
      setOutput(prev => [...prev, resp]);
    }, 200);
    setInput('');
  };

  if (!running) {
    return (
      <Card className="glass-panel p-8 text-center">
        <AlertCircle className="w-10 h-10 text-zinc-700 mx-auto mb-2" />
        <p className="text-sm text-zinc-500">VPS is not running. Start the server to access the console.</p>
      </Card>
    );
  }

  if (suspended) {
    return (
      <Card className="glass-panel p-8 text-center">
        <AlertCircle className="w-10 h-10 text-red-500/50 mx-auto mb-2" />
        <p className="text-sm text-red-300">Console access is disabled for suspended VPS.</p>
      </Card>
    );
  }

  return (
    <Card className="glass-panel-red p-0 overflow-hidden relative">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-zinc-800 bg-zinc-950/80">
        <div className="flex items-center gap-2">
          <Terminal className="w-4 h-4 text-rose-400" />
          <p className="text-xs font-mono text-zinc-300">serial-console · {vpsId.slice(0, 8)}</p>
        </div>
        <div className="flex items-center gap-2">
          {connected ? (
            <span className="flex items-center gap-1 text-xs text-emerald-400">
              <Wifi className="w-3 h-3" /> Live
            </span>
          ) : (
            <span className="flex items-center gap-1 text-xs text-amber-400">
              <WifiOff className="w-3 h-3" /> Disconnected
            </span>
          )}
          <Button size="sm" variant="ghost" onClick={openSession} className="text-zinc-400 hover:text-white h-7">
            <RefreshCw className="w-3 h-3" /> Reconnect
          </Button>
          <Button size="sm" variant="ghost" onClick={() => {
            if (termRef.current?.parentElement?.requestFullscreen) {
              termRef.current.parentElement.requestFullscreen();
            }
          }} className="text-zinc-400 hover:text-white h-7">
            <Maximize2 className="w-3 h-3" /> Full
          </Button>
        </div>
      </div>

      {/* Terminal */}
      <div
        ref={termRef}
        className="bg-black p-4 font-mono text-xs leading-relaxed text-zinc-200 overflow-y-auto h-80 scanline relative"
      >
        {loading ? (
          <div className="flex items-center gap-2 text-zinc-500">
            <Loader2 className="w-3 h-3 animate-spin" /> Opening secure console session...
          </div>
        ) : !session ? (
          <p className="text-red-400">Failed to open console session.</p>
        ) : (
          <>
            {output.map((line, i) => (
              <div key={i} className="whitespace-pre-wrap break-all">
                {line}
              </div>
            ))}
          </>
        )}
      </div>

      {/* Input */}
      <div className="flex items-center gap-2 px-4 py-2.5 border-t border-zinc-800 bg-zinc-950/80">
        <span className="text-rose-400 font-mono text-xs">$</span>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter') send(); }}
          placeholder="Type a command (try: help, hostname, uptime)"
          className="flex-1 bg-transparent border-none outline-none font-mono text-xs text-zinc-100 placeholder:text-zinc-600"
          disabled={!connected}
        />
        <Button size="sm" onClick={send} disabled={!connected || !input} className="bg-rose-600 hover:bg-rose-500 text-white h-7">
          <Terminal className="w-3 h-3" /> Send
        </Button>
      </div>

      {/* Footer */}
      <div className="px-4 py-2 border-t border-zinc-800 bg-zinc-950/60 text-[10px] text-zinc-600">
        Session secured by server-side token. Hypervisor credentials are never exposed to the browser.
      </div>
    </Card>
  );
}
