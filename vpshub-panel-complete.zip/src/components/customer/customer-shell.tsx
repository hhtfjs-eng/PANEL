'use client';

import { useEffect } from 'react';
import { useAppStore, User } from '@/lib/frontend/store';
import { customerApi } from '@/lib/frontend/api';
import { cn } from '@/lib/utils';
import {
  LayoutDashboard, HardDrive, Bell, Key, LifeBuoy, LogOut, Menu, X, Server, Shield, IdCard,
  PanelLeftClose, PanelLeftOpen,
} from 'lucide-react';

interface NavItem {
  id: string;
  label: string;
  icon: any;
}

const NAV: NavItem[] = [
  { id: 'dashboard',     label: 'Dashboard',       icon: LayoutDashboard },
  { id: 'profile',       label: 'Profile',         icon: IdCard },
  { id: 'vps',           label: 'My VPS',          icon: HardDrive },
  { id: 'notifications', label: 'Notifications',   icon: Bell },
  { id: 'ssh-keys',      label: 'SSH Keys',         icon: Key },
  { id: 'api-keys',      label: 'API Tokens',       icon: Shield },
  { id: 'support',       label: 'Support',          icon: LifeBuoy },
];

export function CustomerShell({ user, children }: { user: User; children: React.ReactNode }) {
  const { view, setView, sidebarOpen, setSidebarOpen, sidebarCollapsed, toggleSidebarCollapsed, logout, brand } = useAppStore();

  useEffect(() => {
    // Periodic notification check — light polling fallback (realtime WS used elsewhere)
    const t = setInterval(() => customerApi.notificationsUnread().catch(() => null), 30000);
    return () => clearInterval(t);
  }, []);

  return (
    <div className="min-h-screen relative flex">
      {/* Owner-supplied wallpaper as the post-login background */}
      <div
        aria-hidden="true"
        className="fixed inset-0 z-0 bg-cover bg-center bg-no-repeat pointer-events-none"
        style={{ backgroundImage: 'url(/login-wallpaper.png)' }}
      />
      <div className="fixed inset-0 z-0 bg-gradient-to-br from-black/85 via-zinc-950/80 to-black/90 pointer-events-none" />
      <div className="fixed inset-0 z-0 bg-gradient-to-t from-rose-950/20 via-transparent to-rose-950/10 pointer-events-none" />

      {/* Sidebar — fixed to the viewport so it stays visible while the
          main content scrolls. Full viewport height (h-screen) so it is
          never cropped. Transparent glass (backdrop-blur) lets the owner
          wallpaper show through. On mobile it slides fully off-screen
          until the hamburger opens it. */}
      <aside
        className={cn(
          'fixed top-0 left-0 z-40 flex flex-col h-screen',
          'bg-zinc-950/40 backdrop-blur-xl border-r border-white/5',
          'transition-[width,transform] duration-300 ease-in-out',
          sidebarCollapsed ? 'w-16' : 'w-64',
          sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0',
        )}
      >
        {/* Logo */}
        <div className={cn(
          'h-16 flex items-center border-b border-white/5',
          sidebarCollapsed ? 'justify-center px-2' : 'px-6',
        )}>
          {sidebarCollapsed ? (
            <div className="w-8 h-8 rounded-md bg-rose-600 flex items-center justify-center glow-red-sm shrink-0" title={brand}>
              <Server className="w-4 h-4 text-white" />
            </div>
          ) : (
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-8 h-8 rounded-md bg-rose-600 flex items-center justify-center glow-red-sm shrink-0">
                <Server className="w-4 h-4 text-white" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-bold tracking-tight truncate">{brand}</p>
                <p className="text-[10px] text-zinc-400 -mt-0.5 uppercase tracking-wider">Customer</p>
              </div>
              <span className="hidden xl:inline-flex shrink-0 px-1.5 py-0.5 text-[9px] uppercase tracking-wider bg-rose-500/15 text-rose-300 border border-rose-500/30 rounded">
                {user.role}
              </span>
            </div>
          )}
          <button onClick={() => setSidebarOpen(false)} className="lg:hidden ml-auto text-zinc-300 hover:text-white shrink-0" aria-label="Close sidebar">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Nav */}
        <nav className={cn(
          'flex-1 p-2 space-y-1 overflow-y-auto',
          sidebarCollapsed && 'px-1',
        )}>
          {NAV.map(item => (
            <button
              key={item.id}
              onClick={() => setView(item.id)}
              title={sidebarCollapsed ? item.label : undefined}
              className={cn(
                'w-full flex items-center rounded-md text-sm transition-colors',
                sidebarCollapsed ? 'justify-center px-1 py-2.5' : 'gap-3 px-3 py-2',
                view === item.id
                  ? 'bg-rose-500/15 text-rose-200 border border-rose-500/40 glow-red-sm backdrop-blur-sm'
                  : 'text-zinc-300 hover:text-white hover:bg-white/5 border border-transparent',
              )}
            >
              <item.icon className="w-4 h-4 shrink-0" />
              {!sidebarCollapsed && <span>{item.label}</span>}
            </button>
          ))}
        </nav>

        {/* Provisioning notice — hidden when collapsed (text wouldn't fit) */}
        {!sidebarCollapsed && (
          <div className="m-3 p-3 rounded-md bg-white/5 backdrop-blur-sm border border-white/10">
            <p className="text-xs text-zinc-400 mb-1">Provisioning</p>
            <p className="text-xs text-zinc-300 leading-snug">
              VPS provisioning is managed by administrators. Contact support to request a VPS.
            </p>
          </div>
        )}

        {/* User card */}
        <div className="border-t border-white/5 p-2">
          {!sidebarCollapsed && (
            <button onClick={() => setView('profile')} className="flex items-center gap-2 px-2 py-2 rounded-md bg-white/5 hover:bg-white/10 backdrop-blur-sm transition-colors w-full text-left mb-1" title="Open Profile">
              <div className="w-8 h-8 rounded-full bg-rose-500/20 border border-rose-500/30 flex items-center justify-center text-rose-300 text-xs font-bold uppercase shrink-0">
                {user.name.charAt(0)}
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-zinc-100 truncate">{user.name}</p>
                <p className="text-xs text-zinc-400 truncate">{user.email}</p>
              </div>
            </button>
          )}
          {sidebarCollapsed && (
            <button onClick={() => setView('profile')} className="flex items-center justify-center px-1 py-2 rounded-md bg-white/5 hover:bg-white/10 backdrop-blur-sm transition-colors w-full mb-1" title={`${user.name} · ${user.email}`}>
              <div className="w-8 h-8 rounded-full bg-rose-500/20 border border-rose-500/30 flex items-center justify-center text-rose-300 text-xs font-bold uppercase shrink-0">
                {user.name.charAt(0)}
              </div>
            </button>
          )}
          <button onClick={logout} title="Sign out" className={cn(
            'w-full flex items-center rounded-md text-xs text-zinc-400 hover:text-rose-300 hover:bg-white/5 transition-colors',
            sidebarCollapsed ? 'justify-center px-1 py-2' : 'justify-center gap-2 px-2 py-1.5',
          )}>
            <LogOut className="w-3.5 h-3.5" /> {!sidebarCollapsed && 'Sign out'}
          </button>
        </div>
      </aside>

      {/* Overlay for mobile */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-30 bg-black/70 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Main — offset on desktop by the fixed sidebar width so content
          never slides under it. Transition synced with the sidebar's. */}
      <div className={cn(
        'flex-1 flex flex-col min-w-0 relative z-10',
        'transition-[margin] duration-300 ease-in-out',
        sidebarCollapsed ? 'lg:ml-16' : 'lg:ml-64',
      )}>
        <header className="h-14 lg:h-16 sticky top-0 z-20 bg-zinc-950/60 backdrop-blur-xl border-b border-white/5 flex items-center px-3 lg:px-6 gap-2">
          <button onClick={() => setSidebarOpen(true)} className="lg:hidden text-zinc-300 hover:text-white" aria-label="Open sidebar">
            <Menu className="w-5 h-5" />
          </button>
          <button
            onClick={toggleSidebarCollapsed}
            className="hidden lg:inline-flex items-center justify-center w-8 h-8 rounded-md text-zinc-400 hover:text-rose-300 hover:bg-white/5 transition-colors"
            title={sidebarCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          >
            {sidebarCollapsed ? <PanelLeftOpen className="w-4 h-4" /> : <PanelLeftClose className="w-4 h-4" />}
          </button>
          <div className="flex-1 min-w-0">
            <h1 className="text-sm lg:text-base font-semibold capitalize truncate">
              {NAV.find(n => n.id === view)?.label || 'Dashboard'}
            </h1>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <span className="px-2 py-0.5 text-[10px] uppercase tracking-wider bg-rose-500/15 text-rose-300 border border-rose-500/30 rounded">
              Customer
            </span>
          </div>
        </header>
        <main className="flex-1 p-3 sm:p-4 lg:p-6 max-w-7xl mx-auto w-full">
          {/* Keyed by view so every navigation replays the entrance animation */}
          <div key={view} className="view-enter">{children}</div>
        </main>
      </div>
    </div>
  );
}
