'use client';

import { useEffect, useState } from 'react';
import { useAppStore } from '@/lib/frontend/store';
import { customerApi } from '@/lib/frontend/api';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { StatusBadge } from '@/components/shared/status-badge';
import {
  HardDrive, Search, Cpu, MemoryStick, HardDrive as Disk, Network,
  MapPin, ChevronRight, Loader2, RefreshCw,
} from 'lucide-react';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';

export function CustomerVpsList() {
  const { setView } = useAppStore();
  const [loading, setLoading] = useState(true);
  const [vps, setVps] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('all');
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(1);

  const load = async () => {
    setLoading(true);
    const r = await customerApi.listVps({
      search, status: status === 'all' ? '' : status, page, pageSize: 20,
    });
    if (r.success && r.data) {
      setVps(r.data as any[]);
      setTotal(r.pagination?.total || 0);
      setTotalPages(r.pagination?.totalPages || 1);
    }
    setLoading(false);
  };

  useEffect(() => { load(); }, [page, status]);

  useEffect(() => {
    const t = setTimeout(load, 350);
    return () => clearTimeout(t);
  }, [search]);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-lg font-semibold">My VPS</h2>
          <p className="text-xs text-zinc-500">Servers assigned to your account by administrators</p>
        </div>
        <Button onClick={load} variant="outline" size="sm" className="border-zinc-800">
          <RefreshCw className="w-4 h-4" /> Refresh
        </Button>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
          <Input
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            placeholder="Search by name or hostname..."
            className="pl-9 bg-zinc-950/50 border-zinc-800"
          />
        </div>
        <Select value={status} onValueChange={(v) => { setStatus(v); setPage(1); }}>
          <SelectTrigger className="w-40 bg-zinc-950/50 border-zinc-800">
            <SelectValue placeholder="All statuses" />
          </SelectTrigger>
          <SelectContent className="bg-zinc-950 border-zinc-800">
            <SelectItem value="all">All statuses</SelectItem>
            <SelectItem value="RUNNING">Running</SelectItem>
            <SelectItem value="STOPPED">Stopped</SelectItem>
            <SelectItem value="SUSPENDED">Suspended</SelectItem>
            <SelectItem value="PROVISIONING">Provisioning</SelectItem>
            <SelectItem value="ERROR">Error</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      <Card className="glass-panel overflow-hidden p-0">
        <Table>
          <TableHeader>
            <TableRow className="border-zinc-800 hover:bg-transparent">
              <TableHead className="text-zinc-500">VPS</TableHead>
              <TableHead className="text-zinc-500">Status</TableHead>
              <TableHead className="text-zinc-500">IP</TableHead>
              <TableHead className="text-zinc-500">OS</TableHead>
              <TableHead className="text-zinc-500 hidden md:table-cell">Resources</TableHead>
              <TableHead className="text-zinc-500 hidden lg:table-cell">Location</TableHead>
              <TableHead className="text-zinc-500 hidden lg:table-cell">Created</TableHead>
              <TableHead className="w-8"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-12 text-zinc-500">
                  <Loader2 className="w-5 h-5 animate-spin mx-auto" />
                </TableCell>
              </TableRow>
            ) : vps.length === 0 ? (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-12 text-zinc-500">
                  <HardDrive className="w-10 h-10 text-zinc-700 mx-auto mb-2" />
                  No VPS found matching your filters.
                </TableCell>
              </TableRow>
            ) : vps.map(v => (
              <TableRow
                key={v.id}
                onClick={() => setView('vps-detail', { id: v.id })}
                className="cursor-pointer border-zinc-800 hover:bg-zinc-900/40"
              >
                <TableCell>
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-md bg-rose-500/10 border border-rose-500/30 flex items-center justify-center shrink-0">
                      <HardDrive className="w-4 h-4 text-rose-400" />
                    </div>
                    <div>
                      <p className="font-medium">{v.name}</p>
                      <p className="text-xs text-zinc-500 font-mono">{v.hostname}</p>
                    </div>
                  </div>
                </TableCell>
                <TableCell><StatusBadge status={v.status} size="sm" /></TableCell>
                <TableCell className="font-mono text-xs">{v.ipv4 || '—'}</TableCell>
                <TableCell className="text-sm">
                  {v.os ? <span>{v.os.name}</span> : '—'}
                </TableCell>
                <TableCell className="hidden md:table-cell text-xs text-zinc-400">
                  <div className="flex items-center gap-3">
                    <span className="flex items-center gap-1"><Cpu className="w-3 h-3" /> {v.cpu}</span>
                    <span className="flex items-center gap-1"><MemoryStick className="w-3 h-3" /> {(v.ramMb / 1024).toFixed(0)}G</span>
                    <span className="flex items-center gap-1"><Disk className="w-3 h-3" /> {v.diskGb}G</span>
                  </div>
                </TableCell>
                <TableCell className="hidden lg:table-cell text-xs text-zinc-400">
                  {v.node ? <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> {v.node.region}</span> : '—'}
                </TableCell>
                <TableCell className="hidden lg:table-cell text-xs text-zinc-500">
                  {new Date(v.createdAt).toLocaleDateString()}
                </TableCell>
                <TableCell>
                  <ChevronRight className="w-4 h-4 text-zinc-600" />
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>

      {/* Pagination */}
      <div className="flex items-center justify-between">
        <p className="text-xs text-zinc-500">{total} total · page {page} of {totalPages}</p>
        <div className="flex gap-1">
          <Button size="sm" variant="outline" disabled={page <= 1} onClick={() => setPage(p => p - 1)} className="border-zinc-800">
            Prev
          </Button>
          <Button size="sm" variant="outline" disabled={page >= totalPages} onClick={() => setPage(p => p + 1)} className="border-zinc-800">
            Next
          </Button>
        </div>
      </div>
    </div>
  );
}
