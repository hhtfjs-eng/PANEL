'use client';

import { useEffect, useState, useRef } from 'react';
import { useAppStore } from '@/lib/frontend/store';
import { customerApi, friendlyMessage } from '@/lib/frontend/api';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { StatusBadge } from '@/components/shared/status-badge';
import {
  Tabs, TabsContent, TabsList, TabsTrigger,
} from '@/components/ui/tabs';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  HardDrive, Play, Square, RotateCw, Power, ChevronLeft, Cpu,
  MemoryStick, Network, MapPin, Globe, Server, Activity, Loader2,
  Maximize2, Terminal, RefreshCw, Clock, Key, Copy, Check, ShieldCheck,
  Eye, EyeOff, AlertTriangle,
} from 'lucide-react';
import { toast } from 'sonner';
import { VpsConsole } from './vps-console';
import { VpsMonitoring } from './vps-monitoring';
import { VpsPortForwards } from '@/components/shared/vps-port-forwards';
import { Badge } from '@/components/ui/badge';

export function CustomerVpsDetail() {
  const { viewParams, setView } = useAppStore();
  const id = viewParams?.id as string;
  const [vps, setVps] = useState<any>(null);
  const [activity, setActivity] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [tab, setTab] = useState('overview');
  const [copied, setCopied] = useState(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [pwVisible, setPwVisible] = useState(false);
  // Self-service reinstall
  const [reinstallOpen, setReinstallOpen] = useState(false);
  const [reinstallOsId, setReinstallOsId] = useState('');
  const [osOptions, setOsOptions] = useState<any[]>([]);
  const [reinstallBusy, setReinstallBusy] = useState(false);

  const copyText = async (text: string, field: string) => {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const ta = document.createElement('textarea');
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
    }
    if (field === 'key') { setCopied(true); setTimeout(() => setCopied(false), 2000); }
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const load = async () => {
    setLoading(true);
    const [vRes, aRes] = await Promise.all([
      customerApi.getVps(id),
      customerApi.activity(id),
    ]);
    if (vRes.success && vRes.data) setVps(vRes.data);
    if (aRes.success && aRes.data) setActivity(aRes.data as any[]);
    setLoading(false);
  };

  useEffect(() => { load(); }, [id]);

  const power = async (action: string) => {
    setBusy(true);
    await customerApi.power(id, action);
    await load();
    setBusy(false);
  };

  // Load available OS templates when the reinstall dialog opens
  const openReinstall = async () => {
    setReinstallOsId('');
    setReinstallOpen(true);
    if (osOptions.length === 0) {
      const r = await customerApi.reinstallOsOptions(id);
      if (r.success && r.data) setOsOptions(r.data as any[]);
    }
  };

  const confirmReinstall = async () => {
    setReinstallBusy(true);
    const r = await customerApi.reinstallVps(id, reinstallOsId || undefined);
    setReinstallBusy(false);
    if (r.success) {
      toast.success('Reinstall started — your VPS will be back online shortly');
      setReinstallOpen(false);
      await load();
    } else {
      toast.error(friendlyMessage(r));
    }
  };

  if (loading || !vps) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-6 h-6 text-rose-400 animate-spin" />
      </div>
    );
  }

  const isSuspended = vps.status === 'SUSPENDED';
  const canPower = !isSuspended;

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center gap-3">
        <Button onClick={() => setView('vps')} variant="ghost" size="sm" className="text-zinc-400 hover:text-white">
          <ChevronLeft className="w-4 h-4" /> Back
        </Button>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-rose-500/10 border border-rose-500/30 flex items-center justify-center shrink-0">
              <HardDrive className="w-5 h-5 text-rose-400" />
            </div>
            <div className="min-w-0">
              <h1 className="text-lg font-bold truncate">{vps.name}</h1>
              <p className="text-xs text-zinc-500 font-mono truncate">{vps.hostname}</p>
            </div>
          </div>
        </div>
        <StatusBadge status={vps.status} />
      </div>

      {/* Power actions */}
      <Card className="glass-panel p-4">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div>
            <p className="text-xs uppercase tracking-wider text-zinc-500 mb-1">Power Control</p>
            <p className="text-sm text-zinc-300">
              {isSuspended ? 'This VPS is suspended. Contact your administrator.' :
                vps.status === 'RUNNING' ? 'Server is currently running.' :
                vps.status === 'PROVISIONING' ? 'Server is provisioning.' :
                'Server is currently stopped.'}
            </p>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <Button size="sm" disabled={busy || !canPower || vps.status === 'RUNNING'}
              onClick={() => power('start')}
              className="bg-emerald-600 hover:bg-emerald-500 text-white disabled:opacity-50">
              <Play className="w-4 h-4" /> Start
            </Button>
            <Button size="sm" disabled={busy || !canPower || vps.status !== 'RUNNING'}
              onClick={() => power('stop')}
              variant="outline" className="border-zinc-700 hover:bg-zinc-900">
              <Square className="w-4 h-4" /> Stop
            </Button>
            <Button size="sm" disabled={busy || !canPower || vps.status !== 'RUNNING'}
              onClick={() => power('restart')}
              variant="outline" className="border-zinc-700 hover:bg-zinc-900">
              <RotateCw className="w-4 h-4" /> Restart
            </Button>
            <Button size="sm" disabled={busy || !canPower || vps.status !== 'RUNNING'}
              onClick={() => power('shutdown')}
              variant="outline" className="border-zinc-700 hover:bg-zinc-900">
              <Power className="w-4 h-4" /> Shutdown
            </Button>
            <Button size="sm" disabled={busy || !canPower || vps.status === 'PROVISIONING'}
              onClick={openReinstall}
              variant="outline" className="border-amber-600/40 text-amber-300 hover:bg-amber-500/10 hover:border-amber-500/60">
              <RefreshCw className="w-4 h-4" /> Reinstall
            </Button>
          </div>
        </div>
      </Card>

      {/* Tabs */}
      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="bg-zinc-950/50 border border-zinc-800 p-1">
          <TabsTrigger value="overview" className="data-[state=active]:bg-rose-500/20 data-[state=active]:text-rose-300">Overview</TabsTrigger>
          <TabsTrigger value="monitoring" className="data-[state=active]:bg-rose-500/20 data-[state=active]:text-rose-300">Monitoring</TabsTrigger>
          <TabsTrigger value="console" className="data-[state=active]:bg-rose-500/20 data-[state=active]:text-rose-300">Console</TabsTrigger>
          <TabsTrigger value="ports" className="data-[state=active]:bg-rose-500/20 data-[state=active]:text-rose-300">Ports</TabsTrigger>
          <TabsTrigger value="network" className="data-[state=active]:bg-rose-500/20 data-[state=active]:text-rose-300">Network</TabsTrigger>
          <TabsTrigger value="activity" className="data-[state=active]:bg-rose-500/20 data-[state=active]:text-rose-300">Activity</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-4">
          <div className="space-y-4">
            <div className="grid lg:grid-cols-2 gap-4">
              <Card className="glass-panel p-5">
                <h3 className="text-sm font-semibold uppercase tracking-wider text-zinc-500 mb-4">Resources</h3>
                <div className="space-y-3">
                  <Row icon={Cpu} label="CPU" value={`${vps.cpu} vCPU`} />
                  <Row icon={MemoryStick} label="RAM" value={`${(vps.ramMb / 1024).toFixed(0)} GB`} />
                  <Row icon={HardDrive} label="Disk" value={`${vps.diskGb} GB`} />
                  <Row icon={Network} label="Bandwidth" value={`${(vps.bandwidthMbps / 1000).toFixed(1)} Gbps`} />
                </div>
              </Card>

              <Card className="glass-panel p-5">
                <h3 className="text-sm font-semibold uppercase tracking-wider text-zinc-500 mb-4">Server Info</h3>
                <div className="space-y-3">
                  <Row icon={Server} label="Hostname" value={vps.hostname} mono />
                  <Row icon={Globe} label="IPv4" value={vps.ipv4 || '—'} mono />
                  <Row icon={Globe} label="IPv6" value={vps.ipv6 || '—'} mono />
                  <Row icon={MapPin} label="Location" value={vps.node ? `${vps.node.region} · ${vps.node.datacenter}` : '—'} />
                  <Row icon={HardDrive} label="OS" value={vps.os?.name || '—'} />
                  <Row icon={Clock} label="Uptime" value={vps.status === 'RUNNING' && vps.lastBootedAt ?
                    `${Math.floor((Date.now() - new Date(vps.lastBootedAt).getTime()) / 86400000)}d ${Math.floor((Date.now() - new Date(vps.lastBootedAt).getTime()) / 3600000) % 24}h` : '—'} />
                </div>
              </Card>
            </div>

            {/* SSH access — credentials auto-generated at VPS creation.
                Login reads root@ownername (hostname derives from the owner). */}
            <Card className="glass-panel-red p-5">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-semibold uppercase tracking-wider text-zinc-500 flex items-center gap-2">
                  <Key className="w-4 h-4 text-rose-400" /> SSH Access
                  <Badge variant="outline" className="bg-emerald-500/10 text-emerald-300 border-emerald-500/30 text-[10px] normal-case">Auto-generated at creation</Badge>
                </h3>
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  {/* Login — root@ownername */}
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-zinc-600 mb-1.5">Login (user@host)</p>
                    <div className="flex items-center gap-2">
                      <code className="flex-1 px-3 py-2 rounded-md bg-black/60 border border-zinc-800 font-mono text-sm text-rose-200 select-all">{vps.sshUsername || 'root'}@{vps.hostname}</code>
                      <Button size="sm" variant="outline" onClick={() => copyText(`${vps.sshUsername || 'root'}@${vps.hostname}`, 'login')} className="h-9 border-zinc-700 text-zinc-300 hover:text-white">
                        {copiedField === 'login' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </Button>
                    </div>
                  </div>
                  {/* SSH command */}
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-zinc-600 mb-1.5">Connect via IP</p>
                    <div className="flex items-center gap-2">
                      <code className="flex-1 px-3 py-2 rounded-md bg-black/60 border border-zinc-800 font-mono text-sm text-zinc-300 select-all">ssh {(vps.sshUsername || 'root')}@{vps.ipv4 || vps.hostname}</code>
                      <Button size="sm" variant="outline" onClick={() => copyText(`ssh ${vps.sshUsername || 'root'}@${vps.ipv4 || vps.hostname}`, 'cmd')} className="h-9 border-zinc-700 text-zinc-300 hover:text-white">
                        {copiedField === 'cmd' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </Button>
                    </div>
                  </div>
                  {/* Root password */}
                  {vps.rootPasswordPlain && (
                    <div>
                      <p className="text-[10px] uppercase tracking-wider text-zinc-600 mb-1.5">Root password</p>
                      <div className="flex items-center gap-2">
                        <code className="flex-1 px-3 py-2 rounded-md bg-black/60 border border-zinc-800 font-mono text-sm text-zinc-300 select-all">
                          {pwVisible ? vps.rootPasswordPlain : '•'.repeat(Math.min(24, vps.rootPasswordPlain.length))}
                        </code>
                        <Button size="sm" variant="outline" onClick={() => setPwVisible(v => !v)} className="h-9 border-zinc-700 text-zinc-300 hover:text-white">
                          {pwVisible ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => copyText(vps.rootPasswordPlain, 'pw')} className="h-9 border-zinc-700 text-zinc-300 hover:text-white">
                          {copiedField === 'pw' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
                <div className="space-y-3">
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-zinc-600 mb-1.5">Authorized public key (ED25519)</p>
                    <div className="p-3 rounded-md bg-black/60 border border-zinc-800 max-h-28 overflow-y-auto">
                      <p className="font-mono text-xs text-zinc-300 break-all leading-relaxed select-all">{vps.sshPublicKey || '—'}</p>
                    </div>
                  </div>
                  <p className="text-xs text-zinc-500 flex items-start gap-2">
                    <ShieldCheck className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                    These credentials were generated automatically when your VPS was deployed and are authorized for root login.
                  </p>
                </div>
              </div>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="monitoring" className="mt-4">
          <VpsMonitoring vpsId={id} running={vps.status === 'RUNNING'} />
        </TabsContent>

        <TabsContent value="console" className="mt-4">
          <VpsConsole vpsId={id} running={vps.status === 'RUNNING'} suspended={isSuspended} hostname={vps.hostname} />
        </TabsContent>

        <TabsContent value="ports" className="mt-4">
          <VpsPortForwards
            vpsId={id}
            vpsStatus={vps.status}
            api={{
              list: customerApi.forwards,
              add: customerApi.addForward,
              remove: customerApi.deleteForward,
            }} />
        </TabsContent>

        <TabsContent value="network" className="mt-4">
          <Card className="glass-panel p-5">
            <h3 className="text-sm font-semibold uppercase tracking-wider text-zinc-500 mb-4">Network Configuration</h3>
            <div className="space-y-3">
              <Row icon={Globe} label="IPv4 Address" value={vps.ipv4 || '—'} mono />
              <Row icon={Globe} label="IPv6 Address" value={vps.ipv6 || '—'} mono />
              <Row icon={Network} label="Gateway" value={vps.gateway || '—'} mono />
              <Row icon={Network} label="DNS Primary" value={vps.dnsPrimary || '—'} mono />
              <Row icon={Network} label="DNS Secondary" value={vps.dnsSecondary || '—'} mono />
              <Row icon={Globe} label="Reverse DNS" value={vps.reverseDns || '—'} mono />
              <Row icon={Network} label="Bandwidth Cap" value={`${(vps.bandwidthMbps / 1000).toFixed(1)} Gbps`} />
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="activity" className="mt-4">
          <Card className="glass-panel p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold uppercase tracking-wider text-zinc-500">Activity Log</h3>
              <Button onClick={load} variant="ghost" size="sm" className="text-zinc-400 hover:text-white">
                <RefreshCw className="w-4 h-4" />
              </Button>
            </div>
            <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
              {activity.length === 0 ? (
                <p className="text-sm text-zinc-500 text-center py-8">No activity yet</p>
              ) : activity.map(a => (
                <div key={a.id} className="flex items-start gap-3 p-3 rounded-md bg-zinc-900/50 border border-zinc-800">
                  <div className="w-7 h-7 rounded bg-zinc-800 flex items-center justify-center shrink-0">
                    <Activity className="w-3 h-3 text-zinc-400" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-medium text-zinc-200">{a.action}</p>
                    <p className="text-xs text-zinc-500">{a.message}</p>
                    <p className="text-[10px] text-zinc-600 mt-0.5">
                      {new Date(a.createdAt).toLocaleString()} · {a.actor}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>
      </Tabs>
      {/* Reinstall Dialog — self-service OS reinstall */}
      <Dialog open={reinstallOpen} onOpenChange={setReinstallOpen}>
        <DialogContent className="bg-zinc-950 border-zinc-800">
          <DialogHeader><DialogTitle>Reinstall Operating System</DialogTitle></DialogHeader>
          <div className="space-y-3 py-4">
            <p className="text-xs text-zinc-400">Current OS: <span className="text-zinc-200 font-medium">{vps.os?.name || '—'}</span></p>
            <Select value={reinstallOsId} onValueChange={setReinstallOsId}>
              <SelectTrigger className="bg-zinc-950/50 border-zinc-800"><SelectValue placeholder="Keep current OS" /></SelectTrigger>
              <SelectContent className="bg-zinc-950 border-zinc-800">
                {osOptions.map(o => (
                  <SelectItem key={o.id} value={o.id}>{o.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <div className="text-xs text-red-300 bg-red-500/10 border border-red-500/20 p-3 rounded flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>Warning: all data on this VPS will be destroyed. This cannot be undone.</span>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setReinstallOpen(false)} className="border-zinc-800">Cancel</Button>
            <Button onClick={confirmReinstall} disabled={reinstallBusy}
              className="bg-amber-600 hover:bg-amber-500 text-white">
              {reinstallBusy ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />} Reinstall
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Row({ icon: Icon, label, value, mono }: { icon: any; label: string; value: string; mono?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-3 py-1">
      <div className="flex items-center gap-2 text-sm text-zinc-400">
        <Icon className="w-4 h-4 text-zinc-500" />
        <span>{label}</span>
      </div>
      <span className={`text-sm text-zinc-200 ${mono ? 'font-mono' : ''}`}>{value}</span>
    </div>
  );
}
