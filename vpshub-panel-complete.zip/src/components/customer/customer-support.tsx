'use client';

import { useEffect, useRef, useState } from 'react';
import { customerApi, friendlyMessage } from '@/lib/frontend/api';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { LifeBuoy, Plus, Loader2, Send, MessageSquare, ChevronLeft, Clock, Headphones, Trash2 } from 'lucide-react';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter,
} from '@/components/ui/dialog';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

const TICKET_STATUS: Record<string, { label: string; cls: string }> = {
  open: { label: 'Open', cls: 'bg-amber-500/10 text-amber-300 border-amber-500/30' },
  pending: { label: 'Pending', cls: 'bg-sky-500/10 text-sky-300 border-sky-500/30' },
  resolved: { label: 'Resolved', cls: 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30' },
  closed: { label: 'Closed', cls: 'bg-zinc-500/10 text-zinc-500 border-zinc-500/30' },
};

export function CustomerSupport() {
  const [list, setList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ subject: '', category: 'general', priority: 'normal', message: '' });
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [ticket, setTicket] = useState<any>(null);
  const [threadLoading, setThreadLoading] = useState(false);
  const [reply, setReply] = useState('');
  const [sending, setSending] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const threadRef = useRef<HTMLDivElement | null>(null);

  const load = async () => {
    setLoading(true);
    const r = await customerApi.supportTickets();
    if (r.success && r.data) setList(r.data as any[]);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  // Load thread when a ticket is selected; poll for new staff replies
  const loadThread = async (silent = false) => {
    if (!selectedId) return;
    if (!silent) setThreadLoading(true);
    const r = await customerApi.supportTicket(selectedId);
    if (r.success && r.data) setTicket(r.data);
    if (!silent) setThreadLoading(false);
  };
  useEffect(() => { loadThread(); }, [selectedId]);
  useEffect(() => {
    if (!selectedId) return;
    const t = setInterval(() => loadThread(true), 5000);
    return () => clearInterval(t);
  }, [selectedId]);

  useEffect(() => {
    if (threadRef.current) threadRef.current.scrollTop = threadRef.current.scrollHeight;
  }, [ticket?.messages?.length, selectedId]);

  const submit = async () => {
    if (!form.subject || !form.message) return;
    const r = await customerApi.createSupportTicket(form);
    if (r.success) {
      setForm({ subject: '', category: 'general', priority: 'normal', message: '' });
      setOpen(false);
      load();
    }
  };

  const sendReply = async () => {
    if (!reply.trim() || !selectedId) return;
    setSending(true);
    const r = await customerApi.replySupportTicket(selectedId, reply.trim());
    setSending(false);
    if (r.success) {
      setReply('');
      loadThread(true);
      load();
    }
  };

  const deleteTicket = async () => {
    if (!selectedId || deleting) return;
    setDeleting(true);
    const r = await customerApi.deleteSupportTicket(selectedId);
    setDeleting(false);
    if (r.success) {
      toast.success('Ticket deleted');
      setSelectedId(null);
      setTicket(null);
      load();
    } else {
      toast.error(`Failed: ${friendlyMessage(r)}`);
    }
  };

  // ===== Chat view for a selected ticket =====
  if (selectedId && ticket) {
    return (
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <Button onClick={() => { setSelectedId(null); setTicket(null); }} variant="ghost" size="sm" className="text-zinc-400 hover:text-white">
            <ChevronLeft className="w-4 h-4" /> All tickets
          </Button>
        </div>
        <Card className="glass-panel p-0 overflow-hidden flex flex-col" style={{ minHeight: '480px' }}>
          <div className="px-4 py-3 border-b border-zinc-800 flex items-start justify-between gap-2">
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <p className="text-sm font-semibold">{ticket.subject}</p>
                <span className={cn('px-1.5 py-0.5 text-[10px] uppercase border rounded', TICKET_STATUS[ticket.status]?.cls)}>
                  {TICKET_STATUS[ticket.status]?.label}
                </span>
              </div>
              <p className="text-xs text-zinc-500 mt-0.5">Category: {ticket.category} · Priority: {ticket.priority}</p>
            </div>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button size="sm" variant="outline" disabled={deleting}
                  className="h-8 border-red-800/60 text-red-300 hover:text-red-200 hover:bg-red-500/10 hover:border-red-700 shrink-0">
                  {deleting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />} Delete
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent className="bg-zinc-950 border-zinc-800">
                <AlertDialogHeader>
                  <AlertDialogTitle>Delete this ticket?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This permanently deletes “{ticket.subject}” and its entire message thread.
                    This action cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel className="border-zinc-800 bg-zinc-900 text-zinc-300 hover:bg-zinc-800 hover:text-zinc-100">Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={(e) => { e.preventDefault(); deleteTicket(); }}
                    className="bg-red-600 hover:bg-red-500 text-white border-none">
                    Delete Ticket
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>

          <div ref={threadRef} className="flex-1 overflow-y-auto p-4 space-y-3 max-h-[50vh]">
            {threadLoading ? (
              <div className="flex justify-center py-8"><Loader2 className="w-5 h-5 text-rose-400 animate-spin" /></div>
            ) : ticket.messages.map((m: any) => (
              <div key={m.id} className={cn('flex', m.isStaff ? 'justify-start' : 'justify-end')}>
                <div className={cn(
                  'max-w-[80%] rounded-lg px-3 py-2 border',
                  m.isStaff
                    ? 'bg-rose-500/10 border-rose-500/30 rounded-bl-none'
                    : 'bg-zinc-900/70 border-zinc-800 rounded-br-none',
                )}>
                  <div className="flex items-center gap-1.5 mb-1">
                    <span className={cn('text-[10px] font-semibold uppercase tracking-wider flex items-center gap-1', m.isStaff ? 'text-rose-300' : 'text-zinc-400')}>
                      {m.isStaff ? <Headphones className="w-3 h-3" /> : null}
                      {m.isStaff ? 'Support Team' : 'You'}
                    </span>
                    <span className="text-[10px] text-zinc-600">{new Date(m.createdAt).toLocaleString()}</span>
                  </div>
                  <p className="text-sm text-zinc-200 whitespace-pre-wrap break-words">{m.body}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="border-t border-zinc-800 p-3">
            {ticket.status === 'closed' ? (
              <p className="text-xs text-zinc-500 text-center py-2">
                This ticket is closed. <button onClick={() => { setSelectedId(null); load(); }} className="text-rose-400 hover:text-rose-300">Create a new ticket</button> if you still need help.
              </p>
            ) : (
              <div className="flex items-end gap-2">
                <textarea
                  value={reply}
                  onChange={(e) => setReply(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendReply(); } }}
                  rows={2}
                  placeholder="Write a reply... (Enter to send, Shift+Enter for newline)"
                  className="flex-1 bg-zinc-950/50 border border-zinc-800 rounded-md px-3 py-2 text-sm text-zinc-100 placeholder:text-zinc-600 outline-none focus:border-rose-500/50 resize-none"
                />
                <Button onClick={sendReply} disabled={sending || !reply.trim()} className="bg-rose-600 hover:bg-rose-500 text-white">
                  {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />} Send
                </Button>
              </div>
            )}
          </div>
        </Card>
      </div>
    );
  }

  // ===== Ticket list =====
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold">Support Tickets</h2>
          <p className="text-xs text-zinc-500">Request a VPS, report an issue, or chat with our team</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="bg-rose-600 hover:bg-rose-500 text-white">
              <Plus className="w-4 h-4" /> New Ticket
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-zinc-950 border-zinc-800">
            <DialogHeader>
              <DialogTitle>New Support Ticket</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-1.5">
                <Label>Subject</Label>
                <Input value={form.subject} onChange={(e) => setForm(p => ({ ...p, subject: e.target.value }))}
                  placeholder="Request VPS for production deployment" className="bg-zinc-950/50 border-zinc-800" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label>Category</Label>
                  <Select value={form.category} onValueChange={(v) => setForm(p => ({ ...p, category: v }))}>
                    <SelectTrigger className="bg-zinc-950/50 border-zinc-800"><SelectValue /></SelectTrigger>
                    <SelectContent className="bg-zinc-950 border-zinc-800">
                      <SelectItem value="general">General</SelectItem>
                      <SelectItem value="vps_request">VPS Request</SelectItem>
                      <SelectItem value="billing">Billing</SelectItem>
                      <SelectItem value="abuse">Abuse</SelectItem>
                      <SelectItem value="technical">Technical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label>Priority</Label>
                  <Select value={form.priority} onValueChange={(v) => setForm(p => ({ ...p, priority: v }))}>
                    <SelectTrigger className="bg-zinc-950/50 border-zinc-800"><SelectValue /></SelectTrigger>
                    <SelectContent className="bg-zinc-950 border-zinc-800">
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="normal">Normal</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="urgent">Urgent</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-1.5">
                <Label>Message</Label>
                <Textarea value={form.message} onChange={(e) => setForm(p => ({ ...p, message: e.target.value }))}
                  rows={5} placeholder="Describe your request..."
                  className="bg-zinc-950/50 border-zinc-800" />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setOpen(false)} className="border-zinc-800">Cancel</Button>
              <Button onClick={submit} className="bg-rose-600 hover:bg-rose-500 text-white">Submit Ticket</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="space-y-2">
        {loading ? (
          <div className="flex justify-center py-8"><Loader2 className="w-5 h-5 text-rose-400 animate-spin" /></div>
        ) : list.length === 0 ? (
          <Card className="glass-panel p-8 text-center">
            <LifeBuoy className="w-10 h-10 text-zinc-700 mx-auto mb-2" />
            <p className="text-sm text-zinc-500">No support tickets yet</p>
          </Card>
        ) : list.map(t => (
          <button key={t.id} onClick={() => setSelectedId(t.id)} className="w-full text-left">
            <Card className="glass-panel p-4 hover:border-rose-500/30 transition-colors">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-md bg-rose-500/10 border border-rose-500/30 flex items-center justify-center shrink-0">
                  <MessageSquare className="w-4 h-4 text-rose-400" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-start justify-between gap-2">
                    <p className="text-sm font-medium">{t.subject}</p>
                    <span className={cn('px-1.5 py-0.5 text-[10px] uppercase border rounded shrink-0', TICKET_STATUS[t.status]?.cls)}>
                      {TICKET_STATUS[t.status]?.label}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 mt-1 text-[10px] text-zinc-500">
                    <span>Category: {t.category}</span>
                    <span>Priority: {t.priority}</span>
                    <span className="flex items-center gap-1"><MessageSquare className="w-3 h-3" />{t._count?.messages || 0} messages</span>
                    <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{new Date(t.updatedAt).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>
            </Card>
          </button>
        ))}
      </div>
    </div>
  );
}
