'use client';

import { useEffect, useState, useRef } from 'react';
import { customerApi } from '@/lib/frontend/api';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Loader2, Activity, RefreshCw, AlertCircle } from 'lucide-react';

interface Props {
  vpsId: string;
  running: boolean;
}

export function VpsMonitoring({ vpsId, running }: Props) {
  const [loading, setLoading] = useState(true);
  const [current, setCurrent] = useState<any>(null);
  const [history, setHistory] = useState<any[]>([]);
  const [polling, setPolling] = useState(false);
  const intervalRef = useRef<any>(null);

  const load = async () => {
    setPolling(true);
    const r = await customerApi.stats(vpsId);
    if (r.success && r.data) {
      setCurrent(r.data.current);
      setHistory(r.data.history || []);
    }
    setPolling(false);
    setLoading(false);
  };

  useEffect(() => {
    load();
    // Poll every 5 seconds when running
    intervalRef.current = setInterval(load, 5000);
    return () => clearInterval(intervalRef.current);
  }, [vpsId, running]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-6 h-6 text-rose-400 animate-spin" />
      </div>
    );
  }

  if (!running) {
    return (
      <Card className="glass-panel p-8 text-center">
        <AlertCircle className="w-10 h-10 text-zinc-700 mx-auto mb-2" />
        <p className="text-sm text-zinc-500">VPS is not running. Start the server to view real-time metrics.</p>
      </Card>
    );
  }

  const metric = (label: string, value: number, max: number, suffix: string, data: any[], color: string) => {
    const pct = Math.min(100, (value / max) * 100);
    // chart: simple sparkline
    const points = data.slice(-30).map((d, i) => ({
      x: (i / Math.max(1, data.length - 1)) * 100,
      y: (d as any).cpuUsage || 0,
    }));
    return (
      <Card key={label} className="glass-panel p-4">
        <div className="flex items-center justify-between mb-2">
          <p className="text-xs uppercase tracking-wider text-zinc-500">{label}</p>
          <p className="text-lg font-bold font-mono tabular-nums" style={{ color }}>
            {value.toFixed(1)}{suffix}
          </p>
        </div>
        <Sparkline data={data.map(d => d.cpuUsage).slice(-30)} color="#e11d48" />
        <div className="mt-2 h-1.5 bg-zinc-900 rounded-full overflow-hidden">
          <div className="h-full rounded-full transition-all" style={{ width: `${pct}%`, backgroundColor: color }} />
        </div>
      </Card>
    );
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-semibold">Real-time Metrics</p>
          <p className="text-xs text-zinc-500">Updates every 5 seconds · Uses real infrastructure stats</p>
        </div>
        <Button onClick={load} variant="outline" size="sm" disabled={polling} className="border-zinc-800">
          {polling ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />} Refresh
        </Button>
      </div>

      {current ? (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          <MetricCard label="CPU" value={`${current.cpuUsage.toFixed(1)}%`} pct={current.cpuUsage} color="#e11d48" data={history.map(d => d.cpuUsage)} />
          <MetricCard label="RAM" value={`${current.ramUsage.toFixed(1)}%`} pct={current.ramUsage} color="#f97316" data={history.map(d => d.ramUsage)} />
          <MetricCard label="Disk" value={`${current.diskUsage.toFixed(1)}%`} pct={current.diskUsage} color="#f43f5e" data={history.map(d => d.diskUsage)} />
          <MetricCard label="Net In" value={`${(current.netInKbps / 1000).toFixed(1)} Mbps`} pct={Math.min(100, current.netInKbps / 100)} color="#fb7185" data={history.map(d => d.netInKbps)} />
        </div>
      ) : (
        <Card className="glass-panel p-8 text-center">
          <AlertCircle className="w-10 h-10 text-zinc-700 mx-auto mb-2" />
          <p className="text-sm text-zinc-500">Unable to retrieve metrics from infrastructure provider.</p>
        </Card>
      )}

      <Card className="glass-panel p-5">
        <h3 className="text-sm font-semibold uppercase tracking-wider text-zinc-500 mb-4">CPU Usage History</h3>
        <Chart data={history.map(d => ({ t: new Date(d.collectedAt).toLocaleTimeString(), v: d.cpuUsage }))} color="#e11d48" yLabel="CPU %" />
      </Card>

      <Card className="glass-panel p-5">
        <h3 className="text-sm font-semibold uppercase tracking-wider text-zinc-500 mb-4">RAM Usage History</h3>
        <Chart data={history.map(d => ({ t: new Date(d.collectedAt).toLocaleTimeString(), v: d.ramUsage }))} color="#f97316" yLabel="RAM %" />
      </Card>

      <Card className="glass-panel p-5">
        <h3 className="text-sm font-semibold uppercase tracking-wider text-zinc-500 mb-4">Network Throughput</h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-xs text-zinc-500 mb-2">Inbound (Mbps)</p>
            <Chart data={history.map(d => ({ t: new Date(d.collectedAt).toLocaleTimeString(), v: d.netInKbps / 1000 }))} color="#fb7185" yLabel="Mbps" />
          </div>
          <div>
            <p className="text-xs text-zinc-500 mb-2">Outbound (Mbps)</p>
            <Chart data={history.map(d => ({ t: new Date(d.collectedAt).toLocaleTimeString(), v: d.netOutKbps / 1000 }))} color="#f43f5e" yLabel="Mbps" />
          </div>
        </div>
      </Card>
    </div>
  );
}

function MetricCard({ label, value, pct, color, data }: { label: string; value: string; pct: number; color: string; data: number[] }) {
  return (
    <Card className="glass-panel p-4">
      <div className="flex items-center justify-between mb-2">
        <p className="text-xs uppercase tracking-wider text-zinc-500">{label}</p>
        <p className="text-lg font-bold font-mono tabular-nums" style={{ color }}>{value}</p>
      </div>
      <Sparkline data={data.slice(-30)} color={color} />
      <div className="mt-2 h-1.5 bg-zinc-900 rounded-full overflow-hidden">
        <div className="h-full rounded-full transition-all" style={{ width: `${Math.min(100, pct)}%`, backgroundColor: color }} />
      </div>
    </Card>
  );
}

function Sparkline({ data, color }: { data: number[]; color: string }) {
  if (!data || data.length === 0) return <div className="h-10" />;
  const max = Math.max(...data, 1);
  const min = Math.min(...data, 0);
  const range = max - min || 1;
  const w = 100, h = 30;
  const pts = data.map((v, i) => `${(i / Math.max(1, data.length - 1)) * w},${h - ((v - min) / range) * h}`).join(' ');
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="w-full h-10" preserveAspectRatio="none">
      <polyline points={pts} fill="none" stroke={color} strokeWidth="1.5" vectorEffect="non-scaling-stroke" />
    </svg>
  );
}

function Chart({ data, color, yLabel }: { data: { t: string; v: number }[]; color: string; yLabel: string }) {
  if (!data || data.length === 0) {
    return <p className="text-xs text-zinc-500 py-8 text-center">No data yet</p>;
  }
  const w = 600, h = 200;
  const padding = { top: 10, right: 10, bottom: 25, left: 35 };
  const innerW = w - padding.left - padding.right;
  const innerH = h - padding.top - padding.bottom;
  const max = Math.max(...data.map(d => d.v), 1);
  const min = 0;
  const range = max - min || 1;
  const pts = data.map((d, i) => ({
    x: padding.left + (i / Math.max(1, data.length - 1)) * innerW,
    y: padding.top + innerH - ((d.v - min) / range) * innerH,
  }));
  const path = pts.map((p, i) => `${i === 0 ? 'M' : 'L'}${p.x},${p.y}`).join(' ');
  const area = `${path} L${padding.left + innerW},${padding.top + innerH} L${padding.left},${padding.top + innerH} Z`;

  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="w-full h-48" preserveAspectRatio="none">
      {/* Grid */}
      {[0, 0.25, 0.5, 0.75, 1].map((g, i) => (
        <line key={i} x1={padding.left} y1={padding.top + g * innerH} x2={padding.left + innerW} y2={padding.top + g * innerH} stroke="#1c1c20" strokeWidth="0.5" />
      ))}
      {/* Y labels */}
      {[0, 0.5, 1].map((g, i) => (
        <text key={i} x={padding.left - 6} y={padding.top + (1 - g) * innerH + 4} fill="#525258" fontSize="9" textAnchor="end" fontFamily="monospace">
          {(min + g * range).toFixed(0)}
        </text>
      ))}
      {/* Area */}
      <path d={area} fill={color} opacity="0.08" />
      {/* Line */}
      <path d={path} fill="none" stroke={color} strokeWidth="2" vectorEffect="non-scaling-stroke" />
      {/* X labels (every 5) */}
      {data.filter((_, i) => i % Math.max(1, Math.floor(data.length / 5)) === 0).map((d, i, arr) => {
        const idx = data.indexOf(d);
        return (
          <text key={i} x={padding.left + (idx / Math.max(1, data.length - 1)) * innerW} y={h - 8} fill="#525258" fontSize="8" textAnchor="middle" fontFamily="monospace">
            {d.t.split(':').slice(0, 2).join(':')}
          </text>
        );
      })}
    </svg>
  );
}
