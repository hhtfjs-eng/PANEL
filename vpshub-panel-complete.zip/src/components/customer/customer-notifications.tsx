'use client';

import { useEffect, useState } from 'react';
import { customerApi } from '@/lib/frontend/api';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Bell, Check, CheckCheck, RefreshCw } from 'lucide-react';

export function CustomerNotifications() {
  const [list, setList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    const r = await customerApi.notifications();
    if (r.success && r.data) setList(r.data as any[]);
    setLoading(false);
  };

  const markRead = async (id: string) => {
    await customerApi.markNotificationRead(id);
    load();
  };

  const markAll = async () => {
    await customerApi.markAllNotificationsRead();
    load();
  };

  useEffect(() => { load(); }, []);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold">Notifications</h2>
          <p className="text-xs text-zinc-500">System and account alerts</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={load} variant="outline" size="sm" className="border-zinc-800">
            <RefreshCw className="w-4 h-4" />
          </Button>
          <Button onClick={markAll} variant="outline" size="sm" disabled={!list.some(n => !n.read)} className="border-zinc-800">
            <CheckCheck className="w-4 h-4" /> Mark all read
          </Button>
        </div>
      </div>

      <div className="space-y-2">
        {loading ? (
          <p className="text-zinc-500 text-sm py-8 text-center">Loading...</p>
        ) : list.length === 0 ? (
          <Card className="glass-panel p-8 text-center">
            <Bell className="w-10 h-10 text-zinc-700 mx-auto mb-2" />
            <p className="text-sm text-zinc-500">No notifications</p>
          </Card>
        ) : list.map(n => (
          <Card key={n.id} className={`glass-panel p-4 ${!n.read ? 'border-rose-500/30' : ''}`}>
            <div className="flex items-start gap-3">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                !n.read ? 'bg-rose-500/15 border border-rose-500/30 text-rose-300' : 'bg-zinc-800 text-zinc-500'
              }`}>
                <Bell className="w-4 h-4" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-start justify-between gap-2">
                  <p className="text-sm font-medium text-zinc-100">{n.title}</p>
                  <span className="text-xs text-zinc-500 shrink-0">{new Date(n.createdAt).toLocaleString()}</span>
                </div>
                <p className="text-xs text-zinc-400 mt-1">{n.message}</p>
                <p className="text-[10px] text-zinc-600 mt-1 uppercase tracking-wider">{n.type}</p>
              </div>
              {!n.read && (
                <button onClick={() => markRead(n.id)} className="text-xs text-rose-400 hover:text-rose-300 shrink-0">
                  <Check className="w-4 h-4" />
                </button>
              )}
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
