'use client';

import { useEffect, useState } from 'react';
import { customerApi } from '@/lib/frontend/api';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Shield, Plus, Trash2, Copy, Loader2 } from 'lucide-react';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogDescription,
} from '@/components/ui/dialog';
import { toast } from 'sonner';

export function CustomerApiKeys() {
  const [list, setList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: '', scopes: 'vps.view,vps.power,vps.stats' });
  const [newToken, setNewToken] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    const r = await customerApi.apiKeys();
    if (r.success && r.data) setList(r.data as any[]);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const submit = async () => {
    if (!form.name) return;
    const r = await customerApi.createApiKey(form.name, form.scopes);
    if (r.success && r.data?.token) {
      setNewToken(r.data.token);
      setForm({ name: '', scopes: 'vps.view,vps.power,vps.stats' });
      setOpen(false);
      load();
    }
  };

  const revoke = async (id: string) => {
    if (!confirm('Revoke this API token? This cannot be undone.')) return;
    await customerApi.revokeApiKey(id);
    load();
  };

  const copy = (text: string) => { navigator.clipboard.writeText(text); toast.success('Copied to clipboard'); };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold">API Tokens</h2>
          <p className="text-xs text-zinc-500">Manage API access tokens for your VPS</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="bg-rose-600 hover:bg-rose-500 text-white">
              <Plus className="w-4 h-4" /> Generate Token
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-zinc-950 border-zinc-800">
            <DialogHeader>
              <DialogTitle>Generate API Token</DialogTitle>
              <DialogDescription>The token will be shown only once. Copy it now.</DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-1.5">
                <Label>Name</Label>
                <Input value={form.name} onChange={(e) => setForm(p => ({ ...p, name: e.target.value }))}
                  placeholder="My CI/CD Token" className="bg-zinc-950/50 border-zinc-800" />
              </div>
              <div className="space-y-1.5">
                <Label>Scopes (comma-separated)</Label>
                <Input value={form.scopes} onChange={(e) => setForm(p => ({ ...p, scopes: e.target.value }))}
                  className="bg-zinc-950/50 border-zinc-800 font-mono text-xs" />
                <p className="text-[10px] text-zinc-500">Available: vps.view, vps.power, vps.stats, vps.console, ssh_keys.manage</p>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setOpen(false)} className="border-zinc-800">Cancel</Button>
              <Button onClick={submit} className="bg-rose-600 hover:bg-rose-500 text-white">Generate</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {newToken && (
        <Card className="glass-panel-red p-4 border-rose-500/30">
          <div className="flex items-start justify-between gap-3 mb-2">
            <div>
              <p className="text-sm font-medium text-rose-200">New API Token Generated</p>
              <p className="text-xs text-zinc-400">Copy this token now — it will not be shown again.</p>
            </div>
            <Button size="sm" onClick={() => copy(newToken)} className="bg-rose-600 hover:bg-rose-500 text-white">
              <Copy className="w-3 h-3" /> Copy
            </Button>
          </div>
          <pre className="text-xs font-mono text-zinc-300 bg-black p-3 rounded border border-zinc-800 break-all whitespace-pre-wrap">{newToken}</pre>
          <Button size="sm" variant="ghost" onClick={() => setNewToken(null)} className="mt-2 text-zinc-400 hover:text-white">
            Dismiss
          </Button>
        </Card>
      )}

      <div className="space-y-2">
        {loading ? (
          <div className="flex justify-center py-8"><Loader2 className="w-5 h-5 text-rose-400 animate-spin" /></div>
        ) : list.length === 0 ? (
          <Card className="glass-panel p-8 text-center">
            <Shield className="w-10 h-10 text-zinc-700 mx-auto mb-2" />
            <p className="text-sm text-zinc-500">No API tokens generated</p>
          </Card>
        ) : list.map(k => (
          <Card key={k.id} className="glass-panel p-4">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-md bg-rose-500/10 border border-rose-500/30 flex items-center justify-center shrink-0">
                <Shield className="w-4 h-4 text-rose-400" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium">{k.name}</p>
                <p className="text-xs text-zinc-500 font-mono">scopes: {k.scopes}</p>
                <div className="flex items-center gap-3 mt-1 text-[10px] text-zinc-600">
                  <span>Created: {new Date(k.createdAt).toLocaleDateString()}</span>
                  {k.lastUsedAt && <span>Last used: {new Date(k.lastUsedAt).toLocaleDateString()}</span>}
                  {k.expiresAt && <span>Expires: {new Date(k.expiresAt).toLocaleDateString()}</span>}
                </div>
              </div>
              <Button size="sm" variant="ghost" onClick={() => revoke(k.id)} className="h-7 w-7 p-0 text-red-400 hover:text-red-300">
                <Trash2 className="w-3.5 h-3.5" />
              </Button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
