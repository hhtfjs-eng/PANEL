'use client';

import { useEffect, useState } from 'react';
import { useAppStore } from '@/lib/frontend/store';
import { customerApi } from '@/lib/frontend/api';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { StatCard } from '@/components/shared/stat-card';
import { StatusBadge } from '@/components/shared/status-badge';
import {
  HardDrive, Play, Square, Activity, Bell, LifeBuoy, Server, Cpu,
  AlertCircle, ExternalLink, RefreshCw,
} from 'lucide-react';
import { Loader2 } from 'lucide-react';

export function CustomerDashboard() {
  const { user, setView } = useAppStore();
  const [loading, setLoading] = useState(true);
  const [vps, setVps] = useState<any[]>([]);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [stats, setStats] = useState({ total: 0, running: 0, stopped: 0, suspended: 0 });

  const load = async () => {
    setLoading(true);
    const [vpsRes, notifRes] = await Promise.all([
      customerApi.listVps({ pageSize: 5 }),
      customerApi.notifications(),
    ]);
    if (vpsRes.success && vpsRes.data) {
      const list = vpsRes.data as any[];
      setVps(list);
      setStats({
        total: vpsRes.pagination?.total || list.length,
        running: list.filter(v => v.status === 'RUNNING').length,
        stopped: list.filter(v => v.status === 'STOPPED').length,
        suspended: list.filter(v => v.status === 'SUSPENDED').length,
      });
    }
    if (notifRes.success && notifRes.data) setNotifications(notifRes.data.slice(0, 5));
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-6 h-6 text-rose-400 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Welcome */}
      <Card className="glass-panel-red p-6 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-rose-950/40 to-transparent pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <p className="text-xs uppercase tracking-wider text-rose-300/80">Welcome back</p>
            <h2 className="text-2xl font-bold mt-1">{user?.name}</h2>
            <p className="text-sm text-zinc-400 mt-1">
              {stats.total > 0
                ? `You have ${stats.total} VPS assigned to your account.`
                : 'No VPS have been assigned to your account yet.'}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button onClick={load} variant="outline" size="sm" className="border-zinc-800 hover:bg-zinc-900">
              <RefreshCw className="w-4 h-4" /> Refresh
            </Button>
            <Button onClick={() => setView('support')} size="sm" className="bg-rose-600 hover:bg-rose-500">
              <LifeBuoy className="w-4 h-4" /> Support
            </Button>
          </div>
        </div>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Total VPS" value={stats.total} icon={HardDrive} tone="default" hint="Assigned to you" />
        <StatCard label="Running" value={stats.running} icon={Play} tone="emerald" hint="Active servers" />
        <StatCard label="Stopped" value={stats.stopped} icon={Square} tone="amber" hint="Powered off" />
        <StatCard label="Suspended" value={stats.suspended} icon={AlertCircle} tone="red" hint="By administrator" />
      </div>

      {/* Provisioning notice — explicit message that customer can't deploy */}
      <Card className="glass-panel p-5 border-amber-500/20 bg-amber-950/10">
        <div className="flex items-start gap-3">
          <div className="w-9 h-9 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center shrink-0">
            <AlertCircle className="w-4 h-4 text-amber-300" />
          </div>
          <div>
            <p className="text-sm font-semibold text-amber-100">VPS Provisioning is Admin-Only</p>
            <p className="text-xs text-zinc-400 mt-1 leading-relaxed">
              This platform enforces admin-controlled provisioning. Customers cannot create or deploy VPS instances.
              To request new infrastructure, please open a support ticket or contact your hosting administrator.
            </p>
          </div>
        </div>
      </Card>

      {/* Recent VPS */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold uppercase tracking-wider text-zinc-400">Recent VPS</h3>
          <button onClick={() => setView('vps')} className="text-xs text-rose-400 hover:text-rose-300 flex items-center gap-1">
            View all <ExternalLink className="w-3 h-3" />
          </button>
        </div>
        <div className="space-y-3">
          {vps.length === 0 ? (
            <Card className="glass-panel p-8 text-center">
              <Server className="w-10 h-10 text-zinc-700 mx-auto mb-2" />
              <p className="text-sm text-zinc-500">No VPS assigned yet</p>
            </Card>
          ) : vps.map(v => (
            <Card key={v.id} className="glass-panel p-4 hover:border-rose-500/30 transition-colors cursor-pointer"
              onClick={() => setView('vps-detail', { id: v.id })}>
              <div className="flex items-center gap-4 flex-wrap">
                <div className="w-10 h-10 rounded-lg bg-rose-500/10 border border-rose-500/30 flex items-center justify-center shrink-0">
                  <HardDrive className="w-5 h-5 text-rose-400" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="font-medium truncate">{v.name}</p>
                  <p className="text-xs text-zinc-500 font-mono truncate">{v.hostname}</p>
                </div>
                <div className="hidden md:flex items-center gap-4 text-xs text-zinc-400">
                  <div className="flex items-center gap-1.5"><Cpu className="w-3 h-3" /> {v.cpu} vCPU / {(v.ramMb / 1024).toFixed(0)} GB</div>
                  {v.ipv4 && <div className="font-mono">{v.ipv4}</div>}
                  {v.node && <div>{v.node.region}</div>}
                </div>
                <StatusBadge status={v.status} />
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* Recent activity / notifications */}
      <div className="grid lg:grid-cols-2 gap-4">
        <Card className="glass-panel p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold uppercase tracking-wider text-zinc-400">Recent Notifications</h3>
            <Bell className="w-4 h-4 text-zinc-500" />
          </div>
          <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
            {notifications.length === 0 ? (
              <p className="text-xs text-zinc-500 py-4 text-center">No notifications</p>
            ) : notifications.map(n => (
              <div key={n.id} className="p-3 rounded-md bg-zinc-900/60 border border-zinc-800 text-xs">
                <div className="flex items-start justify-between gap-2 mb-1">
                  <p className="font-medium text-zinc-200">{n.title}</p>
                  <span className="text-zinc-600 text-[10px]">{new Date(n.createdAt).toLocaleString()}</span>
                </div>
                <p className="text-zinc-400 leading-snug">{n.message}</p>
              </div>
            ))}
          </div>
        </Card>

        <Card className="glass-panel p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold uppercase tracking-wider text-zinc-400">Quick Actions</h3>
            <Activity className="w-4 h-4 text-zinc-500" />
          </div>
          <div className="space-y-2">
            <button onClick={() => setView('vps')}
              className="w-full p-3 rounded-md bg-zinc-900/60 border border-zinc-800 hover:border-rose-500/30 hover:bg-zinc-900 text-left transition-colors">
              <p className="text-sm font-medium">View My VPS</p>
              <p className="text-xs text-zinc-500">List all servers assigned to your account</p>
            </button>
            <button onClick={() => setView('support')}
              className="w-full p-3 rounded-md bg-zinc-900/60 border border-zinc-800 hover:border-rose-500/30 hover:bg-zinc-900 text-left transition-colors">
              <p className="text-sm font-medium">Open Support Ticket</p>
              <p className="text-xs text-zinc-500">Request changes, report issues, or ask for help</p>
            </button>
            <button onClick={() => setView('ssh-keys')}
              className="w-full p-3 rounded-md bg-zinc-900/60 border border-zinc-800 hover:border-rose-500/30 hover:bg-zinc-900 text-left transition-colors">
              <p className="text-sm font-medium">Manage SSH Keys</p>
              <p className="text-xs text-zinc-500">Add public keys for future VPS deployments</p>
            </button>
          </div>
        </Card>
      </div>
    </div>
  );
}
