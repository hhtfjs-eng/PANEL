'use client';

import { useEffect, useState } from 'react';
import { customerApi } from '@/lib/frontend/api';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Key, Plus, Trash2, Copy, Loader2 } from 'lucide-react';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter,
} from '@/components/ui/dialog';

export function CustomerSshKeys() {
  const [list, setList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: '', publicKey: '' });

  const load = async () => {
    setLoading(true);
    const r = await customerApi.sshKeys();
    if (r.success && r.data) setList(r.data as any[]);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const submit = async () => {
    if (!form.name || !form.publicKey) return;
    await customerApi.addSshKey(form.name, form.publicKey);
    setForm({ name: '', publicKey: '' });
    setOpen(false);
    load();
  };

  const remove = async (id: string) => {
    if (!confirm('Delete this SSH key?')) return;
    await customerApi.deleteSshKey(id);
    load();
  };

  const copy = (text: string) => navigator.clipboard.writeText(text);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold">SSH Keys</h2>
          <p className="text-xs text-zinc-500">Public keys for VPS deployments</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="bg-rose-600 hover:bg-rose-500 text-white">
              <Plus className="w-4 h-4" /> Add Key
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-zinc-950 border-zinc-800">
            <DialogHeader>
              <DialogTitle>Add SSH Public Key</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-1.5">
                <Label>Name</Label>
                <Input value={form.name} onChange={(e) => setForm(p => ({ ...p, name: e.target.value }))}
                  placeholder="My Laptop Key" className="bg-zinc-950/50 border-zinc-800" />
              </div>
              <div className="space-y-1.5">
                <Label>Public Key</Label>
                <textarea
                  value={form.publicKey}
                  onChange={(e) => setForm(p => ({ ...p, publicKey: e.target.value }))}
                  placeholder="ssh-rsa AAAA... or ssh-ed25519 AAAA..."
                  className="w-full min-h-24 p-2 text-xs font-mono rounded-md bg-zinc-950/50 border border-zinc-800"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setOpen(false)} className="border-zinc-800">Cancel</Button>
              <Button onClick={submit} className="bg-rose-600 hover:bg-rose-500 text-white">Add Key</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="space-y-2">
        {loading ? (
          <div className="flex justify-center py-8"><Loader2 className="w-5 h-5 text-rose-400 animate-spin" /></div>
        ) : list.length === 0 ? (
          <Card className="glass-panel p-8 text-center">
            <Key className="w-10 h-10 text-zinc-700 mx-auto mb-2" />
            <p className="text-sm text-zinc-500">No SSH keys added yet</p>
          </Card>
        ) : list.map(k => (
          <Card key={k.id} className="glass-panel p-4">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-md bg-rose-500/10 border border-rose-500/30 flex items-center justify-center shrink-0">
                <Key className="w-4 h-4 text-rose-400" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium">{k.name}</p>
                <p className="text-xs text-zinc-500 font-mono truncate">{k.fingerprint}</p>
                <p className="text-[10px] text-zinc-600 mt-1">Added: {new Date(k.createdAt).toLocaleDateString()}</p>
              </div>
              <div className="flex gap-1">
                <Button size="sm" variant="ghost" onClick={() => copy(k.publicKey)} className="h-7 w-7 p-0 text-zinc-400 hover:text-white">
                  <Copy className="w-3.5 h-3.5" />
                </Button>
                <Button size="sm" variant="ghost" onClick={() => remove(k.id)} className="h-7 w-7 p-0 text-red-400 hover:text-red-300">
                  <Trash2 className="w-3.5 h-3.5" />
                </Button>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
