'use client';

import { useEffect, useState } from 'react';
import { adminApi, friendlyMessage } from '@/lib/frontend/api';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { StatusBadge } from '@/components/shared/status-badge';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import {
  Package, Plus, RefreshCw, Loader2, Trash2, Cpu, MemoryStick, HardDrive, Network,
  MonitorSmartphone, Activity, CheckCircle2, XCircle, AlertCircle,
} from 'lucide-react';
import { toast } from 'sonner';
import { useAppStore } from '@/lib/frontend/store';

export function AdminPlans() {
  const [list, setList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<any>({
    name: '', cpu: 2, ramMb: 4096, diskGb: 80, bandwidthMbps: 2000,
    ipv4Included: true, ipv6Included: true, region: 'global', priceMonthly: 5, setupFee: 0, enabled: true,
  });

  const load = async () => {
    setLoading(true);
    const r = await adminApi.plans();
    if (r.success && r.data) setList(r.data);
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const submit = async () => {
    const r = await adminApi.createPlan(form);
    if (r.success) { toast.success('Plan created'); setOpen(false); load(); }
    else toast.error(`Failed: ${friendlyMessage(r)}`);
  };

  const remove = async (id: string) => {
    if (!confirm('Delete this plan?')) return;
    const r = await adminApi.deletePlan(id);
    if (r.success) { toast.success('Plan deleted'); load(); }
    else toast.error(`Failed: ${friendlyMessage(r)}`);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2">VPS Plans <Badge variant="outline" className="bg-rose-500/10 text-rose-300 border-rose-500/30">Admin</Badge></h2>
          <p className="text-xs text-zinc-500">Resource templates used for VPS deployment</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={load} variant="outline" size="sm" className="border-zinc-800"><RefreshCw className="w-4 h-4" /></Button>
          <Button onClick={() => setOpen(true)} size="sm" className="bg-rose-600 hover:bg-rose-500 text-white"><Plus className="w-4 h-4" /> Add Plan</Button>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-12"><Loader2 className="w-6 h-6 text-rose-400 animate-spin" /></div>
      ) : (
        <div className="grid lg:grid-cols-2 gap-4">
          {list.map(p => (
            <Card key={p.id} className="glass-panel p-5">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <p className="font-semibold text-lg">{p.name}</p>
                  <p className="text-xs text-zinc-500">{p.region}</p>
                </div>
                <Badge variant="outline" className={p.enabled ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30' : 'bg-zinc-500/10 text-zinc-500 border-zinc-500/30'}>
                  {p.enabled ? 'Enabled' : 'Disabled'}
                </Badge>
              </div>
              <div className="grid grid-cols-4 gap-3 mt-3 text-center">
                <div className="p-2 rounded-md bg-zinc-900/60 border border-zinc-800">
                  <Cpu className="w-4 h-4 text-rose-400 mx-auto mb-1" />
                  <p className="text-xs text-zinc-500">CPU</p>
                  <p className="font-mono">{p.cpu}</p>
                </div>
                <div className="p-2 rounded-md bg-zinc-900/60 border border-zinc-800">
                  <MemoryStick className="w-4 h-4 text-amber-400 mx-auto mb-1" />
                  <p className="text-xs text-zinc-500">RAM</p>
                  <p className="font-mono">{(p.ramMb / 1024).toFixed(0)}G</p>
                </div>
                <div className="p-2 rounded-md bg-zinc-900/60 border border-zinc-800">
                  <HardDrive className="w-4 h-4 text-emerald-400 mx-auto mb-1" />
                  <p className="text-xs text-zinc-500">Disk</p>
                  <p className="font-mono">{p.diskGb}G</p>
                </div>
                <div className="p-2 rounded-md bg-zinc-900/60 border border-zinc-800">
                  <Network className="w-4 h-4 text-sky-400 mx-auto mb-1" />
                  <p className="text-xs text-zinc-500">Net</p>
                  <p className="font-mono">{(p.bandwidthMbps / 1000).toFixed(0)}G</p>
                </div>
              </div>
              <div className="flex items-center justify-between mt-3 pt-3 border-t border-zinc-800">
                <div>
                  <p className="text-xs text-zinc-500">Monthly</p>
                  <p className="font-semibold">${p.priceMonthly.toFixed(2)} <span className="text-xs text-zinc-500">+ ${p.setupFee.toFixed(2)} setup</span></p>
                </div>
                <Button size="sm" variant="ghost" onClick={() => remove(p.id)} className="text-red-400 hover:text-red-300 h-7 w-7 p-0"><Trash2 className="w-3.5 h-3.5" /></Button>
              </div>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="bg-zinc-950 border-zinc-800">
          <DialogHeader><DialogTitle>Create VPS Plan</DialogTitle></DialogHeader>
          <div className="space-y-3 py-4 grid grid-cols-2 gap-3">
            <div className="col-span-2"><Label>Name</Label><Input value={form.name} onChange={e => setForm({...form, name: e.target.value})} placeholder="Starter VPS" className="bg-zinc-950/50 border-zinc-800" /></div>
            <div><Label>CPU</Label><Input type="number" value={form.cpu} onChange={e => setForm({...form, cpu: +e.target.value})} className="bg-zinc-950/50 border-zinc-800" /></div>
            <div><Label>RAM (GB)</Label><Input type="number" min={0.5} step={0.5} value={form.ramMb / 1024} onChange={e => setForm({...form, ramMb: Math.round(+e.target.value * 1024)})} className="bg-zinc-950/50 border-zinc-800" /></div>
            <div><Label>Disk (GB)</Label><Input type="number" value={form.diskGb} onChange={e => setForm({...form, diskGb: +e.target.value})} className="bg-zinc-950/50 border-zinc-800" /></div>
            <div><Label>Bandwidth (Mbps)</Label><Input type="number" value={form.bandwidthMbps} onChange={e => setForm({...form, bandwidthMbps: +e.target.value})} className="bg-zinc-950/50 border-zinc-800" /></div>
            <div><Label>Monthly Price ($)</Label><Input type="number" step="0.01" value={form.priceMonthly} onChange={e => setForm({...form, priceMonthly: +e.target.value})} className="bg-zinc-950/50 border-zinc-800" /></div>
            <div><Label>Setup Fee ($)</Label><Input type="number" step="0.01" value={form.setupFee} onChange={e => setForm({...form, setupFee: +e.target.value})} className="bg-zinc-950/50 border-zinc-800" /></div>
            <div className="col-span-2"><Label>Region</Label><Input value={form.region} onChange={e => setForm({...form, region: e.target.value})} className="bg-zinc-950/50 border-zinc-800" /></div>
            <div className="col-span-2 flex items-center gap-4">
              <label className="flex items-center gap-2 text-sm"><Switch checked={form.ipv4Included} onCheckedChange={v => setForm({...form, ipv4Included: v})} /> IPv4 included</label>
              <label className="flex items-center gap-2 text-sm"><Switch checked={form.ipv6Included} onCheckedChange={v => setForm({...form, ipv6Included: v})} /> IPv6 included</label>
              <label className="flex items-center gap-2 text-sm"><Switch checked={form.enabled} onCheckedChange={v => setForm({...form, enabled: v})} /> Enabled</label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)} className="border-zinc-800">Cancel</Button>
            <Button onClick={submit} className="bg-rose-600 hover:bg-rose-500 text-white">Create Plan</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ============================================================
// OS Management
// ============================================================
export function AdminOs() {
  const [list, setList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<any>({
    name: '', distribution: '', version: '', providerTemplateId: '',
    architecture: 'x86_64', available: true,
  });

  const load = async () => {
    setLoading(true);
    const r = await adminApi.os();
    if (r.success && r.data) setList(r.data);
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const submit = async () => {
    const r = await adminApi.createOs(form);
    if (r.success) { toast.success('OS template created'); setOpen(false); load(); }
    else toast.error(`Failed: ${friendlyMessage(r)}`);
  };

  const remove = async (id: string) => {
    if (!confirm('Delete this OS template?')) return;
    const r = await adminApi.deleteOs(id);
    if (r.success) { toast.success('OS deleted'); load(); }
    else toast.error(`Failed: ${friendlyMessage(r)}`);
  };

  const seedProxmox = async () => {
    const r = await adminApi.osSeedProxmox();
    if (r.success) {
      toast.success(`Added ${r.data?.added ?? 0} Proxmox templates (${r.data?.total ?? 0} in catalog)`);
      load();
    } else toast.error(`Failed: ${friendlyMessage(r)}`);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2">OS Templates <Badge variant="outline" className="bg-rose-500/10 text-rose-300 border-rose-500/30">Admin</Badge></h2>
          <p className="text-xs text-zinc-500">Operating system images available for VPS deployment</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={load} variant="outline" size="sm" className="border-zinc-800"><RefreshCw className="w-4 h-4" /></Button>
          <Button onClick={seedProxmox} variant="outline" size="sm" className="border-orange-700/50 text-orange-300 hover:text-orange-200 hover:bg-orange-500/10"><MonitorSmartphone className="w-4 h-4" /> Add Proxmox Templates</Button>
          <Button onClick={() => setOpen(true)} size="sm" className="bg-rose-600 hover:bg-rose-500 text-white"><Plus className="w-4 h-4" /> Add OS</Button>
        </div>
      </div>

      <Card className="glass-panel overflow-hidden p-0">
        <Table>
          <TableHeader>
            <TableRow className="border-zinc-800 hover:bg-transparent">
              <TableHead className="text-zinc-500">OS</TableHead>
              <TableHead className="text-zinc-500">Distribution</TableHead>
              <TableHead className="text-zinc-500">Version</TableHead>
              <TableHead className="text-zinc-500 hidden md:table-cell">Architecture</TableHead>
              <TableHead className="text-zinc-500 hidden lg:table-cell">Provider Template</TableHead>
              <TableHead className="text-zinc-500">Available</TableHead>
              <TableHead></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow><TableCell colSpan={6} className="text-center py-12"><Loader2 className="w-5 h-5 animate-spin mx-auto text-zinc-500" /></TableCell></TableRow>
            ) : list.map(o => (
              <TableRow key={o.id} className="border-zinc-800">
                <TableCell className="font-medium">{o.name}</TableCell>
                <TableCell className="text-zinc-300">{o.distribution}</TableCell>
                <TableCell className="font-mono">{o.version}</TableCell>
                <TableCell className="hidden md:table-cell font-mono text-xs">{o.architecture}</TableCell>
                <TableCell className="hidden lg:table-cell font-mono text-xs text-zinc-500">{o.providerTemplateId || '—'}</TableCell>
                <TableCell>{o.available ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <XCircle className="w-4 h-4 text-zinc-600" />}</TableCell>
                <TableCell><Button size="sm" variant="ghost" onClick={() => remove(o.id)} className="h-7 w-7 p-0 text-red-400 hover:text-red-300"><Trash2 className="w-3.5 h-3.5" /></Button></TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="bg-zinc-950 border-zinc-800">
          <DialogHeader><DialogTitle>Add OS Template</DialogTitle></DialogHeader>
          <div className="space-y-3 py-4 grid grid-cols-2 gap-3">
            <div><Label>Name</Label><Input value={form.name} onChange={e => setForm({...form, name: e.target.value})} placeholder="Ubuntu 24.04 LTS" className="bg-zinc-950/50 border-zinc-800" /></div>
            <div><Label>Distribution</Label><Input value={form.distribution} onChange={e => setForm({...form, distribution: e.target.value})} placeholder="ubuntu" className="bg-zinc-950/50 border-zinc-800 font-mono text-sm" /></div>
            <div><Label>Version</Label><Input value={form.version} onChange={e => setForm({...form, version: e.target.value})} placeholder="24.04" className="bg-zinc-950/50 border-zinc-800 font-mono text-sm" /></div>
            <div><Label>Provider Template ID</Label><Input value={form.providerTemplateId} onChange={e => setForm({...form, providerTemplateId: e.target.value})} placeholder="ubuntu-2404" className="bg-zinc-950/50 border-zinc-800 font-mono text-sm" /></div>
            <div><Label>Architecture</Label><Input value={form.architecture} onChange={e => setForm({...form, architecture: e.target.value})} className="bg-zinc-950/50 border-zinc-800 font-mono text-sm" /></div>
            <div className="flex items-center"><label className="flex items-center gap-2 text-sm"><Switch checked={form.available} onCheckedChange={v => setForm({...form, available: v})} /> Available</label></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)} className="border-zinc-800">Cancel</Button>
            <Button onClick={submit} className="bg-rose-600 hover:bg-rose-500 text-white">Add OS</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ============================================================
// IP Management
// ============================================================
export function AdminIps() {
  const [data, setData] = useState<{ pools: any[]; ips: any[] }>({ pools: [], ips: [] });
  const [loading, setLoading] = useState(true);
  const [poolOpen, setPoolOpen] = useState(false);
  const [ipOpen, setIpOpen] = useState(false);
  const [poolForm, setPoolForm] = useState<any>({ name: '', family: 4, cidr: '', gateway: '', dnsPrimary: '', dnsSecondary: '' });
  const [ipForm, setIpForm] = useState<any>({ poolId: '', address: '', family: 4 });

  const load = async () => {
    setLoading(true);
    const r = await adminApi.ips();
    if (r.success && r.data) setData(r.data as any);
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const createPool = async () => {
    const r = await adminApi.ipAction({ action: 'create_pool', ...poolForm });
    if (r.success) { toast.success('Pool created'); setPoolOpen(false); load(); }
    else toast.error(`Failed: ${friendlyMessage(r)}`);
  };

  const addIp = async () => {
    const r = await adminApi.ipAction({ action: 'add_ip', ...ipForm });
    if (r.success) { toast.success('IP added'); setIpOpen(false); load(); }
    else toast.error(`Failed: ${friendlyMessage(r)}`);
  };

  const release = async (id: string) => {
    if (!confirm('Release this IP?')) return;
    await adminApi.ipAction({ action: 'release', ipId: id });
    load();
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2">IP Management <Badge variant="outline" className="bg-rose-500/10 text-rose-300 border-rose-500/30">Admin</Badge></h2>
          <p className="text-xs text-zinc-500">IP pools and address allocations</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={load} variant="outline" size="sm" className="border-zinc-800"><RefreshCw className="w-4 h-4" /></Button>
          <Button onClick={() => setPoolOpen(true)} variant="outline" size="sm" className="border-zinc-800"><Package className="w-4 h-4" /> New Pool</Button>
          <Button onClick={() => setIpOpen(true)} size="sm" className="bg-rose-600 hover:bg-rose-500 text-white"><Plus className="w-4 h-4" /> Add IP</Button>
        </div>
      </div>

      {/* Pools */}
      <Card className="glass-panel p-5">
        <h3 className="text-sm font-semibold uppercase tracking-wider text-zinc-500 mb-3">IP Pools</h3>
        {data.pools.length === 0 ? (
          <p className="text-sm text-zinc-500 py-4 text-center">No IP pools</p>
        ) : (
          <div className="grid lg:grid-cols-2 gap-3">
            {data.pools.map(p => (
              <div key={p.id} className="p-3 rounded-md bg-zinc-900/60 border border-zinc-800">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">{p.name}</p>
                    <p className="text-xs text-zinc-500 font-mono">{p.cidr} · IPv{p.family}</p>
                  </div>
                  <Badge variant="outline" className="bg-zinc-800 text-zinc-300 border-zinc-700">{p._count?.ips || 0} IPs</Badge>
                </div>
                <div className="mt-2 text-xs text-zinc-500">
                  Gateway: <span className="font-mono text-zinc-300">{p.gateway || '—'}</span>
                  {p.dnsPrimary && <span> · DNS: <span className="font-mono text-zinc-300">{p.dnsPrimary}</span></span>}
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* IPs */}
      <Card className="glass-panel overflow-hidden p-0">
        <Table>
          <TableHeader>
            <TableRow className="border-zinc-800 hover:bg-transparent">
              <TableHead className="text-zinc-500">Address</TableHead>
              <TableHead className="text-zinc-500">Family</TableHead>
              <TableHead className="text-zinc-500">Pool</TableHead>
              <TableHead className="text-zinc-500">State</TableHead>
              <TableHead className="text-zinc-500 hidden md:table-cell">VPS</TableHead>
              <TableHead className="text-zinc-500 hidden lg:table-cell">Reverse DNS</TableHead>
              <TableHead></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow><TableCell colSpan={7} className="text-center py-12"><Loader2 className="w-5 h-5 animate-spin mx-auto text-zinc-500" /></TableCell></TableRow>
            ) : data.ips.length === 0 ? (
              <TableRow><TableCell colSpan={7} className="text-center py-12 text-zinc-500">No IPs</TableCell></TableRow>
            ) : data.ips.map(ip => (
              <TableRow key={ip.id} className="border-zinc-800">
                <TableCell className="font-mono text-sm">{ip.address}</TableCell>
                <TableCell className="text-xs">v{ip.family}</TableCell>
                <TableCell className="text-xs">{ip.pool?.name || '—'}</TableCell>
                <TableCell><StatusBadge status={ip.state} size="sm" /></TableCell>
                <TableCell className="hidden md:table-cell text-xs text-zinc-400">{ip.vps?.name || '—'}</TableCell>
                <TableCell className="hidden lg:table-cell text-xs font-mono text-zinc-400">{ip.reverseDns || '—'}</TableCell>
                <TableCell>
                  {ip.state === 'ASSIGNED' && <Button size="sm" variant="ghost" onClick={() => release(ip.id)} className="h-7 w-7 p-0 text-amber-400 hover:text-amber-300"><RefreshCw className="w-3.5 h-3.5" /></Button>}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>

      <Dialog open={poolOpen} onOpenChange={setPoolOpen}>
        <DialogContent className="bg-zinc-950 border-zinc-800">
          <DialogHeader><DialogTitle>Create IP Pool</DialogTitle></DialogHeader>
          <div className="space-y-3 py-4">
            <div><Label>Name</Label><Input value={poolForm.name} onChange={e => setPoolForm({...poolForm, name: e.target.value})} placeholder="main-v4" className="bg-zinc-950/50 border-zinc-800" /></div>
            <div><Label>Family</Label>
              <Select value={String(poolForm.family)} onValueChange={v => setPoolForm({...poolForm, family: +v})}>
                <SelectTrigger className="bg-zinc-950/50 border-zinc-800"><SelectValue /></SelectTrigger>
                <SelectContent className="bg-zinc-950 border-zinc-800"><SelectItem value="4">IPv4</SelectItem><SelectItem value="6">IPv6</SelectItem></SelectContent>
              </Select>
            </div>
            <div><Label>CIDR</Label><Input value={poolForm.cidr} onChange={e => setPoolForm({...poolForm, cidr: e.target.value})} placeholder="10.0.0.0/24" className="bg-zinc-950/50 border-zinc-800 font-mono text-sm" /></div>
            <div><Label>Gateway</Label><Input value={poolForm.gateway} onChange={e => setPoolForm({...poolForm, gateway: e.target.value})} className="bg-zinc-950/50 border-zinc-800 font-mono text-sm" /></div>
            <div><Label>DNS Primary</Label><Input value={poolForm.dnsPrimary} onChange={e => setPoolForm({...poolForm, dnsPrimary: e.target.value})} className="bg-zinc-950/50 border-zinc-800 font-mono text-sm" /></div>
            <div><Label>DNS Secondary</Label><Input value={poolForm.dnsSecondary} onChange={e => setPoolForm({...poolForm, dnsSecondary: e.target.value})} className="bg-zinc-950/50 border-zinc-800 font-mono text-sm" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setPoolOpen(false)} className="border-zinc-800">Cancel</Button>
            <Button onClick={createPool} className="bg-rose-600 hover:bg-rose-500 text-white">Create Pool</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={ipOpen} onOpenChange={setIpOpen}>
        <DialogContent className="bg-zinc-950 border-zinc-800">
          <DialogHeader><DialogTitle>Add IP Address</DialogTitle></DialogHeader>
          <div className="space-y-3 py-4">
            <div><Label>Pool</Label>
              <Select value={ipForm.poolId} onValueChange={v => setIpForm({...ipForm, poolId: v, family: data.pools.find(p => p.id === v)?.family || 4})}>
                <SelectTrigger className="bg-zinc-950/50 border-zinc-800"><SelectValue placeholder="Select pool" /></SelectTrigger>
                <SelectContent className="bg-zinc-950 border-zinc-800">{data.pools.map(p => <SelectItem key={p.id} value={p.id}>{p.name} ({p.cidr})</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label>Address</Label><Input value={ipForm.address} onChange={e => setIpForm({...ipForm, address: e.target.value})} placeholder="10.0.0.5" className="bg-zinc-950/50 border-zinc-800 font-mono text-sm" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIpOpen(false)} className="border-zinc-800">Cancel</Button>
            <Button onClick={addIp} className="bg-rose-600 hover:bg-rose-500 text-white">Add IP</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ============================================================
// Deployments
// ============================================================
export function AdminDeployments() {
  const [list, setList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [state, setState] = useState('all');
  const [page, setPage] = useState(1);

  const load = async (silent = false) => {
    if (!silent) setLoading(true);
    const r = await adminApi.deployments({ state: state === 'all' ? '' : state, page, pageSize: 25 });
    if (r.success && r.data) setList(r.data);
    if (!silent) setLoading(false);
  };
  useEffect(() => { load(); const t = setInterval(() => load(true), 5000); return () => clearInterval(t); }, [state, page]);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2">Deployment Queue <Badge variant="outline" className="bg-rose-500/10 text-rose-300 border-rose-500/30">Admin</Badge></h2>
          <p className="text-xs text-zinc-500">Background provisioning jobs</p>
        </div>
        <div className="flex gap-2">
          <Select value={state} onValueChange={(v) => { setState(v); setPage(1); }}>
            <SelectTrigger className="w-44 bg-zinc-950/50 border-zinc-800"><SelectValue /></SelectTrigger>
            <SelectContent className="bg-zinc-950 border-zinc-800">
              <SelectItem value="all">All states</SelectItem>
              <SelectItem value="QUEUED">Queued</SelectItem>
              <SelectItem value="CREATING_VM">Creating VM</SelectItem>
              <SelectItem value="INSTALLING_OS">Installing OS</SelectItem>
              <SelectItem value="COMPLETED">Completed</SelectItem>
              <SelectItem value="FAILED">Failed</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Card className="glass-panel overflow-hidden p-0">
        <Table>
          <TableHeader>
            <TableRow className="border-zinc-800 hover:bg-transparent">
              <TableHead className="text-zinc-500">VPS</TableHead>
              <TableHead className="text-zinc-500">State</TableHead>
              <TableHead className="text-zinc-500">Progress</TableHead>
              <TableHead className="text-zinc-500 hidden md:table-cell">Initiated By</TableHead>
              <TableHead className="text-zinc-500 hidden lg:table-cell">Started</TableHead>
              <TableHead className="text-zinc-500 hidden lg:table-cell">Completed</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow><TableCell colSpan={6} className="text-center py-12"><Loader2 className="w-5 h-5 animate-spin mx-auto text-zinc-500" /></TableCell></TableRow>
            ) : list.length === 0 ? (
              <TableRow><TableCell colSpan={6} className="text-center py-12 text-zinc-500">No deployment jobs</TableCell></TableRow>
            ) : list.map(j => (
              <TableRow key={j.id} className="border-zinc-800">
                <TableCell>
                  <p className="text-sm font-medium">{j.vps?.name || '—'}</p>
                  <p className="text-xs text-zinc-500 font-mono">{j.vps?.hostname}</p>
                </TableCell>
                <TableCell><StatusBadge status={j.state} size="sm" /></TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <div className="w-16 h-1.5 bg-zinc-900 rounded-full overflow-hidden">
                      <div className="h-full bg-rose-500 transition-all" style={{ width: `${j.progress}%` }} />
                    </div>
                    <span className="text-xs font-mono text-zinc-400">{j.progress}%</span>
                  </div>
                </TableCell>
                <TableCell className="hidden md:table-cell text-xs text-zinc-400">{j.initiatedBy?.email || '—'}</TableCell>
                <TableCell className="hidden lg:table-cell text-xs text-zinc-500">{j.startedAt ? new Date(j.startedAt).toLocaleString() : '—'}</TableCell>
                <TableCell className="hidden lg:table-cell text-xs text-zinc-500">{j.completedAt ? new Date(j.completedAt).toLocaleString() : '—'}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}

// ============================================================
// Audit Logs
// ============================================================
export function AdminAudit() {
  const [list, setList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  const load = async () => {
    setLoading(true);
    const r = await adminApi.audit({ action: search, page: 1, pageSize: 100 });
    if (r.success && r.data) setList(r.data);
    setLoading(false);
  };
  useEffect(() => { load(); }, []);
  useEffect(() => { const t = setTimeout(load, 350); return () => clearTimeout(t); }, [search]);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2">Audit Logs <Badge variant="outline" className="bg-rose-500/10 text-rose-300 border-rose-500/30">Admin</Badge></h2>
          <p className="text-xs text-zinc-500">All sensitive administrative actions</p>
        </div>
        <Button onClick={load} variant="outline" size="sm" className="border-zinc-800"><RefreshCw className="w-4 h-4" /></Button>
      </div>
      <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Filter by action (e.g. VPS_)" className="bg-zinc-950/50 border-zinc-800" />
      <Card className="glass-panel p-0 overflow-hidden">
        <div className="max-h-[70vh] overflow-y-auto">
          {loading ? (
            <p className="text-center py-12 text-zinc-500"><Loader2 className="w-5 h-5 animate-spin mx-auto" /></p>
          ) : list.length === 0 ? (
            <p className="text-center py-12 text-zinc-500">No audit entries</p>
          ) : list.map(a => (
            <div key={a.id} className="flex items-start gap-3 p-3 border-b border-zinc-900 hover:bg-zinc-900/40">
              <div className="w-7 h-7 rounded bg-rose-500/10 border border-rose-500/30 flex items-center justify-center shrink-0">
                {a.success ? <CheckCircle2 className="w-3 h-3 text-emerald-400" /> : <AlertCircle className="w-3 h-3 text-red-400" />}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <p className="text-sm font-mono text-zinc-200">{a.action}</p>
                  <span className="text-xs text-zinc-500">{new Date(a.createdAt).toLocaleString()}</span>
                </div>
                <p className="text-xs text-zinc-500">Actor: {a.actorRole || '—'}</p>
                {a.metadata && <p className="text-xs text-zinc-600 font-mono mt-1 truncate">{a.metadata}</p>}
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

// ============================================================
// Settings
// ============================================================
export function AdminSettings() {
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const refreshBrand = useAppStore(s => s.refreshBrand);

  const load = async () => {
    setLoading(true);
    const r = await adminApi.settings();
    if (r.success && r.data) setSettings(r.data);
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const update = async (key: string, value: string) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const save = async () => {
    setSaving(true);
    const r = await adminApi.updateSettings(settings);
    if (r.success) {
      toast.success('Settings saved');
      // Sync the brand (site name) everywhere immediately — sidebar, login page, title
      await refreshBrand();
    } else {
      toast.error(`Failed: ${friendlyMessage(r)}`);
    }
    setSaving(false);
  };

  if (loading) return <div className="flex justify-center py-12"><Loader2 className="w-6 h-6 text-rose-400 animate-spin" /></div>;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2">Settings <Badge variant="outline" className="bg-rose-500/10 text-rose-300 border-rose-500/30">Admin</Badge></h2>
          <p className="text-xs text-zinc-500">Platform configuration</p>
        </div>
        <Button onClick={save} disabled={saving} className="bg-rose-600 hover:bg-rose-500 text-white">
          {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />} Save
        </Button>
      </div>

      <Card className="glass-panel p-5">
        <h3 className="text-sm font-semibold uppercase tracking-wider text-zinc-500 mb-4">General</h3>
        <div className="space-y-3">
          <div><Label>Site Name</Label><Input value={settings['site.name'] || ''} onChange={e => update('site.name', e.target.value)} className="bg-zinc-950/50 border-zinc-800" /></div>
          <div><Label>Support Email</Label><Input value={settings['site.support_email'] || ''} onChange={e => update('site.support_email', e.target.value)} className="bg-zinc-950/50 border-zinc-800" /></div>
          <div><Label>Customer "No Provision" Message</Label><Input value={settings['customer.no_provision_message'] || ''} onChange={e => update('customer.no_provision_message', e.target.value)} className="bg-zinc-950/50 border-zinc-800" /></div>
        </div>
      </Card>

      <Card className="glass-panel p-5">
        <h3 className="text-sm font-semibold uppercase tracking-wider text-zinc-500 mb-4">Branding &amp; Links</h3>
        <div className="space-y-3">
          <div><Label>YouTube Channel URL (YT Owner button)</Label><Input value={settings['site.youtube_url'] || ''} onChange={e => update('site.youtube_url', e.target.value)} placeholder="https://www.youtube.com/channel/UCILvOqZhASpc_Pk0ULdrKUQ" className="bg-zinc-950/50 border-zinc-800" /></div>
          <div><Label>Discord Server Invite URL</Label><Input value={settings['site.discord_url'] || ''} onChange={e => update('site.discord_url', e.target.value)} placeholder="https://discord.gg/yourserver" className="bg-zinc-950/50 border-zinc-800" /></div>
          <div><Label>Watermark Text (bottom-right fixed)</Label><Input value={settings['site.watermark_text'] || ''} onChange={e => update('site.watermark_text', e.target.value)} placeholder="Leave empty to hide" className="bg-zinc-950/50 border-zinc-800" /></div>
          <div><Label>Owner Credit Text</Label><Input value={settings['site.owner_credit'] || ''} onChange={e => update('site.owner_credit', e.target.value)} placeholder="Made by YT" className="bg-zinc-950/50 border-zinc-800" /></div>
          <div><Label>Owner Credit Link URL (wraps the credit text in a link)</Label><Input value={settings['site.made_by_url'] || ''} onChange={e => update('site.made_by_url', e.target.value)} placeholder="https://www.youtube.com/@DevAVoid" className="bg-zinc-950/50 border-zinc-800" /></div>
          <p className="text-xs text-zinc-600">YT Owner / Discord Server buttons and the credit text appear on the login page below the auth card. The bottom-right global watermark is currently disabled.</p>
        </div>
      </Card>

      <Card className="glass-panel p-5">
        <h3 className="text-sm font-semibold uppercase tracking-wider text-zinc-500 mb-4">Login Page</h3>
        <div className="space-y-3">
          <div><Label>Headline — Top Line (red text)</Label><Input value={settings['auth.hero_top'] ?? 'Admin-Controlled'} onChange={e => update('auth.hero_top', e.target.value)} placeholder="Admin-Controlled" className="bg-zinc-950/50 border-zinc-800" /></div>
          <div><Label>Headline — Bottom Line</Label><Input value={settings['auth.hero_bottom'] ?? 'VPS Provisioning'} onChange={e => update('auth.hero_bottom', e.target.value)} placeholder="VPS Provisioning" className="bg-zinc-950/50 border-zinc-800" /></div>
          <div><Label>Description Text</Label><Input value={settings['auth.hero_description'] ?? 'A production-grade virtual infrastructure management platform. Built for hosting providers who need strict separation between customer and administrative actions.'} onChange={e => update('auth.hero_description', e.target.value)} placeholder="Description shown under the headline" className="bg-zinc-950/50 border-zinc-800" /></div>
          <p className="text-xs text-zinc-600">These power the big headline on the login page ("Admin-Controlled / VPS Provisioning"). Leave a field empty to hide that line. Refresh the login page after saving to see changes.</p>
        </div>
      </Card>

      <Card className="glass-panel p-5">
        <h3 className="text-sm font-semibold uppercase tracking-wider text-zinc-500 mb-4">Authentication</h3>
        <div className="space-y-3">
          <div><Label>Registration Enabled</Label><Input value={settings['auth.registration_enabled'] || ''} onChange={e => update('auth.registration_enabled', e.target.value)} placeholder="true or false" className="bg-zinc-950/50 border-zinc-800" /></div>
          <div><Label>Email Verification Required</Label><Input value={settings['auth.email_verification_required'] || ''} onChange={e => update('auth.email_verification_required', e.target.value)} placeholder="true or false" className="bg-zinc-950/50 border-zinc-800" /></div>
        </div>
      </Card>
    </div>
  );
}

// ============================================================
// Staff
// ============================================================
export function AdminStaff() {
  const [list, setList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [form, setForm] = useState<any>({ name: '', username: '', email: '', role: 'SUPPORT', password: '' });

  const load = async () => {
    setLoading(true);
    const r = await adminApi.staff();
    if (r.success && r.data) setList(r.data);
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const validate = (): string | null => {
    const f = form;
    if (!f.name?.trim()) return 'Name is required.';
    if (!/^[a-zA-Z0-9_]{3,30}$/.test(f.username || '')) return 'Username must be 3-30 characters — letters, numbers and underscores only.';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(f.email || '')) return 'Enter a valid email address.';
    if ((f.password || '').length < 8) return 'Password must be at least 8 characters long.';
    return null;
  };

  const submit = async () => {
    const err = validate();
    if (err) { setFormError(err); return; }
    setFormError(null);
    setBusy(true);
    const r = await adminApi.createStaff(form);
    setBusy(false);
    if (r.success) {
      toast.success('Staff account created — they can sign in with this email/username and password');
      setOpen(false);
      setForm({ name: '', username: '', email: '', role: 'SUPPORT', password: '' });
      load();
    } else {
      setFormError(friendlyMessage(r));
      toast.error(`Failed: ${friendlyMessage(r)}`);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2">Staff & Administrators <Badge variant="outline" className="bg-rose-500/10 text-rose-300 border-rose-500/30">Super Admin</Badge></h2>
          <p className="text-xs text-zinc-500">Manage staff and administrative roles</p>
        </div>
        <Button onClick={() => setOpen(true)} size="sm" className="bg-rose-600 hover:bg-rose-500 text-white"><Plus className="w-4 h-4" /> Add Staff</Button>
      </div>

      <Card className="glass-panel overflow-hidden p-0">
        <Table>
          <TableHeader>
            <TableRow className="border-zinc-800 hover:bg-transparent">
              <TableHead className="text-zinc-500">Name</TableHead>
              <TableHead className="text-zinc-500">Email</TableHead>
              <TableHead className="text-zinc-500">Role</TableHead>
              <TableHead className="text-zinc-500">Status</TableHead>
              <TableHead className="text-zinc-500 hidden lg:table-cell">Last Login</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow><TableCell colSpan={5} className="text-center py-12"><Loader2 className="w-5 h-5 animate-spin mx-auto text-zinc-500" /></TableCell></TableRow>
            ) : list.map(s => (
              <TableRow key={s.id} className="border-zinc-800">
                <TableCell><div className="flex items-center gap-3"><div className="w-8 h-8 rounded-full bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-xs uppercase text-rose-200">{s.name?.charAt(0)}</div><p className="font-medium">{s.name}</p></div></TableCell>
                <TableCell className="text-sm text-zinc-300">{s.email}</TableCell>
                <TableCell><Badge variant="outline" className="bg-rose-500/10 text-rose-300 border-rose-500/30">{s.role}</Badge></TableCell>
                <TableCell><StatusBadge status={s.status} size="sm" /></TableCell>
                <TableCell className="hidden lg:table-cell text-xs text-zinc-500">{s.lastLogin ? new Date(s.lastLogin).toLocaleDateString() : '—'}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>

      <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) setFormError(null); }}>
        <DialogContent className="bg-zinc-950 border-zinc-800">
          <DialogHeader><DialogTitle>Create Staff Account</DialogTitle></DialogHeader>
          <div className="space-y-3 py-4">
            <div><Label>Name</Label><Input value={form.name} onChange={e => setForm({...form, name: e.target.value})} className="bg-zinc-950/50 border-zinc-800" /></div>
            <div>
              <Label>Username</Label>
              <Input value={form.username} onChange={e => setForm({...form, username: e.target.value})} className="bg-zinc-950/50 border-zinc-800 font-mono" placeholder="e.g. john_staff" />
              <p className="text-xs text-zinc-500 mt-1">3-30 characters — letters, numbers and underscores only.</p>
            </div>
            <div><Label>Email</Label><Input type="text" inputMode="email" value={form.email} onChange={e => setForm({...form, email: e.target.value})} className="bg-zinc-950/50 border-zinc-800" /></div>
            <div><Label>Role</Label>
              <Select value={form.role} onValueChange={v => setForm({...form, role: v})}>
                <SelectTrigger className="bg-zinc-950/50 border-zinc-800"><SelectValue /></SelectTrigger>
                <SelectContent className="bg-zinc-950 border-zinc-800">
                  <SelectItem value="SUPPORT">SUPPORT</SelectItem>
                  <SelectItem value="STAFF">STAFF</SelectItem>
                  <SelectItem value="ADMIN">ADMIN</SelectItem>
                  <SelectItem value="SUPER_ADMIN">SUPER_ADMIN</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Password</Label>
              <Input type="password" value={form.password} onChange={e => setForm({...form, password: e.target.value})} className="bg-zinc-950/50 border-zinc-800" />
              <p className="text-xs text-zinc-500 mt-1">Minimum 8 characters — they will use this to sign in.</p>
            </div>
            {formError && (
              <div className="text-xs text-red-400 bg-red-500/10 border border-red-500/20 rounded px-3 py-2">{formError}</div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)} className="border-zinc-800" disabled={busy}>Cancel</Button>
            <Button onClick={submit} disabled={busy} className="bg-rose-600 hover:bg-rose-500 text-white">
              {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Create Staff'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ============================================================
// System Health (detailed)
// ============================================================
export function AdminHealth() {
  const [health, setHealth] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const load = async (silent = false) => {
    if (!silent) setLoading(true);
    const r = await adminApi.systemHealth();
    if (r.success && r.data) setHealth(r.data);
    if (!silent) setLoading(false);
  };
  useEffect(() => { load(); const t = setInterval(() => load(true), 10000); return () => clearInterval(t); }, []);

  if (loading || !health) return <div className="flex justify-center py-12"><Loader2 className="w-6 h-6 text-rose-400 animate-spin" /></div>;

  const cards = [
    { label: 'Database', status: health.db.status, info: health.db.latency },
    { label: 'Realtime Service', status: health.realtime.status, info: 'socket.io :3003' },
    { label: 'Queue', status: health.queue.status, info: `${health.queue.activeJobs} active jobs` },
    { label: 'Nodes', status: 'OK', info: `${health.nodes.total} total` },
    { label: 'VPS', status: 'OK', info: `${health.vps.total} total` },
    { label: 'Users', status: 'OK', info: `${health.users.total} total` },
    { label: 'Deployments', status: 'OK', info: `${health.deployments.total} total` },
    { label: 'Audit Logs', status: 'OK', info: `${health.audit.total} entries` },
  ];

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-lg font-semibold flex items-center gap-2">System Health <Badge variant="outline" className="bg-rose-500/10 text-rose-300 border-rose-500/30">Admin</Badge></h2>
        <p className="text-xs text-zinc-500">Real-time service status</p>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {cards.map(c => (
          <Card key={c.label} className="glass-panel p-4">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-zinc-300">{c.label}</p>
              <StatusBadge status={c.status === 'OK' ? 'RUNNING' : c.status === 'DEGRADED' ? 'DEGRADED' : 'OFFLINE'} size="sm" />
            </div>
            <p className="text-xs text-zinc-500 font-mono">{c.info}</p>
          </Card>
        ))}
      </div>

      {health.queue.jobs && health.queue.jobs.length > 0 && (
        <Card className="glass-panel p-5">
          <h3 className="text-sm font-semibold uppercase tracking-wider text-zinc-500 mb-4">Active Queue Jobs</h3>
          <div className="space-y-2">
            {health.queue.jobs.map((j: any) => (
              <div key={j.id} className="flex items-center justify-between p-2 rounded-md bg-zinc-900/60 border border-zinc-800">
                <p className="text-xs font-mono">{j.id}</p>
                <StatusBadge status={j.state} size="sm" />
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}
