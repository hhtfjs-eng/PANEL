'use client';

import { useEffect, useRef, useState } from 'react';
import { adminApi, friendlyMessage } from '@/lib/frontend/api';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { StatusBadge } from '@/components/shared/status-badge';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import {
  LifeBuoy, Loader2, RefreshCw, Send, CheckCircle2, Ban, RotateCcw,
  User, MessageSquare, Clock, ChevronLeft, Trash2,
} from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

const TICKET_STATUS: Record<string, { label: string; cls: string }> = {
  open: { label: 'Open', cls: 'bg-amber-500/10 text-amber-300 border-amber-500/30' },
  pending: { label: 'Pending', cls: 'bg-sky-500/10 text-sky-300 border-sky-500/30' },
  resolved: { label: 'Resolved', cls: 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30' },
  closed: { label: 'Closed', cls: 'bg-zinc-500/10 text-zinc-500 border-zinc-500/30' },
};

const PRIORITY_CLS: Record<string, string> = {
  low: 'bg-zinc-900 text-zinc-400 border-zinc-700',
  normal: 'bg-sky-500/10 text-sky-300 border-sky-500/30',
  high: 'bg-amber-500/10 text-amber-300 border-amber-500/30',
  urgent: 'bg-red-500/10 text-red-300 border-red-500/30',
};

export function AdminSupport() {
  const [tickets, setTickets] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [status, setStatus] = useState('all');
  const [priority, setPriority] = useState('all');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [ticket, setTicket] = useState<any>(null);
  const [reply, setReply] = useState('');
  const [sending, setSending] = useState(false);
  const [ticketLoading, setTicketLoading] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const threadRef = useRef<HTMLDivElement | null>(null);

  const load = async (silent = false) => {
    if (!silent) setLoading(true);
    const r = await adminApi.supportTickets({ status, priority });
    if (r.success && r.data) setTickets(r.data);
    if (!silent) setLoading(false);
  };
  useEffect(() => { load(); setSelectedId(null); setTicket(null); }, [status, priority]);

  // Load full thread for the selected ticket; poll for new messages silently
  const loadThread = async (silent = false) => {
    if (!selectedId) return;
    if (!silent) setTicketLoading(true);
    const r = await adminApi.supportTicket(selectedId);
    if (r.success && r.data) setTicket(r.data);
    if (!silent) setTicketLoading(false);
  };
  useEffect(() => { loadThread(); }, [selectedId]);
  useEffect(() => {
    if (!selectedId) return;
    const t = setInterval(() => { loadThread(true); load(true); }, 4000);
    return () => clearInterval(t);
  }, [selectedId]);

  useEffect(() => {
    if (threadRef.current) threadRef.current.scrollTop = threadRef.current.scrollHeight;
  }, [ticket?.messages?.length, selectedId]);

  const send = async () => {
    if (!reply.trim() || !selectedId) return;
    setSending(true);
    const r = await adminApi.supportTicketAction(selectedId, 'reply', { body: reply.trim() });
    setSending(false);
    if (r.success) {
      setReply('');
      await loadThread(true);
      await load(true);
    } else {
      toast.error(`Failed to send: ${friendlyMessage(r)}`);
    }
  };

  const changeStatus = async (newStatus: string) => {
    if (!selectedId) return;
    const r = await adminApi.supportTicketAction(selectedId, 'status', { status: newStatus });
    if (r.success) {
      toast.success(`Ticket marked ${newStatus}`);
      await loadThread(true);
      await load(true);
    } else toast.error(`Failed: ${friendlyMessage(r)}`);
  };

  const changePriority = async (newPriority: string) => {
    if (!selectedId) return;
    const r = await adminApi.supportTicketAction(selectedId, 'priority', { priority: newPriority });
    if (r.success) { await loadThread(true); await load(true); }
    else toast.error(`Failed: ${friendlyMessage(r)}`);
  };

  const deleteTicket = async () => {
    if (!selectedId || deleting) return;
    setDeleting(true);
    const r = await adminApi.deleteSupportTicket(selectedId);
    setDeleting(false);
    if (r.success) {
      toast.success('Ticket deleted');
      setSelectedId(null);
      setTicket(null);
      await load(true);
    } else {
      toast.error(`Failed: ${friendlyMessage(r)}`);
    }
  };

  const lastMsg = ticket?.messages?.[ticket.messages.length - 1];
  const needsReply = ticket && lastMsg && !lastMsg.isStaff && ticket.status !== 'closed';

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2">
            Support Tickets <Badge variant="outline" className="bg-rose-500/10 text-rose-300 border-rose-500/30">Admin</Badge>
          </h2>
          <p className="text-xs text-zinc-500">View customer tickets and reply directly from the panel</p>
        </div>
        <div className="flex gap-2">
          <Select value={status} onValueChange={setStatus}>
            <SelectTrigger className="w-36 bg-zinc-950/50 border-zinc-800"><SelectValue /></SelectTrigger>
            <SelectContent className="bg-zinc-950 border-zinc-800">
              <SelectItem value="all">All statuses</SelectItem>
              <SelectItem value="open">Open</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="resolved">Resolved</SelectItem>
              <SelectItem value="closed">Closed</SelectItem>
            </SelectContent>
          </Select>
          <Select value={priority} onValueChange={setPriority}>
            <SelectTrigger className="w-36 bg-zinc-950/50 border-zinc-800"><SelectValue /></SelectTrigger>
            <SelectContent className="bg-zinc-950 border-zinc-800">
              <SelectItem value="all">All priorities</SelectItem>
              <SelectItem value="low">Low</SelectItem>
              <SelectItem value="normal">Normal</SelectItem>
              <SelectItem value="high">High</SelectItem>
              <SelectItem value="urgent">Urgent</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={() => load()} variant="outline" size="sm" className="border-zinc-800"><RefreshCw className="w-4 h-4" /></Button>
        </div>
      </div>

      <div className="grid lg:grid-cols-[380px_1fr] gap-4 items-start">
        {/* Ticket list */}
        <Card className="glass-panel p-0 overflow-hidden">
          <div className="px-4 py-3 border-b border-zinc-800 flex items-center justify-between">
            <p className="text-sm font-semibold flex items-center gap-2"><MessageSquare className="w-4 h-4 text-rose-400" /> Tickets</p>
            <span className="text-xs text-zinc-500">{tickets.length} total</span>
          </div>
          <div className="max-h-[70vh] overflow-y-auto divide-y divide-zinc-900">
            {loading ? (
              <div className="flex justify-center py-10"><Loader2 className="w-5 h-5 text-rose-400 animate-spin" /></div>
            ) : tickets.length === 0 ? (
              <div className="py-10 text-center">
                <LifeBuoy className="w-8 h-8 text-zinc-700 mx-auto mb-2" />
                <p className="text-sm text-zinc-500">No tickets found</p>
              </div>
            ) : tickets.map((t: any) => {
              const last = t.messages?.[0]; // latest message (desc order, take 1)
              const awaiting = last && !last.isStaff && t.status !== 'closed';
              return (
                <button
                  key={t.id}
                  onClick={() => setSelectedId(t.id)}
                  className={cn(
                    'w-full text-left px-4 py-3 transition-colors',
                    selectedId === t.id ? 'bg-rose-500/10' : 'hover:bg-zinc-900/60',
                  )}
                >
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <p className="text-sm font-medium truncate flex items-center gap-1.5">
                      {awaiting && <span className="w-1.5 h-1.5 rounded-full bg-rose-400 shrink-0" />}
                      {t.subject}
                    </p>
                    <span className={cn('px-1.5 py-0.5 text-[10px] uppercase border rounded shrink-0', PRIORITY_CLS[t.priority])}>
                      {t.priority}
                    </span>
                  </div>
                  <p className="text-xs text-zinc-500 truncate">{last?.body || 'No messages yet'}</p>
                  <div className="flex items-center gap-2 mt-1.5 text-[10px] text-zinc-600">
                    <span className="flex items-center gap-1"><User className="w-3 h-3" />{t.user?.name}</span>
                    <span className="flex items-center gap-1"><MessageSquare className="w-3 h-3" />{t._count?.messages || 0}</span>
                    <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{new Date(t.updatedAt).toLocaleString()}</span>
                  </div>
                  <div className="mt-1.5">
                    <span className={cn('px-1.5 py-0.5 text-[10px] uppercase border rounded', TICKET_STATUS[t.status]?.cls)}>
                      {TICKET_STATUS[t.status]?.label || t.status}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </Card>

        {/* Chat panel */}
        {selectedId && ticket ? (
          <Card className="glass-panel p-0 overflow-hidden flex flex-col" style={{ minHeight: '520px' }}>
            {/* Chat header */}
            <div className="px-4 py-3 border-b border-zinc-800 flex items-center justify-between gap-3 flex-wrap">
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <Button size="sm" variant="ghost" onClick={() => { setSelectedId(null); setTicket(null); }} className="lg:hidden h-7 px-2 text-zinc-400">
                    <ChevronLeft className="w-4 h-4" />
                  </Button>
                  <p className="text-sm font-semibold truncate">{ticket.subject}</p>
                  <span className={cn('px-1.5 py-0.5 text-[10px] uppercase border rounded', TICKET_STATUS[ticket.status]?.cls)}>
                    {TICKET_STATUS[ticket.status]?.label}
                  </span>
                  {needsReply && (
                    <Badge variant="outline" className="bg-rose-500/10 text-rose-300 border-rose-500/30 text-[10px] animate-pulse">
                      Awaiting reply
                    </Badge>
                  )}
                </div>
                <p className="text-xs text-zinc-500 mt-0.5">
                  {ticket.user?.name} · {ticket.user?.email} · {ticket.category}
                </p>
              </div>
              <div className="flex items-center gap-1.5">
                <Select value={ticket.priority} onValueChange={changePriority}>
                  <SelectTrigger className="h-8 w-28 bg-zinc-950/50 border-zinc-800 text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-zinc-950 border-zinc-800">
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="normal">Normal</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="urgent">Urgent</SelectItem>
                  </SelectContent>
                </Select>
                {ticket.status !== 'resolved' && (
                  <Button size="sm" variant="outline" onClick={() => changeStatus('resolved')}
                    className="h-8 border-emerald-700/50 text-emerald-300 hover:text-emerald-200 hover:bg-emerald-500/10">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Resolve
                  </Button>
                )}
                {ticket.status !== 'closed' ? (
                  <Button size="sm" variant="outline" onClick={() => changeStatus('closed')}
                    className="h-8 border-zinc-700 text-zinc-400 hover:text-zinc-200">
                    <Ban className="w-3.5 h-3.5" /> Close
                  </Button>
                ) : (
                  <Button size="sm" variant="outline" onClick={() => changeStatus('open')}
                    className="h-8 border-zinc-700 text-zinc-400 hover:text-zinc-200">
                    <RotateCcw className="w-3.5 h-3.5" /> Reopen
                  </Button>
                )}
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button size="sm" variant="outline" disabled={deleting}
                      className="h-8 border-red-800/60 text-red-300 hover:text-red-200 hover:bg-red-500/10 hover:border-red-700">
                      {deleting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />} Delete
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent className="bg-zinc-950 border-zinc-800">
                    <AlertDialogHeader>
                      <AlertDialogTitle>Delete this ticket?</AlertDialogTitle>
                      <AlertDialogDescription>
                        This permanently deletes “{ticket.subject}” and its entire message thread.
                        This action cannot be undone.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel className="border-zinc-800 bg-zinc-900 text-zinc-300 hover:bg-zinc-800 hover:text-zinc-100">Cancel</AlertDialogCancel>
                      <AlertDialogAction onClick={(e) => { e.preventDefault(); deleteTicket(); }}
                        className="bg-red-600 hover:bg-red-500 text-white border-none">
                        Delete Ticket
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            </div>

            {/* Messages */}
            <div ref={threadRef} className="flex-1 overflow-y-auto p-4 space-y-3 max-h-[46vh]">
              {ticketLoading ? (
                <div className="flex justify-center py-8"><Loader2 className="w-5 h-5 text-rose-400 animate-spin" /></div>
              ) : ticket.messages.length === 0 ? (
                <p className="text-sm text-zinc-500 text-center py-8">No messages in this ticket yet</p>
              ) : ticket.messages.map((m: any) => (
                <div key={m.id} className={cn('flex', m.isStaff ? 'justify-end' : 'justify-start')}>
                  <div className={cn(
                    'max-w-[80%] rounded-lg px-3 py-2 border',
                    m.isStaff
                      ? 'bg-rose-500/10 border-rose-500/30 rounded-br-none'
                      : 'bg-zinc-900/70 border-zinc-800 rounded-bl-none',
                  )}>
                    <div className="flex items-center gap-1.5 mb-1">
                      <span className={cn('text-[10px] font-semibold uppercase tracking-wider', m.isStaff ? 'text-rose-300' : 'text-zinc-400')}>
                        {m.isStaff ? `Support · ${m.user?.name || 'Staff'}` : m.user?.name || 'Customer'}
                      </span>
                      <span className="text-[10px] text-zinc-600">{new Date(m.createdAt).toLocaleString()}</span>
                    </div>
                    <p className="text-sm text-zinc-200 whitespace-pre-wrap break-words">{m.body}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Reply box */}
            <div className="border-t border-zinc-800 p-3">
              {ticket.status === 'closed' ? (
                <p className="text-xs text-zinc-500 text-center py-2">This ticket is closed. Reopen it to reply.</p>
              ) : (
                <div className="flex items-end gap-2">
                  <textarea
                    value={reply}
                    onChange={(e) => setReply(e.target.value)}
                    onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } }}
                    rows={2}
                    placeholder="Type your reply to the customer... (Enter to send, Shift+Enter for newline)"
                    className="flex-1 bg-zinc-950/50 border border-zinc-800 rounded-md px-3 py-2 text-sm text-zinc-100 placeholder:text-zinc-600 outline-none focus:border-rose-500/50 resize-none"
                  />
                  <Button onClick={send} disabled={sending || !reply.trim()} className="bg-rose-600 hover:bg-rose-500 text-white">
                    {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />} Send
                  </Button>
                </div>
              )}
            </div>
          </Card>
        ) : (
          <Card className="glass-panel p-12 text-center">
            <LifeBuoy className="w-12 h-12 text-zinc-700 mx-auto mb-3" />
            <p className="text-sm text-zinc-400 font-medium">Select a ticket to view the conversation</p>
            <p className="text-xs text-zinc-600 mt-1">
              Replies are delivered to the customer instantly — they get a notification and can answer right in their panel.
            </p>
          </Card>
        )}
      </div>
    </div>
  );
}
