'use client';

import { useEffect, useState } from 'react';
import { adminApi } from '@/lib/frontend/api';
import { Card } from '@/components/ui/card';
import { StatCard } from '@/components/shared/stat-card';
import { StatusBadge } from '@/components/shared/status-badge';
import {
  Server, HardDrive, Users, Activity, Cpu, MemoryStick, HardDrive as Disk,
  MapPin, AlertCircle, CheckCircle2, XCircle, Loader2, Zap, ShieldCheck,
} from 'lucide-react';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';

export function AdminDashboard() {
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState<any>(null);
  const [health, setHealth] = useState<any>(null);

  const load = async (silent = false) => {
    if (!silent) setLoading(true);
    const [s, h] = await Promise.all([adminApi.dashboardStats(), adminApi.systemHealth()]);
    if (s.success && s.data) setStats(s.data);
    if (h.success && h.data) setHealth(h.data);
    if (!silent) setLoading(false);
  };

  useEffect(() => { load(); const t = setInterval(() => load(true), 15000); return () => clearInterval(t); }, []);

  if (loading || !stats) {
    return <div className="flex items-center justify-center py-20"><Loader2 className="w-6 h-6 text-rose-400 animate-spin" /></div>;
  }

  const infra = stats.infrastructure;
  const vps = stats.vps;
  const users = stats.users;
  const deployments = stats.deployments;

  return (
    <div className="space-y-6">
      {/* Hero */}
      <Card className="glass-panel-red p-6 relative overflow-hidden anim-fade-up">
        <div className="absolute inset-0 bg-gradient-to-r from-rose-950/40 to-transparent pointer-events-none" />
        <div className="relative z-10">
          {/* Owner watermark — head area of the dashboard, above
              Infrastructure Overview, exactly as the owner requested. */}
          <div className="flex justify-center mb-4 animate-[wmGlow_3s_ease-in-out_infinite]">
            <p className="text-[11px] uppercase tracking-[0.35em] text-rose-400/90 font-semibold whitespace-nowrap drop-shadow-[0_0_10px_rgba(225,29,72,0.55)]">
              made by 『NØCTIS』
            </p>
          </div>
          <div className="flex items-center gap-2 mb-2">
            <Zap className="w-4 h-4 text-rose-400 anim-float" />
            <p className="text-xs uppercase tracking-wider text-rose-300/80">Infrastructure Overview</p>
          </div>
          <h2 className="text-2xl font-bold">System Status</h2>
          <p className="text-sm text-zinc-400 mt-1">
            {infra.onlineNodes} of {infra.totalNodes} nodes online · {vps.total} VPS managed · {users.total} users registered
          </p>
        </div>
      </Card>

      {/* Stat tiles */}
      <div>
        <h3 className="text-sm font-semibold uppercase tracking-wider text-zinc-500 mb-3">Infrastructure</h3>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 stagger">
          <StatCard label="Total Nodes" value={infra.totalNodes} icon={Server} tone="default" hint={`${infra.onlineNodes} online`} />
          <StatCard label="CPU Capacity" value={infra.cpuCapacity} icon={Cpu} tone="blue" hint={`${infra.usedCpu} vCPU in use`} />
          <StatCard label="RAM Capacity" value={`${(infra.ramCapacityMb / 1024).toFixed(0)}G`} icon={MemoryStick} tone="amber" hint={`${(infra.usedRamMb / 1024).toFixed(0)}G used`} />
          <StatCard label="Storage" value={`${(infra.storageCapacityGb / 1024).toFixed(1)}T`} icon={Disk} tone="emerald" hint={`${(infra.usedDiskGb / 1024).toFixed(1)}T used`} />
        </div>
      </div>

      <div>
        <h3 className="text-sm font-semibold uppercase tracking-wider text-zinc-500 mb-3">VPS</h3>
        <div className="grid grid-cols-2 lg:grid-cols-6 gap-4 stagger">
          <StatCard label="Total" value={vps.total} icon={HardDrive} tone="default" />
          <StatCard label="Running" value={vps.running} icon={CheckCircle2} tone="emerald" />
          <StatCard label="Stopped" value={vps.stopped} icon={XCircle} tone="amber" />
          <StatCard label="Suspended" value={vps.suspended} icon={AlertCircle} tone="red" />
          <StatCard label="Provisioning" value={vps.provisioning} icon={Loader2} tone="blue" />
          <StatCard label="Failed" value={vps.failed} icon={AlertCircle} tone="red" />
        </div>
      </div>

      <div>
        <h3 className="text-sm font-semibold uppercase tracking-wider text-zinc-500 mb-3">Users & Deployments</h3>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 stagger">
          <StatCard label="Total Users" value={users.total} icon={Users} tone="default" hint={`${users.verified} verified`} />
          <StatCard label="Suspended Users" value={users.suspended} icon={AlertCircle} tone="red" hint={`${users.unverified} unverified`} />
          <StatCard label="Active Deployments" value={deployments.active} icon={Activity} tone="amber" hint={`${deployments.queued} queued`} />
          <StatCard label="Completed Deployments" value={deployments.completed} icon={CheckCircle2} tone="emerald" hint={`${deployments.failed} failed`} />
        </div>
      </div>

      {/* System health */}
      <div>
        <h3 className="text-sm font-semibold uppercase tracking-wider text-zinc-500 mb-3">System Health</h3>
        <div className="grid lg:grid-cols-3 gap-4">
          {health && (
            <>
              <Card className="glass-panel p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Server className="w-4 h-4 text-zinc-500" />
                    <p className="text-sm">Database</p>
                  </div>
                  <StatusBadge status={health.db.status === 'OK' ? 'RUNNING' : 'ERROR'} size="sm" />
                </div>
              </Card>
              <Card className="glass-panel p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Zap className="w-4 h-4 text-zinc-500" />
                    <p className="text-sm">Realtime Service</p>
                  </div>
                  <StatusBadge status={health.realtime.status === 'OK' ? 'RUNNING' : 'OFFLINE'} size="sm" />
                </div>
              </Card>
              <Card className="glass-panel p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Activity className="w-4 h-4 text-zinc-500" />
                    <p className="text-sm">Queue</p>
                  </div>
                  <StatusBadge status={health.queue.status === 'OK' ? 'RUNNING' : 'ERROR'} size="sm" />
                </div>
              </Card>
            </>
          )}
        </div>
      </div>

      {/* Recent registrations */}
      <Card className="glass-panel p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold uppercase tracking-wider text-zinc-500">Recent Registrations</h3>
          <ShieldCheck className="w-4 h-4 text-zinc-500" />
        </div>
        <Table>
          <TableHeader>
            <TableRow className="border-zinc-800 hover:bg-transparent">
              <TableHead className="text-zinc-500">User</TableHead>
              <TableHead className="text-zinc-500">Email</TableHead>
              <TableHead className="text-zinc-500">Registered</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {users.recentRegistrations.length === 0 ? (
              <TableRow><TableCell colSpan={3} className="text-center text-zinc-500 py-8">No users</TableCell></TableRow>
            ) : users.recentRegistrations.map((u: any) => (
              <TableRow key={u.id} className="border-zinc-800">
                <TableCell className="font-medium">{u.name}</TableCell>
                <TableCell className="text-zinc-400">{u.email}</TableCell>
                <TableCell className="text-xs text-zinc-500">{new Date(u.createdAt).toLocaleString()}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}
