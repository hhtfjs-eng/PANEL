'use client';

import { useEffect, useState } from 'react';
import { useAppStore } from '@/lib/frontend/store';
import { adminApi, friendlyMessage } from '@/lib/frontend/api';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { StatusBadge } from '@/components/shared/status-badge';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from '@/components/ui/dialog';
import {
  HardDrive, Plus, Search, ChevronRight, Loader2, Cpu, MemoryStick, HardDrive as Disk,
  Network, MapPin, Globe, User, Server, MonitorSmartphone, Key, RefreshCw, Play,
  Square, RotateCw, AlertTriangle, Check, ArrowRight, Package, Timer, Infinity as InfinityIcon,
} from 'lucide-react';
import { toast } from 'sonner';

export function AdminVps() {
  const { setView } = useAppStore();
  const [loading, setLoading] = useState(true);
  const [vps, setVps] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('all');
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [createOpen, setCreateOpen] = useState(false);

  const load = async () => {
    setLoading(true);
    const r = await adminApi.vps({ search, status: status === 'all' ? '' : status, page, pageSize: 20 });
    if (r.success && r.data) {
      setVps(r.data as any[]);
      setTotal(r.pagination?.total || 0);
      setTotalPages(r.pagination?.totalPages || 1);
    }
    setLoading(false);
  };

  useEffect(() => { load(); }, [page, status]);
  useEffect(() => { const t = setTimeout(load, 350); return () => clearTimeout(t); }, [search]);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2">
            VPS Management
            <Badge variant="outline" className="bg-rose-500/10 text-rose-300 border-rose-500/30">Admin</Badge>
          </h2>
          <p className="text-xs text-zinc-500">Provisioning operations are admin/staff-only</p>
        </div>
        <Button onClick={() => setCreateOpen(true)} className="bg-rose-600 hover:bg-rose-500 text-white glow-red-sm">
          <Plus className="w-4 h-4" /> Create VPS
        </Button>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
          <Input value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            placeholder="Search VPS by name, hostname, IP..."
            className="pl-9 bg-zinc-950/50 border-zinc-800" />
        </div>
        <Select value={status} onValueChange={(v) => { setStatus(v); setPage(1); }}>
          <SelectTrigger className="w-40 bg-zinc-950/50 border-zinc-800">
            <SelectValue placeholder="All statuses" />
          </SelectTrigger>
          <SelectContent className="bg-zinc-950 border-zinc-800">
            <SelectItem value="all">All statuses</SelectItem>
            <SelectItem value="RUNNING">Running</SelectItem>
            <SelectItem value="STOPPED">Stopped</SelectItem>
            <SelectItem value="SUSPENDED">Suspended</SelectItem>
            <SelectItem value="PROVISIONING">Provisioning</SelectItem>
            <SelectItem value="QUEUED">Queued</SelectItem>
            <SelectItem value="ERROR">Error</SelectItem>
          </SelectContent>
        </Select>
        <Button onClick={load} variant="outline" size="sm" className="border-zinc-800">
          <RefreshCw className="w-4 h-4" />
        </Button>
      </div>

      <Card className="glass-panel overflow-hidden p-0">
        <Table>
          <TableHeader>
            <TableRow className="border-zinc-800 hover:bg-transparent">
              <TableHead className="text-zinc-500">VPS</TableHead>
              <TableHead className="text-zinc-500">Owner</TableHead>
              <TableHead className="text-zinc-500">Status</TableHead>
              <TableHead className="text-zinc-500 hidden md:table-cell">IP</TableHead>
              <TableHead className="text-zinc-500 hidden lg:table-cell">Resources</TableHead>
              <TableHead className="text-zinc-500 hidden lg:table-cell">Node</TableHead>
              <TableHead className="text-zinc-500 hidden xl:table-cell">Created</TableHead>
              <TableHead className="w-8"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow><TableCell colSpan={8} className="text-center py-12"><Loader2 className="w-5 h-5 animate-spin mx-auto text-zinc-500" /></TableCell></TableRow>
            ) : vps.length === 0 ? (
              <TableRow><TableCell colSpan={8} className="text-center py-12 text-zinc-500">No VPS found</TableCell></TableRow>
            ) : vps.map(v => (
              <TableRow key={v.id} onClick={() => setView('admin-vps-detail', { id: v.id })}
                className="cursor-pointer border-zinc-800 hover:bg-zinc-900/40">
                <TableCell>
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-md bg-rose-500/10 border border-rose-500/30 flex items-center justify-center shrink-0">
                      <HardDrive className="w-4 h-4 text-rose-400" />
                    </div>
                    <div>
                      <p className="font-medium">{v.name}</p>
                      <p className="text-xs text-zinc-500 font-mono">{v.hostname}</p>
                    </div>
                  </div>
                </TableCell>
                <TableCell className="text-xs">
                  <div>
                    <p className="text-zinc-200 truncate max-w-40">{v.owner?.name}</p>
                    <p className="text-zinc-500 truncate max-w-40">{v.owner?.email}</p>
                  </div>
                </TableCell>
                <TableCell><StatusBadge status={v.status} size="sm" /></TableCell>
                <TableCell className="hidden md:table-cell font-mono text-xs">{v.ipv4 || '—'}</TableCell>
                <TableCell className="hidden lg:table-cell text-xs text-zinc-400">
                  <div className="flex items-center gap-2">
                    <span className="flex items-center gap-1"><Cpu className="w-3 h-3" />{v.cpu}</span>
                    <span className="flex items-center gap-1"><MemoryStick className="w-3 h-3" />{(v.ramMb/1024).toFixed(0)}G</span>
                    <span className="flex items-center gap-1"><Disk className="w-3 h-3" />{v.diskGb}G</span>
                  </div>
                </TableCell>
                <TableCell className="hidden lg:table-cell text-xs text-zinc-400">
                  {v.node ? <span className="flex items-center gap-1"><MapPin className="w-3 h-3" />{v.node.name}</span> : '—'}
                </TableCell>
                <TableCell className="hidden xl:table-cell text-xs text-zinc-500">{new Date(v.createdAt).toLocaleDateString()}</TableCell>
                <TableCell><ChevronRight className="w-4 h-4 text-zinc-600" /></TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>

      <div className="flex items-center justify-between">
        <p className="text-xs text-zinc-500">{total} total · page {page} of {totalPages}</p>
        <div className="flex gap-1">
          <Button size="sm" variant="outline" disabled={page <= 1} onClick={() => setPage(p => p - 1)} className="border-zinc-800">Prev</Button>
          <Button size="sm" variant="outline" disabled={page >= totalPages} onClick={() => setPage(p => p + 1)} className="border-zinc-800">Next</Button>
        </div>
      </div>

      <CreateVpsWizard open={createOpen} onClose={() => setCreateOpen(false)} onCreated={(vpsId) => {
        setCreateOpen(false);
        setView('admin-deployments');
      }} />
    </div>
  );
}

// ============================================================
// CREATE VPS WIZARD (admin/staff only — enforced server-side)
// ============================================================
function CreateVpsWizard({ open, onClose, onCreated }: { open: boolean; onClose: () => void; onCreated: (vpsId: string) => void }) {
  const [step, setStep] = useState(1);
  const [users, setUsers] = useState<any[]>([]);
  const [nodes, setNodes] = useState<any[]>([]);
  const [plans, setPlans] = useState<any[]>([]);
  const [osList, setOsList] = useState<any[]>([]);
  const [ips, setIps] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [planOpen, setPlanOpen] = useState(false);
  const [savingPlan, setSavingPlan] = useState(false);
  const [planForm, setPlanForm] = useState<any>({ name: '', cpu: 2, ramGb: 4, diskGb: 80, bandwidthMbps: 2000, priceMonthly: 5 });
  const [form, setForm] = useState<any>({
    ownerId: '', name: '', hostname: '', description: '',
    planId: '', cpu: 2, ramMb: 4096, diskGb: 80, bandwidthMbps: 2000,
    nodeId: '', osId: '', ipv4: '', ipv6: '', gateway: '10.0.0.1',
    dnsPrimary: '1.1.1.1', dnsSecondary: '8.8.8.8', reverseDns: '',
    rootPassword: '', sshKeyFingerprint: '', autoStart: true, monitoringEnabled: true,
    autoSuspendDays: null as number | null, // null = Lifetime
  });

  useEffect(() => {
    if (!open) return;
    Promise.all([adminApi.users({ pageSize: 200 }), adminApi.nodes(), adminApi.plans(), adminApi.os(), adminApi.ips()])
      .then(([u, n, p, o, i]) => {
        if (u.success && u.data) setUsers(u.data);
        if (n.success && n.data) setNodes(n.data.filter((x: any) => x.enabled && !x.maintenanceMode && x.health === 'ONLINE'));
        if (p.success && p.data) setPlans(p.data);
        if (o.success && o.data) setOsList(o.data);
        if (i.success && i.data) setIps(i.data.ips.filter((x: any) => x.state === 'AVAILABLE'));
      });
  }, [open]);

  const set = (k: string, v: any) => setForm((prev: any) => ({ ...prev, [k]: v }));

  // Owner selection — auto-fill the hostname from the owner's name (spaces
  // removed) so the SSH login reads root@ownername. If the admin already
  // typed a hostname manually, don't clobber it.
  const selectOwner = (ownerId: string) => {
    const owner = users.find((u: any) => u.id === ownerId);
    setForm((prev: any) => {
      const autoHostname = (owner?.name || '').trim().replace(/\s+/g, '');
      const hostname = (!prev.hostname || prev.hostname === prev.autoHostname) && autoHostname
        ? autoHostname
        : prev.hostname;
      return { ...prev, ownerId, hostname, autoHostname };
    });
  };

  const applyPlan = (planId: string) => {
    const plan = plans.find(p => p.id === planId);
    if (plan) {
      setForm((prev: any) => ({
        ...prev, planId, cpu: plan.cpu, ramMb: plan.ramMb,
        diskGb: plan.diskGb, bandwidthMbps: plan.bandwidthMbps,
      }));
    }
  };

  // Create a new predefined plan from within the wizard and apply it immediately
  const createAndUsePlan = async () => {
    if (!planForm.name?.trim()) { toast.error('Plan name is required'); return; }
    setSavingPlan(true);
    const payload = {
      name: planForm.name.trim(),
      cpu: planForm.cpu,
      ramMb: Math.round(planForm.ramGb * 1024),
      diskGb: planForm.diskGb,
      bandwidthMbps: planForm.bandwidthMbps,
      priceMonthly: planForm.priceMonthly,
      setupFee: 0, region: 'global', ipv4Included: true, ipv6Included: true, enabled: true,
    };
    const r = await adminApi.createPlan(payload);
    setSavingPlan(false);
    if (r.success && r.data?.id) {
      const newPlan = { id: r.data.id, ...payload };
      setPlans(prev => [newPlan, ...prev]);
      // Apply directly (setPlans is async, so applyPlan's lookup would miss the new plan)
      setForm((prev: any) => ({
        ...prev, planId: newPlan.id, cpu: newPlan.cpu, ramMb: newPlan.ramMb,
        diskGb: newPlan.diskGb, bandwidthMbps: newPlan.bandwidthMbps,
      }));
      toast.success(`Plan "${newPlan.name}" created and applied`);
      setPlanOpen(false);
      setPlanForm({ name: '', cpu: 2, ramGb: 4, diskGb: 80, bandwidthMbps: 2000, priceMonthly: 5 });
    } else {
      toast.error(`Failed to create plan: ${friendlyMessage(r)}`);
    }
  };

  const submit = async () => {
    setLoading(true); setError(null);
    const idem = crypto.randomUUID();
    // Build the payload, coercing empty-string optionals to undefined so the
    // backend gets clean values (the backend also does this defensively, but
    // sending clean data helps proxies and any future validation layers).
    const payload: any = {
      ...form,
      planId: form.planId || undefined,
      description: form.description || undefined,
      ipv4: form.ipv4 || undefined,
      ipv6: form.ipv6 || undefined,
      gateway: form.gateway || undefined,
      dnsPrimary: form.dnsPrimary || undefined,
      dnsSecondary: form.dnsSecondary || undefined,
      reverseDns: form.reverseDns || undefined,
      rootPassword: form.rootPassword || undefined,
      sshKeyFingerprint: form.sshKeyFingerprint || undefined,
      autoSuspendDays: form.autoSuspendDays,
      idempotencyKey: idem,
    };
    const r = await adminApi.createVps(payload);
    setLoading(false);
    if (r.success && r.data?.vpsId) {
      toast.success('VPS creation queued — deployment job started');
      onCreated(r.data.vpsId);
    } else {
      setError(friendlyMessage(r));
    }
  };

  const steps = [
    { num: 1, label: 'Customer' },
    { num: 2, label: 'Info' },
    { num: 3, label: 'Resources' },
    { num: 4, label: 'Node' },
    { num: 5, label: 'OS' },
    { num: 6, label: 'Network' },
    { num: 7, label: 'Review' },
  ];

  const canNext = () => {
    switch (step) {
      case 1: return !!form.ownerId;
      case 2: return !!form.name && !!form.hostname;
      case 3: return form.cpu > 0 && form.ramMb >= 512 && form.diskGb >= 10;
      case 4: return !!form.nodeId;
      case 5: return !!form.osId;
      default: return true;
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-3xl bg-zinc-950 border-zinc-800 max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <HardDrive className="w-5 h-5 text-rose-400" /> Create VPS — Admin Provisioning
          </DialogTitle>
          <DialogDescription>This action is restricted to admin/staff roles. Backend enforces RBAC.</DialogDescription>
        </DialogHeader>

        {/* Stepper */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-zinc-900">
          {steps.map((s, i) => (
            <div key={s.num} className="flex items-center gap-2">
              <div className={`flex items-center gap-2 px-2 py-1 rounded-md text-xs ${step === s.num ? 'bg-rose-500/15 text-rose-300 border border-rose-500/30' : step > s.num ? 'text-emerald-400' : 'text-zinc-500'}`}>
                <div className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${step === s.num ? 'bg-rose-500 text-white' : step > s.num ? 'bg-emerald-500/20 border border-emerald-500/40' : 'bg-zinc-900 border border-zinc-700'}`}>
                  {step > s.num ? <Check className="w-3 h-3" /> : s.num}
                </div>
                <span className="hidden sm:inline">{s.label}</span>
              </div>
              {i < steps.length - 1 && <ArrowRight className="w-3 h-3 text-zinc-700" />}
            </div>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto py-4">
          {error && (
            <div className="mb-3 p-3 rounded-md bg-red-500/10 border border-red-500/20 text-xs text-red-300 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4" /> {error}
            </div>
          )}

          {/* Step 1 — Customer */}
          {step === 1 && (
            <div className="space-y-4">
              <div>
                <Label className="flex items-center gap-1.5 mb-2"><User className="w-3 h-3" /> Select Customer (Owner)</Label>
                <Input
                  placeholder="Search by name, email, username..."
                  className="bg-zinc-950/50 border-zinc-800 mb-3"
                  onChange={(e) => adminApi.users({ search: e.target.value, pageSize: 50 }).then(r => r.success && setUsers(r.data))}
                />
              </div>
              <div className="space-y-1 max-h-80 overflow-y-auto">
                {users.length === 0 ? (
                  <p className="text-sm text-zinc-500 py-4 text-center">No users found</p>
                ) : users.map((u: any) => (
                  <button key={u.id} onClick={() => selectOwner(u.id)}
                    className={`w-full flex items-center gap-3 p-3 rounded-md border text-left ${form.ownerId === u.id ? 'bg-rose-500/10 border-rose-500/40' : 'bg-zinc-900/40 border-zinc-800 hover:border-zinc-700'}`}>
                    <div className="w-8 h-8 rounded-full bg-zinc-800 border border-zinc-700 flex items-center justify-center text-xs uppercase">
                      {u.name?.charAt(0) || '?'}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium">{u.name} <span className="text-zinc-500 font-normal">· @{u.username}</span></p>
                      <p className="text-xs text-zinc-500">{u.email}</p>
                    </div>
                    {u.role !== 'USER' && <Badge variant="outline" className="bg-amber-500/10 text-amber-300 border-amber-500/30 text-[10px]">{u.role}</Badge>}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Step 2 — Info */}
          {step === 2 && (
            <div className="space-y-4">
              <div className="space-y-1.5">
                <Label>VPS Name</Label>
                <Input value={form.name} onChange={(e) => set('name', e.target.value)}
                  placeholder="Production Web Server" className="bg-zinc-950/50 border-zinc-800" />
              </div>
              <div className="space-y-1.5">
                <Label>Hostname</Label>
                <Input value={form.hostname} onChange={(e) => set('hostname', e.target.value.trim())}
                  placeholder="auto-filled from owner name" className="bg-zinc-950/50 border-zinc-800 font-mono text-sm" />
                <p className="text-[11px] text-zinc-500">Auto-filled from the owner's name (no spaces) so the SSH login reads root@hostname. You can override it.</p>
              </div>
              <div className="space-y-1.5">
                <Label>Description (optional)</Label>
                <Textarea value={form.description} onChange={(e) => set('description', e.target.value)}
                  rows={2} className="bg-zinc-950/50 border-zinc-800" />
              </div>
            </div>
          )}

          {/* Step 3 — Resources */}
          {step === 3 && (
            <div className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <Label>Use Predefined Plan</Label>
                  <Button size="sm" variant="outline" onClick={() => setPlanOpen(true)}
                    className="h-7 border-rose-500/30 text-rose-300 hover:text-rose-200 hover:bg-rose-500/10">
                    <Plus className="w-3.5 h-3.5" /> Add New Plan
                  </Button>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <button onClick={() => set('planId', '')} className={`p-3 rounded-md border text-left ${!form.planId ? 'bg-rose-500/10 border-rose-500/40' : 'bg-zinc-900/40 border-zinc-800'}`}>
                    <p className="text-sm font-medium">Custom</p>
                    <p className="text-xs text-zinc-500">Manually specify resources</p>
                  </button>
                  {plans.map((p: any) => (
                    <button key={p.id} onClick={() => applyPlan(p.id)} className={`p-3 rounded-md border text-left ${form.planId === p.id ? 'bg-rose-500/10 border-rose-500/40' : 'bg-zinc-900/40 border-zinc-800 hover:border-zinc-700'}`}>
                      <p className="text-sm font-medium">{p.name}</p>
                      <p className="text-xs text-zinc-500">{p.cpu} CPU / {(p.ramMb/1024).toFixed(0)}G / {p.diskGb}G</p>
                    </button>
                  ))}
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-1.5">
                  <Label>CPU (cores)</Label>
                  <Input type="number" min={1} max={64} value={form.cpu} onChange={(e) => set('cpu', +e.target.value)} className="bg-zinc-950/50 border-zinc-800" />
                </div>
                <div className="space-y-1.5">
                  <Label>RAM (GB)</Label>
                  <Input type="number" min={0.5} step={0.5} value={form.ramMb / 1024} onChange={(e) => set('ramMb', Math.round(+e.target.value * 1024))} className="bg-zinc-950/50 border-zinc-800" />
                </div>
                <div className="space-y-1.5">
                  <Label>Disk (GB)</Label>
                  <Input type="number" min={10} value={form.diskGb} onChange={(e) => set('diskGb', +e.target.value)} className="bg-zinc-950/50 border-zinc-800" />
                </div>
              </div>

              {/* Auto-suspend policy — dropdown of periods + Lifetime button */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <Label className="flex items-center gap-1.5"><Timer className="w-3 h-3" /> Auto-Suspend</Label>
                  <span className="text-[11px] text-zinc-500">
                    {form.autoSuspendDays === null
                      ? 'Lifetime — never auto-suspend'
                      : `Suspends ${new Date(Date.now() + form.autoSuspendDays * 86400 * 1000).toLocaleDateString()}`}
                  </span>
                </div>
                <div className="flex gap-2">
                  <Select
                    value={form.autoSuspendDays === null ? '' : String(form.autoSuspendDays)}
                    onValueChange={(v) => set('autoSuspendDays', v === '' ? null : +v)}
                  >
                    <SelectTrigger className="bg-zinc-950/50 border-zinc-800 flex-1">
                      <SelectValue placeholder="Choose a period…" />
                    </SelectTrigger>
                    <SelectContent className="bg-zinc-950 border-zinc-800">
                      <SelectItem value="30">30 days</SelectItem>
                      <SelectItem value="60">60 days</SelectItem>
                      <SelectItem value="90">90 days</SelectItem>
                      <SelectItem value="180">180 days</SelectItem>
                      <SelectItem value="365">1 year</SelectItem>
                      <SelectItem value="730">2 years</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button
                    type="button"
                    variant={form.autoSuspendDays === null ? 'default' : 'outline'}
                    onClick={() => set('autoSuspendDays', null)}
                    className={form.autoSuspendDays === null
                      ? 'bg-rose-600 hover:bg-rose-500 text-white'
                      : 'border-zinc-800 text-zinc-400'}
                  >
                    <InfinityIcon className="w-4 h-4" /> Lifetime
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* Step 4 — Node */}
          {step === 4 && (
            <div className="space-y-2">
              {nodes.length === 0 ? (
                <p className="text-sm text-zinc-500 py-8 text-center">No nodes available for deployment</p>
              ) : nodes.map((n: any) => {
                const cpuUsed = ((n.usedCpu / n.cpuCapacity) * 100).toFixed(0);
                const ramUsed = ((n.usedRamMb / n.ramCapacityMb) * 100).toFixed(0);
                return (
                  <button key={n.id} onClick={() => set('nodeId', n.id)}
                    className={`w-full p-3 rounded-md border text-left ${form.nodeId === n.id ? 'bg-rose-500/10 border-rose-500/40' : 'bg-zinc-900/40 border-zinc-800 hover:border-zinc-700'}`}>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium flex items-center gap-2">
                          <MapPin className="w-3 h-3 text-rose-400" />{n.name}
                        </p>
                        <p className="text-xs text-zinc-500">{n.region} · {n.datacenter}</p>
                      </div>
                      <StatusBadge status={n.health} size="sm" />
                    </div>
                    <div className="grid grid-cols-3 gap-2 mt-2 text-[10px] text-zinc-500">
                      <span>CPU: {cpuUsed}%</span>
                      <span>RAM: {ramUsed}%</span>
                      <span>VPS: {n.vpsCount}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          )}

          {/* Step 5 — OS */}
          {step === 5 && (
            <div className="space-y-2">
              {osList.filter((o: any) => o.available).map((o: any) => (
                <button key={o.id} onClick={() => set('osId', o.id)}
                  className={`w-full p-3 rounded-md border text-left flex items-center gap-3 ${form.osId === o.id ? 'bg-rose-500/10 border-rose-500/40' : 'bg-zinc-900/40 border-zinc-800 hover:border-zinc-700'}`}>
                  <MonitorSmartphone className="w-4 h-4 text-rose-400" />
                  <div>
                    <p className="text-sm font-medium">{o.name}</p>
                    <p className="text-xs text-zinc-500">{o.distribution} · {o.version} · {o.architecture}</p>
                  </div>
                </button>
              ))}
            </div>
          )}

          {/* Step 6 — Network */}
          {step === 6 && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label>IPv4</Label>
                  <Select value={form.ipv4 || '__auto__'} onValueChange={(v) => set('ipv4', v === '__auto__' ? '' : v)}>
                    <SelectTrigger className="bg-zinc-950/50 border-zinc-800"><SelectValue placeholder="Auto-assign" /></SelectTrigger>
                    <SelectContent className="bg-zinc-950 border-zinc-800">
                      <SelectItem value="__auto__">Auto-assign</SelectItem>
                      {ips.filter((i: any) => i.family === 4).map((i: any) => (
                        <SelectItem key={i.id} value={i.address}>{i.address}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label>IPv6 (optional)</Label>
                  <Select value={form.ipv6 || '__auto__'} onValueChange={(v) => set('ipv6', v === '__auto__' ? '' : v)}>
                    <SelectTrigger className="bg-zinc-950/50 border-zinc-800"><SelectValue placeholder="Auto-assign" /></SelectTrigger>
                    <SelectContent className="bg-zinc-950 border-zinc-800">
                      <SelectItem value="__auto__">Auto-assign</SelectItem>
                      {ips.filter((i: any) => i.family === 6).map((i: any) => (
                        <SelectItem key={i.id} value={i.address}>{i.address}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label>Gateway</Label>
                  <Input value={form.gateway} onChange={(e) => set('gateway', e.target.value)} className="bg-zinc-950/50 border-zinc-800 font-mono text-sm" />
                </div>
                <div className="space-y-1.5">
                  <Label>Reverse DNS</Label>
                  <Input value={form.reverseDns} onChange={(e) => set('reverseDns', e.target.value)} placeholder="vps.example.com" className="bg-zinc-950/50 border-zinc-800 font-mono text-sm" />
                </div>
                <div className="space-y-1.5">
                  <Label>DNS Primary</Label>
                  <Input value={form.dnsPrimary} onChange={(e) => set('dnsPrimary', e.target.value)} className="bg-zinc-950/50 border-zinc-800 font-mono text-sm" />
                </div>
                <div className="space-y-1.5">
                  <Label>DNS Secondary</Label>
                  <Input value={form.dnsSecondary} onChange={(e) => set('dnsSecondary', e.target.value)} className="bg-zinc-950/50 border-zinc-800 font-mono text-sm" />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label className="flex items-center gap-1.5"><Key className="w-3 h-3" /> SSH Key Fingerprint (optional)</Label>
                <Input value={form.sshKeyFingerprint} onChange={(e) => set('sshKeyFingerprint', e.target.value)} placeholder="SHA256:..." className="bg-zinc-950/50 border-zinc-800 font-mono text-xs" />
              </div>
              <div className="flex items-center gap-3 text-sm">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" checked={form.autoStart} onChange={(e) => set('autoStart', e.target.checked)} className="rounded" />
                  Auto-start after deployment
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" checked={form.monitoringEnabled} onChange={(e) => set('monitoringEnabled', e.target.checked)} className="rounded" />
                  Enable monitoring
                </label>
              </div>
            </div>
          )}

          {/* Step 7 — Review */}
          {step === 7 && (
            <div className="space-y-3">
              <Card className="glass-panel-red p-3 border-amber-500/20 bg-amber-950/10">
                <div className="flex items-start gap-2 text-xs">
                  <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <p className="text-zinc-300">SSH credentials are generated automatically: an ED25519 keypair plus an initial root password. The owner can view them in the VPS detail SSH Access card (login reads root@{form.hostname || 'hostname'}).</p>
                </div>
              </Card>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <ReviewRow label="Owner" value={users.find(u => u.id === form.ownerId)?.email} />
                <ReviewRow label="VPS Name" value={form.name} />
                <ReviewRow label="Hostname" value={form.hostname} />
                <ReviewRow label="Plan" value={plans.find(p => p.id === form.planId)?.name || 'Custom'} />
                <ReviewRow label="CPU" value={`${form.cpu} vCPU`} />
                <ReviewRow label="RAM" value={`${(form.ramMb / 1024).toFixed(0)} GB`} />
                <ReviewRow label="Disk" value={`${form.diskGb} GB`} />
                <ReviewRow label="Auto-Suspend" value={
                  form.autoSuspendDays === null
                    ? 'Lifetime'
                    : `${form.autoSuspendDays} days (${new Date(Date.now() + form.autoSuspendDays * 86400 * 1000).toLocaleDateString()})`
                } />
                <ReviewRow label="Node" value={nodes.find(n => n.id === form.nodeId)?.name} />
                <ReviewRow label="OS" value={osList.find(o => o.id === form.osId)?.name} />
                <ReviewRow label="IPv4" value={form.ipv4 || 'Auto-assign'} />
                <ReviewRow label="Auto-start" value={form.autoStart ? 'Yes' : 'No'} />
              </div>
            </div>
          )}
        </div>

        <DialogFooter className="border-t border-zinc-900 pt-4">
          <Button variant="outline" onClick={onClose} disabled={loading} className="border-zinc-800">Cancel</Button>
          {step > 1 && <Button variant="outline" onClick={() => setStep(s => s - 1)} disabled={loading} className="border-zinc-800">Back</Button>}
          {step < 7 ? (
            <Button onClick={() => setStep(s => s + 1)} disabled={!canNext()} className="bg-rose-600 hover:bg-rose-500 text-white">
              Next <ArrowRight className="w-4 h-4" />
            </Button>
          ) : (
            <Button onClick={submit} disabled={loading} className="bg-rose-600 hover:bg-rose-500 text-white glow-red-sm">
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />} Create & Deploy
            </Button>
          )}
        </DialogFooter>

        {/* Nested dialog — create a new predefined plan without leaving the wizard */}
        <Dialog open={planOpen} onOpenChange={setPlanOpen}>
          <DialogContent className="bg-zinc-950 border-zinc-800 max-w-lg">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Package className="w-4 h-4 text-rose-400" /> Add New Predefined Plan
              </DialogTitle>
              <DialogDescription>
                The plan is saved to the catalog and applied to this deployment immediately.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-3 py-4 grid grid-cols-2 gap-3">
              <div className="col-span-2">
                <Label>Plan Name</Label>
                <Input value={planForm.name} onChange={(e) => setPlanForm({ ...planForm, name: e.target.value })}
                  placeholder="e.g. GPU Optimized VPS" className="bg-zinc-950/50 border-zinc-800" />
              </div>
              <div><Label>CPU (cores)</Label><Input type="number" min={1} max={64} value={planForm.cpu} onChange={(e) => setPlanForm({ ...planForm, cpu: +e.target.value })} className="bg-zinc-950/50 border-zinc-800" /></div>
              <div><Label>RAM (GB)</Label><Input type="number" min={0.5} max={256} step={0.5} value={planForm.ramGb} onChange={(e) => setPlanForm({ ...planForm, ramGb: +e.target.value })} className="bg-zinc-950/50 border-zinc-800" /></div>
              <div><Label>Disk (GB)</Label><Input type="number" min={10} max={2048} value={planForm.diskGb} onChange={(e) => setPlanForm({ ...planForm, diskGb: +e.target.value })} className="bg-zinc-950/50 border-zinc-800" /></div>
              <div className="col-span-2"><Label>Monthly Price ($)</Label><Input type="number" min={0} step="0.01" value={planForm.priceMonthly} onChange={(e) => setPlanForm({ ...planForm, priceMonthly: +e.target.value })} className="bg-zinc-950/50 border-zinc-800" /></div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setPlanOpen(false)} disabled={savingPlan} className="border-zinc-800">Cancel</Button>
              <Button onClick={createAndUsePlan} disabled={savingPlan || !planForm.name?.trim()} className="bg-rose-600 hover:bg-rose-500 text-white">
                {savingPlan ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />} Create & Use Plan
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </DialogContent>
    </Dialog>
  );
}

function ReviewRow({ label, value }: { label: string; value?: string }) {
  return (
    <div className="flex items-center justify-between gap-2 py-1 border-b border-zinc-900">
      <span className="text-zinc-500">{label}</span>
      <span className="text-zinc-200 font-mono text-xs truncate max-w-48">{value || '—'}</span>
    </div>
  );
}
