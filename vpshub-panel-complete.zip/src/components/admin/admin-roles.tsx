'use client';

// Role Editor — list all roles (5 built-ins read-only + custom roles) and
// create/edit/delete custom roles with a full permission matrix.

import { useEffect, useState } from 'react';
import { adminApi, friendlyMessage } from '@/lib/frontend/api';
import { PERMISSION_GROUPS } from '@/lib/permissions';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import { toast } from 'sonner';
import {
  Loader2, ShieldCheck, Plus, Pencil, Trash2, Lock, Users,
} from 'lucide-react';

interface RoleRow {
  key: string; name: string; description?: string | null;
  permissions: string[]; isSystem: boolean; memberCount?: number;
}

const emptyForm = { name: '', description: '', permissions: [] as string[] };

export function AdminRoles() {
  const [roles, setRoles] = useState<RoleRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null); // null = create
  const [form, setForm] = useState(emptyForm);
  const [deleteTarget, setDeleteTarget] = useState<RoleRow | null>(null);
  const [deleting, setDeleting] = useState(false);

  const load = async () => {
    setLoading(true);
    const r = await adminApi.roles();
    if (r.success && r.data) setRoles(r.data);
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const openCreate = () => {
    setEditingId(null);
    setForm(emptyForm);
    setOpen(true);
  };

  const openEdit = (role: RoleRow) => {
    // Custom roles only — built-ins have a fixed permission set
    if (!(role as any).id) { toast.error('Built-in roles cannot be edited'); return; }
    setEditingId((role as any).id);
    setForm({ name: role.name, description: role.description || '', permissions: [...role.permissions] });
    setOpen(true);
  };

  const togglePermission = (key: string) => {
    setForm(f => ({
      ...f,
      permissions: f.permissions.includes(key)
        ? f.permissions.filter(p => p !== key)
        : [...f.permissions, key],
    }));
  };

  const submit = async () => {
    if (!form.name.trim()) { toast.error('Role name is required'); return; }
    if (form.permissions.length === 0) { toast.error('Select at least one permission'); return; }
    setSaving(true);
    const payload = {
      name: form.name.trim(),
      description: form.description.trim() || undefined,
      permissions: form.permissions,
    };
    const r = editingId
      ? await adminApi.updateRole(editingId, payload)
      : await adminApi.createRole(payload);
    setSaving(false);
    if (r.success) {
      toast.success(editingId ? 'Role updated' : `Role "${payload.name}" created`);
      setOpen(false);
      load();
    } else {
      toast.error(friendlyMessage(r));
    }
  };

  const doDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    const r = await adminApi.deleteRole((deleteTarget as any).id);
    setDeleting(false);
    if (r.success) {
      toast.success(`Role "${deleteTarget.name}" deleted — members moved to USER`);
      setDeleteTarget(null);
      load();
    } else {
      toast.error(friendlyMessage(r));
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-rose-400" /> Role Editor
          </h2>
          <p className="text-xs text-zinc-500">Create custom roles with granular permissions</p>
        </div>
        <Button onClick={openCreate} size="sm" className="bg-rose-600 hover:bg-rose-500 text-white">
          <Plus className="w-4 h-4" /> Create Role
        </Button>
      </div>

      {loading ? (
        <div className="flex justify-center py-12"><Loader2 className="w-6 h-6 text-rose-400 animate-spin" /></div>
      ) : (
        <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">
          {roles.map(role => {
            const members = role.memberCount ?? 0;
            return (
              <Card key={role.key} className={`glass-panel p-4 flex flex-col ${role.isSystem ? 'opacity-90' : ''}`}>
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="font-semibold truncate">{role.name}</p>
                      {role.isSystem
                        ? <Badge variant="outline" className="bg-zinc-800/60 text-zinc-400 border-zinc-700 shrink-0"><Lock className="w-3 h-3 mr-1" />Built-in</Badge>
                        : <Badge variant="outline" className="bg-rose-500/10 text-rose-300 border-rose-500/30 shrink-0">Custom</Badge>}
                    </div>
                    <p className="text-[11px] text-zinc-600 font-mono mt-0.5 truncate">{role.key}</p>
                  </div>
                </div>
                {role.description && <p className="text-xs text-zinc-500 mt-1">{role.description}</p>}
                <div className="flex items-center gap-1.5 mt-2 text-xs text-zinc-500">
                  <Users className="w-3.5 h-3.5" /> {members} member{members === 1 ? '' : 's'}
                  <span className="text-zinc-700">·</span> {role.permissions.length} permissions
                </div>

                {/* Permission chips (collapsed preview) */}
                <div className="flex flex-wrap gap-1 mt-3">
                  {role.permissions.slice(0, 6).map(p => (
                    <span key={p} className="px-1.5 py-0.5 text-[10px] rounded bg-zinc-900/80 border border-zinc-800 text-zinc-400 font-mono">{p}</span>
                  ))}
                  {role.permissions.length > 6 && (
                    <span className="px-1.5 py-0.5 text-[10px] rounded bg-zinc-900/80 border border-zinc-800 text-zinc-500">+{role.permissions.length - 6} more</span>
                  )}
                </div>

                <div className="mt-auto pt-3 flex gap-2">
                  {role.isSystem ? (
                    <span className="text-[11px] text-zinc-600 flex items-center gap-1">
                      <Lock className="w-3 h-3" /> Fixed permission set
                    </span>
                  ) : (
                    <>
                      <Button size="sm" variant="outline" onClick={() => openEdit(role)} className="border-zinc-800 hover:bg-zinc-900">
                        <Pencil className="w-3.5 h-3.5" /> Edit
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => setDeleteTarget(role)} className="border-red-900/60 text-red-300 hover:bg-red-500/10">
                        <Trash2 className="w-3.5 h-3.5" /> Delete
                      </Button>
                    </>
                  )}
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {/* Create / edit dialog with permission matrix */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-3xl bg-zinc-950 border-zinc-800 max-h-[90vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-rose-400" />
              {editingId ? 'Edit Custom Role' : 'Create Custom Role'}
            </DialogTitle>
            <DialogDescription>
              Pick exactly what this role can do — every API call checks these permissions server-side.
            </DialogDescription>
          </DialogHeader>

          <div className="flex-1 overflow-y-auto space-y-4 py-2">
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Role Name</Label>
                <Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })}
                  placeholder="e.g. Support Manager" className="bg-zinc-950/50 border-zinc-800" /></div>
              <div><Label>Description (optional)</Label>
                <Input value={form.description} onChange={e => setForm({ ...form, description: e.target.value })}
                  placeholder="What is this role for?" className="bg-zinc-950/50 border-zinc-800" /></div>
            </div>

            <div className="flex items-center justify-between">
              <p className="text-xs text-zinc-500">
                <span className="text-rose-300 font-medium">{form.permissions.length}</span> permission{form.permissions.length === 1 ? '' : 's'} selected
              </p>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" className="border-zinc-800 text-xs h-7"
                  onClick={() => setForm(f => ({ ...f, permissions: PERMISSION_GROUPS.flatMap(g => g.permissions.map(p => p.key)) }))}>
                  Select all
                </Button>
                <Button size="sm" variant="outline" className="border-zinc-800 text-xs h-7"
                  onClick={() => setForm(f => ({ ...f, permissions: [] }))}>
                  Clear
                </Button>
              </div>
            </div>

            {PERMISSION_GROUPS.map(group => (
              <Card key={group.group} className="bg-zinc-900/30 border-zinc-800/60 p-3">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-xs font-semibold uppercase tracking-wider text-zinc-400">{group.group}</p>
                  <button className="text-[11px] text-rose-400 hover:text-rose-300"
                    onClick={() => {
                      const keys: string[] = group.permissions.map(p => p.key);
                      const allOn = keys.every(k => form.permissions.includes(k));
                      setForm(f => ({
                        ...f,
                        permissions: allOn
                          ? f.permissions.filter(p => !keys.includes(p))
                          : [...new Set([...f.permissions, ...keys])],
                      }));
                    }}>
                    toggle all
                  </button>
                </div>
                <div className="grid sm:grid-cols-2 gap-1.5">
                  {group.permissions.map(p => {
                    const on = form.permissions.includes(p.key);
                    return (
                      <button key={p.key} onClick={() => togglePermission(p.key)}
                        className={`flex items-center gap-2 px-2.5 py-1.5 rounded-md border text-left text-xs transition-colors ${on ? 'bg-rose-500/10 border-rose-500/40 text-rose-200' : 'bg-zinc-950/40 border-zinc-800 text-zinc-400 hover:border-zinc-700'}`}>
                        <span className={`w-3.5 h-3.5 rounded border flex items-center justify-center shrink-0 ${on ? 'bg-rose-500 border-rose-500' : 'border-zinc-700'}`}>
                          {on && <svg viewBox="0 0 12 12" className="w-2.5 h-2.5 text-white"><path d="M2 6l3 3 5-6" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>}
                        </span>
                        <span className="truncate">{p.label}</span>
                      </button>
                    );
                  })}
                </div>
              </Card>
            ))}
          </div>

          <DialogFooter className="border-t border-zinc-900 pt-4">
            <Button variant="outline" onClick={() => setOpen(false)} disabled={saving} className="border-zinc-800">Cancel</Button>
            <Button onClick={submit} disabled={saving} className="bg-rose-600 hover:bg-rose-500 text-white">
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
              {editingId ? 'Save Role' : 'Create Role'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete confirmation */}
      <Dialog open={!!deleteTarget} onOpenChange={o => !o && setDeleteTarget(null)}>
        <DialogContent className="max-w-md bg-zinc-950 border-zinc-800">
          <DialogHeader>
            <DialogTitle>Delete role "{deleteTarget?.name}"?</DialogTitle>
            <DialogDescription>
              {deleteTarget?.memberCount
                ? `${deleteTarget.memberCount} member${deleteTarget.memberCount === 1 ? '' : 's'} will be moved back to the USER role.`
                : 'This role has no members.'}
              This cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteTarget(null)} disabled={deleting} className="border-zinc-800">Cancel</Button>
            <Button onClick={doDelete} disabled={deleting} className="bg-red-600 hover:bg-red-500 text-white">
              {deleting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />} Delete Role
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
