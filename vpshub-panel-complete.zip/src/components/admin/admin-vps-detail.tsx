'use client';

import { useEffect, useState, useRef } from 'react';
import { useAppStore, canProvision, isSuperUser } from '@/lib/frontend/store';
import { adminApi, customerApi, friendlyMessage } from '@/lib/frontend/api';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { StatusBadge } from '@/components/shared/status-badge';
import {
  Tabs, TabsContent, TabsList, TabsTrigger,
} from '@/components/ui/tabs';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  HardDrive, Play, Square, RotateCw, Power, ChevronLeft, Cpu, MemoryStick,
  HardDrive as Disk, Network, MapPin, Globe, Server, Activity, Loader2,
  Trash2, RefreshCw, Ban, CheckCircle2, AlertTriangle, ExternalLink,
  Settings2, Repeat, ArrowRight, Activity as ActivityIcon, User,
  Key, Copy, Check, Eye, EyeOff, ShieldCheck,
} from 'lucide-react';
import { io, Socket } from 'socket.io-client';
import { toast } from 'sonner';
import { VpsConsole } from '@/components/customer/vps-console';
import { VpsPortForwards } from '@/components/shared/vps-port-forwards';

export function AdminVpsDetail() {
  const { viewParams, setView, user } = useAppStore();
  const id = viewParams?.id as string;
  const [vps, setVps] = useState<any>(null);
  const [job, setJob] = useState<any>(null);
  const [nodes, setNodes] = useState<any[]>([]);
  const [osList, setOsList] = useState<any[]>([]);
  const [activity, setActivity] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [tab, setTab] = useState('overview');
  const [migrateOpen, setMigrateOpen] = useState(false);
  const [resizeOpen, setResizeOpen] = useState(false);
  const [suspendOpen, setSuspendOpen] = useState(false);
  const [suspendReason, setSuspendReason] = useState('Manual administrative action');
  const [reinstallOpen, setReinstallOpen] = useState(false);
  const [migrateNodeId, setMigrateNodeId] = useState('');
  const [resize, setResize] = useState({ cpu: 2, ramMb: 4096, diskGb: 80 });
  const [reinstallOsId, setReinstallOsId] = useState('');
  const socketRef = useRef<Socket | null>(null);
  const [progress, setProgress] = useState<{ state: string; progress: number; message: string } | null>(null);
  const [pwVisible, setPwVisible] = useState(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const copyText = async (text: string, field: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedField(field);
      setTimeout(() => setCopiedField(null), 2000);
    } catch {
      const ta = document.createElement('textarea');
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
      setCopiedField(field);
      setTimeout(() => setCopiedField(null), 2000);
    }
  };

  const load = async () => {
    setLoading(true);
    const [v, a, n, o] = await Promise.all([
      adminApi.getVps(id),
      customerApi.activity(id),
      adminApi.nodes(),
      adminApi.os(),
    ]);
    if (v.success && v.data) {
      const data = v.data;
      setVps(data);
      setResize({ cpu: data.cpu, ramMb: data.ramMb, diskGb: data.diskGb });
      if (data.deployments?.length) {
        const latestJob = data.deployments[0];
        const jd = await adminApi.deployment(latestJob.id);
        if (jd.success && jd.data) setJob(jd.data);
      }
    }
    if (a.success && a.data) setActivity(a.data as any[]);
    if (n.success && n.data) setNodes(n.data);
    if (o.success && o.data) setOsList(o.data);
    setLoading(false);
  };

  useEffect(() => {
    load();
    // Connect to deployment progress websocket
    const socket = io('/?XTransformPort=3003', { transports: ['websocket', 'polling'] });
    socketRef.current = socket;
    socket.on('connect', () => {
      // Subscribe to deployment room for this VPS
      if (job?.id) socket.emit('subscribe', `deployment:${job.id}`);
      socket.emit('subscribe', `vps:${id}`);
    });
    socket.on('deployment.progress', (payload: any) => {
      setProgress({ state: payload.state, progress: payload.progress, message: payload.message });
      if (payload.state === 'COMPLETED' || payload.state === 'FAILED') {
        load();
      }
    });
    socket.on('vps.status.updated', () => load());
    return () => { socket.disconnect(); };
  }, [id]);

  const action = async (fn: () => Promise<any>, label: string) => {
    setBusy(true);
    const r = await fn();
    if (r.success) toast.success(`${label} successful`);
    else toast.error(`${label} failed: ${friendlyMessage(r)}`);
    await load();
    setBusy(false);
  };

  if (loading || !vps) {
    return <div className="flex items-center justify-center py-20"><Loader2 className="w-6 h-6 text-rose-400 animate-spin" /></div>;
  }

  const isProvisioner = canProvision(user?.role);
  const isSuper = isSuperUser(user?.role);

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center gap-3">
        <Button onClick={() => setView('admin-vps')} variant="ghost" size="sm" className="text-zinc-400 hover:text-white">
          <ChevronLeft className="w-4 h-4" /> Back to VPS
        </Button>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-rose-500/10 border border-rose-500/30 flex items-center justify-center shrink-0">
              <HardDrive className="w-5 h-5 text-rose-400" />
            </div>
            <div className="min-w-0">
              <h1 className="text-lg font-bold truncate">{vps.name}</h1>
              <p className="text-xs text-zinc-500 font-mono truncate">{vps.id}</p>
            </div>
          </div>
        </div>
        <StatusBadge status={vps.status} />
      </div>

      {/* Active deployment progress (if provisioning) */}
      {(vps.status === 'QUEUED' || vps.status === 'PROVISIONING' || progress) && (
        <Card className="glass-panel-red p-4">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <ActivityIcon className="w-4 h-4 text-rose-400" />
              <p className="text-sm font-semibold">Deployment in Progress</p>
              {progress && <Badge variant="outline" className="bg-rose-500/10 text-rose-300 border-rose-500/30 text-xs">{progress.state}</Badge>}
            </div>
            <span className="text-xs font-mono text-zinc-400">{progress?.progress || 0}%</span>
          </div>
          <div className="h-2 bg-zinc-900 rounded-full overflow-hidden">
            <div className="h-full bg-gradient-to-r from-rose-500 to-red-600 transition-all"
              style={{ width: `${progress?.progress || 0}%` }} />
          </div>
          <p className="text-xs text-zinc-400 mt-2">{progress?.message || 'Waiting for progress updates...'}</p>
        </Card>
      )}

      {/* Power + admin actions */}
      <Card className="glass-panel p-4">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2 flex-wrap">
            {isProvisioner && (
              <>
                <Button size="sm" disabled={busy || vps.status === 'RUNNING'} onClick={() => action(() => adminApi.powerVps(id, 'start'), 'Start')}
                  className="bg-emerald-600 hover:bg-emerald-500 text-white"><Play className="w-3.5 h-3.5" />Start</Button>
                <Button size="sm" disabled={busy || vps.status !== 'RUNNING'} onClick={() => action(() => adminApi.powerVps(id, 'stop'), 'Stop')}
                  variant="outline" className="border-zinc-700"><Square className="w-3.5 h-3.5" />Stop</Button>
                <Button size="sm" disabled={busy || vps.status !== 'RUNNING'} onClick={() => action(() => adminApi.powerVps(id, 'restart'), 'Restart')}
                  variant="outline" className="border-zinc-700"><RotateCw className="w-3.5 h-3.5" />Restart</Button>
                <Button size="sm" disabled={busy || vps.status !== 'RUNNING'} onClick={() => action(() => adminApi.powerVps(id, 'shutdown'), 'Shutdown')}
                  variant="outline" className="border-zinc-700"><Power className="w-3.5 h-3.5" />Shutdown</Button>
                <Button size="sm" disabled={busy || vps.status !== 'RUNNING'} onClick={() => action(() => adminApi.powerVps(id, 'force_stop'), 'Force stop')}
                  variant="outline" className="border-zinc-700"><Square className="w-3.5 h-3.5" />Force stop</Button>
              </>
            )}
          </div>
          <div className="flex items-center gap-1 flex-wrap">
            {isProvisioner && (
              <>
                <Button size="sm" variant="ghost" onClick={() => setReinstallOpen(true)} disabled={busy} className="text-amber-300 hover:text-amber-200"><RefreshCw className="w-3.5 h-3.5" />Reinstall</Button>
                <Button size="sm" variant="ghost" onClick={() => setResizeOpen(true)} disabled={busy} className="text-blue-300 hover:text-blue-200"><Settings2 className="w-3.5 h-3.5" />Resize</Button>
                <Button size="sm" variant="ghost" onClick={() => setMigrateOpen(true)} disabled={busy} className="text-purple-300 hover:text-purple-200"><Repeat className="w-3.5 h-3.5" />Migrate</Button>
                {vps.status === 'SUSPENDED' ? (
                  <Button size="sm" variant="ghost" onClick={() => action(() => adminApi.unsuspendVps(id), 'Unsuspend')} disabled={busy} className="text-emerald-300 hover:text-emerald-200"><CheckCircle2 className="w-3.5 h-3.5" />Unsuspend</Button>
                ) : (
                  <Button size="sm" variant="ghost" onClick={() => setSuspendOpen(true)} disabled={busy} className="text-amber-300 hover:text-amber-200"><Ban className="w-3.5 h-3.5" />Suspend</Button>
                )}
              </>
            )}
            {isSuper && (
              <Button size="sm" variant="ghost" onClick={() => { if (confirm('Delete this VPS? This will release IPs and audit logs are preserved.')) action(() => adminApi.deleteVps(id), 'Delete'); }} disabled={busy} className="text-red-300 hover:text-red-200"><Trash2 className="w-3.5 h-3.5" />Delete</Button>
            )}
          </div>
        </div>
      </Card>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="bg-zinc-950/50 border border-zinc-800 p-1 flex-wrap h-auto">
          <TabsTrigger value="overview" className="data-[state=active]:bg-rose-500/20 data-[state=active]:text-rose-300">Overview</TabsTrigger>
          <TabsTrigger value="console" className="data-[state=active]:bg-rose-500/20 data-[state=active]:text-rose-300">Console</TabsTrigger>
          <TabsTrigger value="ports" className="data-[state=active]:bg-rose-500/20 data-[state=active]:text-rose-300">Ports</TabsTrigger>
          <TabsTrigger value="deployment" className="data-[state=active]:bg-rose-500/20 data-[state=active]:text-rose-300">Deployment</TabsTrigger>
          <TabsTrigger value="network" className="data-[state=active]:bg-rose-500/20 data-[state=active]:text-rose-300">Network</TabsTrigger>
          <TabsTrigger value="activity" className="data-[state=active]:bg-rose-500/20 data-[state=active]:text-rose-300">Activity</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-4">
          <div className="space-y-4">
            <div className="grid lg:grid-cols-2 gap-4">
              <Card className="glass-panel p-5">
                <h3 className="text-sm font-semibold uppercase tracking-wider text-zinc-500 mb-4">Resources</h3>
                <div className="space-y-3">
                  <Row icon={Cpu} label="CPU" value={`${vps.cpu} vCPU`} />
                  <Row icon={MemoryStick} label="RAM" value={`${(vps.ramMb / 1024).toFixed(0)} GB`} />
                  <Row icon={Disk} label="Disk" value={`${vps.diskGb} GB`} />
                  <Row icon={Network} label="Bandwidth" value={`${(vps.bandwidthMbps / 1000).toFixed(1)} Gbps`} />
                </div>
              </Card>
              <Card className="glass-panel p-5">
                <h3 className="text-sm font-semibold uppercase tracking-wider text-zinc-500 mb-4">Server Info</h3>
                <div className="space-y-3">
                  <Row icon={Server} label="Hostname" value={vps.hostname} mono />
                  <Row icon={Globe} label="IPv4" value={vps.ipv4 || '—'} mono />
                  <Row icon={Globe} label="IPv6" value={vps.ipv6 || '—'} mono />
                  <Row icon={MapPin} label="Location" value={vps.node ? `${vps.node.region} · ${vps.node.datacenter}` : '—'} />
                  <Row icon={HardDrive} label="OS" value={vps.os?.name || '—'} />
                  <Row icon={User} label="Owner" value={vps.owner?.email || '—'} mono />
                  <Row icon={Activity} label="Provider ID" value={vps.providerResourceId || '—'} mono />
                </div>
              </Card>
            </div>

            {/* SSH Access — auto-generated credentials, login reads root@ownername */}
            <Card className="glass-panel-red p-5">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-semibold uppercase tracking-wider text-zinc-500 flex items-center gap-2">
                  <Key className="w-4 h-4 text-rose-400" /> SSH Access
                  <Badge variant="outline" className="bg-emerald-500/10 text-emerald-300 border-emerald-500/30 text-[10px] normal-case">Auto-generated at creation</Badge>
                </h3>
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  {/* Login — root@ownername */}
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-zinc-600 mb-1.5">Login (user@host)</p>
                    <div className="flex items-center gap-2">
                      <code className="flex-1 px-3 py-2 rounded-md bg-black/60 border border-zinc-800 font-mono text-sm text-rose-200 select-all">root@{vps.hostname}</code>
                      <Button size="sm" variant="outline" onClick={() => copyText(`root@${vps.hostname}`, 'login')} className="h-9 border-zinc-700 text-zinc-300 hover:text-white">
                        {copiedField === 'login' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </Button>
                    </div>
                  </div>
                  {/* SSH command */}
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-zinc-600 mb-1.5">Connect via IP</p>
                    <div className="flex items-center gap-2">
                      <code className="flex-1 px-3 py-2 rounded-md bg-black/60 border border-zinc-800 font-mono text-sm text-zinc-300 select-all">ssh root@{vps.ipv4 || vps.hostname}</code>
                      <Button size="sm" variant="outline" onClick={() => copyText(`ssh root@${vps.ipv4 || vps.hostname}`, 'cmd')} className="h-9 border-zinc-700 text-zinc-300 hover:text-white">
                        {copiedField === 'cmd' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </Button>
                    </div>
                  </div>
                  {/* Root password */}
                  {vps.rootPasswordPlain && (
                    <div>
                      <p className="text-[10px] uppercase tracking-wider text-zinc-600 mb-1.5">Root password</p>
                      <div className="flex items-center gap-2">
                        <code className="flex-1 px-3 py-2 rounded-md bg-black/60 border border-zinc-800 font-mono text-sm text-zinc-300 select-all">
                          {pwVisible ? vps.rootPasswordPlain : '•'.repeat(Math.min(24, vps.rootPasswordPlain.length))}
                        </code>
                        <Button size="sm" variant="outline" onClick={() => setPwVisible(v => !v)} className="h-9 border-zinc-700 text-zinc-300 hover:text-white">
                          {pwVisible ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => copyText(vps.rootPasswordPlain, 'pw')} className="h-9 border-zinc-700 text-zinc-300 hover:text-white">
                          {copiedField === 'pw' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
                <div className="space-y-3">
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-zinc-600 mb-1.5">Authorized public key (ED25519)</p>
                    <div className="p-3 rounded-md bg-black/60 border border-zinc-800 max-h-28 overflow-y-auto">
                      <p className="font-mono text-xs text-zinc-300 break-all leading-relaxed select-all">{vps.sshPublicKey || '—'}</p>
                    </div>
                  </div>
                  <p className="text-xs text-zinc-500 flex items-start gap-2">
                    <ShieldCheck className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                    Credentials were generated automatically when the VPS was deployed. The hostname derives from the owner's name, so the login reads root@{vps.hostname}.
                  </p>
                </div>
              </div>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="console" className="mt-4">
          <VpsConsole vpsId={id} running={vps.status === 'RUNNING'} suspended={vps.status === 'SUSPENDED'} hostname={vps.hostname} />
        </TabsContent>

        <TabsContent value="ports" className="mt-4">
          <VpsPortForwards
            vpsId={id}
            vpsStatus={vps.status}
            api={{
              list: adminApi.forwards,
              add: adminApi.addForward,
              remove: adminApi.deleteForward,
            }} />
        </TabsContent>

        <TabsContent value="deployment" className="mt-4">
          {job ? (
            <Card className="glass-panel p-5">
              <h3 className="text-sm font-semibold uppercase tracking-wider text-zinc-500 mb-4">Latest Deployment Job</h3>
              <div className="space-y-2 mb-4">
                <Row icon={Activity} label="Job ID" value={job.id} mono />
                <Row icon={Activity} label="State" value={job.state} mono />
                <Row icon={Activity} label="Progress" value={`${job.progress}%`} />
                <Row icon={Activity} label="Initiated by" value={job.initiatedBy?.email || '—'} />
                {job.startedAt && <Row icon={Activity} label="Started" value={new Date(job.startedAt).toLocaleString()} />}
                {job.completedAt && <Row icon={Activity} label="Completed" value={new Date(job.completedAt).toLocaleString()} />}
              </div>
              <h4 className="text-xs uppercase tracking-wider text-zinc-500 mt-6 mb-3">Steps</h4>
              <div className="space-y-2">
                {job.steps.map((s: any) => (
                  <div key={s.id} className="flex items-start gap-3 p-3 rounded-md bg-zinc-900/60 border border-zinc-800">
                    <div className="w-7 h-7 rounded-md flex items-center justify-center shrink-0"
                      style={{
                        background: s.status === 'COMPLETED' ? 'rgba(16, 185, 129, 0.15)' : s.status === 'FAILED' ? 'rgba(239, 68, 68, 0.15)' : 'rgba(225, 29, 72, 0.15)',
                        color: s.status === 'COMPLETED' ? '#10b981' : s.status === 'FAILED' ? '#ef4444' : '#e11d48',
                      }}>
                      {s.status === 'COMPLETED' ? <CheckCircle2 className="w-3 h-3" /> :
                       s.status === 'FAILED' ? <AlertTriangle className="w-3 h-3" /> :
                       <Loader2 className="w-3 h-3 animate-spin" />}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-mono">{s.stepName}</p>
                      <p className="text-xs text-zinc-400">{s.message}</p>
                      <p className="text-[10px] text-zinc-600 mt-0.5">
                        Status: {s.status}
                        {s.durationMs ? ` · ${s.durationMs}ms` : ''}
                        {s.startedAt ? ` · ${new Date(s.startedAt).toLocaleTimeString()}` : ''}
                      </p>
                      {s.errorMessage && <p className="text-xs text-red-400 mt-1">{s.errorMessage}</p>}
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          ) : (
            <Card className="glass-panel p-8 text-center">
              <Activity className="w-10 h-10 text-zinc-700 mx-auto mb-2" />
              <p className="text-sm text-zinc-500">No deployment jobs yet</p>
              {isProvisioner && (
                <Button onClick={() => action(() => adminApi.deployVps(id), 'Redeploy')} disabled={busy} className="mt-3 bg-rose-600 hover:bg-rose-500 text-white">
                  <RefreshCw className="w-4 h-4" /> Redeploy
                </Button>
              )}
            </Card>
          )}
        </TabsContent>

        <TabsContent value="network" className="mt-4">
          <Card className="glass-panel p-5">
            <h3 className="text-sm font-semibold uppercase tracking-wider text-zinc-500 mb-4">Network Configuration</h3>
            <div className="space-y-3">
              <Row icon={Globe} label="IPv4 Address" value={vps.ipv4 || '—'} mono />
              <Row icon={Globe} label="IPv6 Address" value={vps.ipv6 || '—'} mono />
              <Row icon={Network} label="Gateway" value={vps.gateway || '—'} mono />
              <Row icon={Network} label="DNS Primary" value={vps.dnsPrimary || '—'} mono />
              <Row icon={Network} label="DNS Secondary" value={vps.dnsSecondary || '—'} mono />
              <Row icon={Globe} label="Reverse DNS" value={vps.reverseDns || '—'} mono />
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="activity" className="mt-4">
          <Card className="glass-panel p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold uppercase tracking-wider text-zinc-500">Activity Log</h3>
              <Button onClick={load} variant="ghost" size="sm" className="text-zinc-400 hover:text-white"><RefreshCw className="w-4 h-4" /></Button>
            </div>
            <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
              {activity.map(a => (
                <div key={a.id} className="flex items-start gap-3 p-3 rounded-md bg-zinc-900/50 border border-zinc-800">
                  <div className="w-7 h-7 rounded bg-zinc-800 flex items-center justify-center shrink-0">
                    <Activity className="w-3 h-3 text-zinc-400" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-medium text-zinc-200">{a.action}</p>
                    <p className="text-xs text-zinc-500">{a.message}</p>
                    <p className="text-[10px] text-zinc-600 mt-0.5">{new Date(a.createdAt).toLocaleString()} · {a.actor}</p>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Migrate Dialog */}
      <Dialog open={migrateOpen} onOpenChange={setMigrateOpen}>
        <DialogContent className="bg-zinc-950 border-zinc-800">
          <DialogHeader><DialogTitle>Migrate VPS to New Node</DialogTitle></DialogHeader>
          <div className="space-y-3 py-4">
            <Label>Destination Node</Label>
            <Select value={migrateNodeId} onValueChange={setMigrateNodeId}>
              <SelectTrigger className="bg-zinc-950/50 border-zinc-800"><SelectValue placeholder="Select node" /></SelectTrigger>
              <SelectContent className="bg-zinc-950 border-zinc-800">
                {nodes.filter(n => n.id !== vps.nodeId && n.enabled && !n.maintenanceMode && n.health === 'ONLINE').map(n => (
                  <SelectItem key={n.id} value={n.id}>{n.name} · {n.region}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <div className="text-xs text-amber-300 bg-amber-500/10 border border-amber-500/20 p-3 rounded">
              Migration will perform provider-side live migration. The database node will only be updated after a successful migration.
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setMigrateOpen(false)} className="border-zinc-800">Cancel</Button>
            <Button onClick={() => { action(() => adminApi.migrateVps(id, migrateNodeId), 'Migration'); setMigrateOpen(false); }} disabled={!migrateNodeId || busy} className="bg-rose-600 hover:bg-rose-500 text-white">Migrate</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Resize Dialog */}
      <Dialog open={resizeOpen} onOpenChange={setResizeOpen}>
        <DialogContent className="bg-zinc-950 border-zinc-800">
          <DialogHeader><DialogTitle>Resize VPS Resources</DialogTitle></DialogHeader>
          <div className="space-y-3 py-4">
            <div className="grid grid-cols-3 gap-3">
              <div><Label>CPU</Label><Input type="number" min={1} value={resize.cpu} onChange={e => setResize(p => ({ ...p, cpu: +e.target.value }))} className="bg-zinc-950/50 border-zinc-800" /></div>
              <div><Label>RAM (GB)</Label><Input type="number" min={0.5} step={0.5} value={resize.ramMb / 1024} onChange={e => setResize(p => ({ ...p, ramMb: Math.round(+e.target.value * 1024) }))} className="bg-zinc-950/50 border-zinc-800" /></div>
              <div><Label>Disk (GB)</Label><Input type="number" min={10} value={resize.diskGb} onChange={e => setResize(p => ({ ...p, diskGb: +e.target.value }))} className="bg-zinc-950/50 border-zinc-800" /></div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setResizeOpen(false)} className="border-zinc-800">Cancel</Button>
            <Button onClick={() => { action(() => adminApi.resizeVps(id, resize), 'Resize'); setResizeOpen(false); }} disabled={busy} className="bg-rose-600 hover:bg-rose-500 text-white">Resize</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Suspend Dialog */}
      <Dialog open={suspendOpen} onOpenChange={setSuspendOpen}>
        <DialogContent className="bg-zinc-950 border-zinc-800">
          <DialogHeader><DialogTitle>Suspend VPS</DialogTitle></DialogHeader>
          <div className="space-y-3 py-4">
            <Label>Reason</Label>
            <Select value={suspendReason} onValueChange={setSuspendReason}>
              <SelectTrigger className="bg-zinc-950/50 border-zinc-800"><SelectValue /></SelectTrigger>
              <SelectContent className="bg-zinc-950 border-zinc-800">
                <SelectItem value="Payment issue">Payment issue</SelectItem>
                <SelectItem value="Abuse">Abuse</SelectItem>
                <SelectItem value="Terms violation">Terms violation</SelectItem>
                <SelectItem value="Account suspension">Account suspension</SelectItem>
                <SelectItem value="Manual administrative action">Manual administrative action</SelectItem>
                <SelectItem value="Resource abuse">Resource abuse</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setSuspendOpen(false)} className="border-zinc-800">Cancel</Button>
            <Button onClick={() => { action(() => adminApi.suspendVps(id, suspendReason), 'Suspend'); setSuspendOpen(false); }} disabled={busy} className="bg-amber-600 hover:bg-amber-500 text-white"><Ban className="w-4 h-4" />Suspend</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reinstall Dialog */}
      <Dialog open={reinstallOpen} onOpenChange={setReinstallOpen}>
        <DialogContent className="bg-zinc-950 border-zinc-800">
          <DialogHeader><DialogTitle>Reinstall Operating System</DialogTitle></DialogHeader>
          <div className="space-y-3 py-4">
            <Label>Operating System</Label>
            <Select value={reinstallOsId} onValueChange={setReinstallOsId}>
              <SelectTrigger className="bg-zinc-950/50 border-zinc-800"><SelectValue placeholder="Keep current" /></SelectTrigger>
              <SelectContent className="bg-zinc-950 border-zinc-800">
                {osList.filter(o => o.available).map(o => <SelectItem key={o.id} value={o.id}>{o.name}</SelectItem>)}
              </SelectContent>
            </Select>
            <div className="text-xs text-red-300 bg-red-500/10 border border-red-500/20 p-3 rounded">
              Warning: All data on the VPS will be destroyed.
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setReinstallOpen(false)} className="border-zinc-800">Cancel</Button>
            <Button onClick={() => { action(() => adminApi.reinstallVps(id, reinstallOsId), 'Reinstall'); setReinstallOpen(false); }} disabled={busy} className="bg-amber-600 hover:bg-amber-500 text-white"><RefreshCw className="w-4 h-4" />Reinstall</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

import { User as UserIcon } from 'lucide-react';

function Row({ icon: Icon, label, value, mono }: { icon: any; label: string; value: string; mono?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-3 py-1">
      <div className="flex items-center gap-2 text-sm text-zinc-400">
        <Icon className="w-4 h-4 text-zinc-500" />
        <span>{label}</span>
      </div>
      <span className={`text-sm text-zinc-200 ${mono ? 'font-mono text-xs' : ''} truncate max-w-60`}>{value}</span>
    </div>
  );
}
