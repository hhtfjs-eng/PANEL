'use client';

import { useEffect, useState } from 'react';
import { useAppStore, isSuperUser } from '@/lib/frontend/store';
import { adminApi, friendlyMessage } from '@/lib/frontend/api';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { StatusBadge } from '@/components/shared/status-badge';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger,
} from '@/components/ui/dialog';
import {
  Users, Search, RefreshCw, Eye, Ban, Check, Trash2, Key, Mail, ChevronRight, Loader2, UserCog,
} from 'lucide-react';
import { toast } from 'sonner';

export function AdminUsers() {
  const { setView, user } = useAppStore();
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('all');
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [resetOpen, setResetOpen] = useState<string | null>(null);
  const [newPass, setNewPass] = useState('');
  const isSuper = isSuperUser(user?.role);
  const isSuperAdmin = user?.role === 'SUPER_ADMIN';

  // ── Role management ──
  const [roleTarget, setRoleTarget] = useState<any | null>(null); // user being edited
  const [roleValue, setRoleValue] = useState('');
  const [roleOptions, setRoleOptions] = useState<any[] | null>(null); // built-ins + custom roles
  const [roleBusy, setRoleBusy] = useState(false);

  const openRole = async (u: any) => {
    setRoleTarget(u);
    setRoleValue(u.role);
    setRoleBusy(false);
    if (!roleOptions) {
      const r = await adminApi.roles();
      if (r.success && r.data) setRoleOptions(r.data);
      else setRoleOptions([]);
    }
  };

  const saveRole = async () => {
    if (!roleTarget || !roleValue || roleValue === roleTarget.role) { setRoleTarget(null); return; }
    setRoleBusy(true);
    const r = await adminApi.updateUser(roleTarget.id, { role: roleValue });
    setRoleBusy(false);
    if (r.success) {
      toast.success(`${roleTarget.name}'s role is now ${roleValue}`);
      setRoleTarget(null);
      load();
    } else {
      toast.error(`Failed: ${friendlyMessage(r)}`);
    }
  };

  const ROLE_LABELS: Record<string, string> = {
    USER: 'User (customer)',
    SUPPORT: 'Support',
    STAFF: 'Staff',
    ADMIN: 'Admin',
    SUPER_ADMIN: 'Super Admin',
  };

  const load = async () => {
    setLoading(true);
    const r = await adminApi.users({ search, status: status === 'all' ? '' : status, page, pageSize: 25 });
    if (r.success && r.data) {
      setUsers(r.data);
      setTotal(r.pagination?.total || 0);
      setTotalPages(r.pagination?.totalPages || 1);
    }
    setLoading(false);
  };

  useEffect(() => { load(); }, [page, status]);
  useEffect(() => { const t = setTimeout(load, 350); return () => clearTimeout(t); }, [search]);

  const action = async (id: string, fn: () => Promise<any>, label: string) => {
    const r = await fn();
    if (r.success) toast.success(`${label} successful`);
    else toast.error(`${label} failed: ${friendlyMessage(r)}`);
    load();
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2">
            Users <Badge variant="outline" className="bg-rose-500/10 text-rose-300 border-rose-500/30">Admin</Badge>
          </h2>
          <p className="text-xs text-zinc-500">All registered customers</p>
        </div>
        <Button onClick={load} variant="outline" size="sm" className="border-zinc-800"><RefreshCw className="w-4 h-4" /></Button>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
          <Input value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} placeholder="Search by name, email, username..." className="pl-9 bg-zinc-950/50 border-zinc-800" />
        </div>
        <Select value={status} onValueChange={(v) => { setStatus(v); setPage(1); }}>
          <SelectTrigger className="w-40 bg-zinc-950/50 border-zinc-800"><SelectValue /></SelectTrigger>
          <SelectContent className="bg-zinc-950 border-zinc-800">
            <SelectItem value="all">All</SelectItem>
            <SelectItem value="ACTIVE">Active</SelectItem>
            <SelectItem value="SUSPENDED">Suspended</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Card className="glass-panel overflow-hidden p-0">
        <Table>
          <TableHeader>
            <TableRow className="border-zinc-800 hover:bg-transparent">
              <TableHead className="text-zinc-500">User</TableHead>
              <TableHead className="text-zinc-500">Email</TableHead>
              <TableHead className="text-zinc-500">Role</TableHead>
              <TableHead className="text-zinc-500">Status</TableHead>
              <TableHead className="text-zinc-500 hidden md:table-cell">Verified</TableHead>
              <TableHead className="text-zinc-500 hidden lg:table-cell">VPS</TableHead>
              <TableHead className="text-zinc-500 hidden lg:table-cell">Last login</TableHead>
              <TableHead className="text-zinc-500 hidden xl:table-cell">Registered</TableHead>
              <TableHead></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow><TableCell colSpan={9} className="text-center py-12"><Loader2 className="w-5 h-5 animate-spin mx-auto text-zinc-500" /></TableCell></TableRow>
            ) : users.length === 0 ? (
              <TableRow><TableCell colSpan={9} className="text-center py-12 text-zinc-500">No users found</TableCell></TableRow>
            ) : users.map(u => (
              <TableRow key={u.id} className="border-zinc-800 hover:bg-zinc-900/40">
                <TableCell>
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-zinc-800 border border-zinc-700 flex items-center justify-center text-xs uppercase">{(u.name?.charAt(0) || "?")}</div>
                    <div>
                      <p className="font-medium">{u.name}</p>
                      <p className="text-xs text-zinc-500 font-mono">@{u.username}</p>
                    </div>
                  </div>
                </TableCell>
                <TableCell className="text-sm text-zinc-300">{u.email}</TableCell>
                <TableCell>
                  <Badge variant="outline" className={
                    u.role === 'SUPER_ADMIN' || u.role === 'ADMIN' ? 'bg-rose-500/10 text-rose-300 border-rose-500/30' :
                    u.role === 'STAFF' || u.role === 'SUPPORT' ? 'bg-amber-500/10 text-amber-300 border-amber-500/30' :
                    'bg-zinc-500/10 text-zinc-400 border-zinc-500/30'
                  }>{u.role}</Badge>
                </TableCell>
                <TableCell><StatusBadge status={u.status} size="sm" /></TableCell>
                <TableCell className="hidden md:table-cell">
                  {u.emailVerified ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Mail className="w-3.5 h-3.5 text-amber-400" />}
                </TableCell>
                <TableCell className="hidden lg:table-cell text-xs">{u.vpsCount || 0}</TableCell>
                <TableCell className="hidden lg:table-cell text-xs text-zinc-500">{u.lastLogin ? new Date(u.lastLogin).toLocaleDateString() : '—'}</TableCell>
                <TableCell className="hidden xl:table-cell text-xs text-zinc-500">{new Date(u.createdAt).toLocaleDateString()}</TableCell>
                <TableCell>
                  <div className="flex items-center gap-1">
                    <Button size="sm" variant="ghost" onClick={() => action(u.id, () => adminApi.userAction(u.id, u.status === 'SUSPENDED' ? 'unsuspend' : 'suspend'), u.status === 'SUSPENDED' ? 'Unsuspend' : 'Suspend')}
                      className="h-7 w-7 p-0 text-amber-400 hover:text-amber-300">
                      {u.status === 'SUSPENDED' ? <Check className="w-3.5 h-3.5" /> : <Ban className="w-3.5 h-3.5" />}
                    </Button>
                    {!u.emailVerified && (
                      <Button size="sm" variant="ghost" onClick={() => action(u.id, () => adminApi.userAction(u.id, 'verify'), 'Verify')} className="h-7 w-7 p-0 text-emerald-400 hover:text-emerald-300">
                        <Check className="w-3.5 h-3.5" />
                      </Button>
                    )}
                    {isSuper && u.id !== user?.id && (isSuperAdmin || u.role !== 'SUPER_ADMIN') && (
                      <Button size="sm" variant="ghost" title="Change role" onClick={() => openRole(u)} className="h-7 w-7 p-0 text-rose-400 hover:text-rose-300">
                        <UserCog className="w-3.5 h-3.5" />
                      </Button>
                    )}
                    {isSuper && (
                      <Button size="sm" variant="ghost" onClick={() => setResetOpen(u.id)} className="h-7 w-7 p-0 text-blue-400 hover:text-blue-300">
                        <Key className="w-3.5 h-3.5" />
                      </Button>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>

      <div className="flex items-center justify-between">
        <p className="text-xs text-zinc-500">{total} total · page {page} of {totalPages}</p>
        <div className="flex gap-1">
          <Button size="sm" variant="outline" disabled={page <= 1} onClick={() => setPage(p => p - 1)} className="border-zinc-800">Prev</Button>
          <Button size="sm" variant="outline" disabled={page >= totalPages} onClick={() => setPage(p => p + 1)} className="border-zinc-800">Next</Button>
        </div>
      </div>

      <Dialog open={!!roleTarget} onOpenChange={(o) => !o && setRoleTarget(null)}>
        <DialogContent className="bg-zinc-950 border-zinc-800">
          <DialogHeader><DialogTitle>Change Role</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div className="flex items-center gap-3 rounded-lg border border-zinc-800 bg-zinc-900/40 px-3 py-2">
              <div className="w-8 h-8 rounded-full bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-xs uppercase text-rose-200">{roleTarget?.name?.charAt(0)}</div>
              <div className="min-w-0">
                <p className="font-medium truncate">{roleTarget?.name}</p>
                <p className="text-xs text-zinc-500 font-mono truncate">@{roleTarget?.username} · current role: {roleTarget?.role}</p>
              </div>
            </div>
            <div>
              <Label>New Role</Label>
              <Select value={roleValue} onValueChange={setRoleValue}>
                <SelectTrigger className="bg-zinc-950/50 border-zinc-800"><SelectValue /></SelectTrigger>
                <SelectContent className="bg-zinc-950 border-zinc-800">
                  {(roleOptions ?? []).map((r: any) => (
                    <SelectItem key={r.key} value={r.key}>
                      {ROLE_LABELS[r.key] || `${r.name}${r.isSystem ? '' : ' (custom)'}`}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-zinc-500 mt-2">
                Changing a role updates their permissions immediately (on their next request). Custom roles created in the Role Editor can also be assigned here.
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRoleTarget(null)} className="border-zinc-800" disabled={roleBusy}>Cancel</Button>
            <Button onClick={saveRole} disabled={roleBusy || roleValue === roleTarget?.role} className="bg-rose-600 hover:bg-rose-500 text-white">
              {roleBusy ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Save Role'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!resetOpen} onOpenChange={(o) => !o && setResetOpen(null)}>
        <DialogContent className="bg-zinc-950 border-zinc-800">
          <DialogHeader><DialogTitle>Reset User Password</DialogTitle></DialogHeader>
          <div className="space-y-3 py-4">
            <Label>New Password</Label>
            <Input type="password" value={newPass} onChange={(e) => setNewPass(e.target.value)} placeholder="Min 8 characters" className="bg-zinc-950/50 border-zinc-800" />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setResetOpen(null)} className="border-zinc-800">Cancel</Button>
            <Button onClick={() => { if (newPass.length < 8) { toast.error('Password must be at least 8 chars'); return; } action(resetOpen!, () => adminApi.userAction(resetOpen!, 'reset_password', { password: newPass }), 'Password reset'); setResetOpen(null); setNewPass(''); }} className="bg-rose-600 hover:bg-rose-500 text-white">Reset</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
