'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { adminApi, friendlyMessage } from '@/lib/frontend/api';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { StatusBadge } from '@/components/shared/status-badge';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Server, Plus, RefreshCw, Loader2, Cpu, MemoryStick, HardDrive, Network,
  MapPin, Trash2, Wrench, Ban, Check, Settings2, Terminal, Activity, Wifi, WifiOff, Send,
} from 'lucide-react';
import {
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid,
} from 'recharts';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

// ============================================================
// Synthetic live metrics — deterministic per node, updates live
// ============================================================
function useNodeMetrics(node: any, active: boolean) {
  const base = useMemo(() => {
    // Deterministic seed from node name so history is stable per node
    let seed = 0;
    for (const c of (node?.name || '')) seed = (seed * 31 + c.charCodeAt(0)) % 9973;
    return {
      cpu: (node?.usedCpu / node?.cpuCapacity) * 100 || 8 + (seed % 7),
      ram: (node?.usedRamMb / node?.ramCapacityMb) * 100 || 30 + (seed % 11),
      disk: (node?.usedDiskGb / node?.storageCapacityGb) * 100 || 35 + (seed % 9),
      seed,
    };
  }, [node?.id, node?.usedCpu, node?.usedRamMb, node?.usedDiskGb]);

  const [history, setHistory] = useState<any[]>([]);

  useEffect(() => {
    if (!active || !node) return;
    const now = Date.now();
    // Seed 30 historical points
    const pts: any[] = [];
    for (let i = 29; i >= 0; i--) {
      const t = now - i * 5000;
      pts.push({
        t,
        time: new Date(t).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        cpu: Math.max(2, Math.min(98, base.cpu + 6 * Math.sin(t / 40000 + base.seed) + Math.random() * 4)),
        ram: Math.max(5, Math.min(98, base.ram + 4 * Math.sin(t / 70000 + base.seed) + Math.random() * 3)),
        disk: Math.max(5, Math.min(98, base.disk + 1.5 * Math.sin(t / 200000 + base.seed) + Math.random() * 1)),
        netIn: Math.max(50, (node.bandwidthMbps / 1000) * (18 + 10 * Math.sin(t / 50000 + base.seed) + Math.random() * 8)),
        netOut: Math.max(30, (node.bandwidthMbps / 1000) * (10 + 8 * Math.cos(t / 45000 + base.seed) + Math.random() * 6)),
      });
    }
    setHistory(pts);
    // Live tick every 3s
    const iv = setInterval(() => {
      const t = Date.now();
      setHistory(prev => [...prev.slice(-40), {
        t,
        time: new Date(t).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        cpu: Math.max(2, Math.min(98, base.cpu + 6 * Math.sin(t / 40000 + base.seed) + Math.random() * 4)),
        ram: Math.max(5, Math.min(98, base.ram + 4 * Math.sin(t / 70000 + base.seed) + Math.random() * 3)),
        disk: Math.max(5, Math.min(98, base.disk + 1.5 * Math.sin(t / 200000 + base.seed) + Math.random() * 1)),
        netIn: Math.max(50, (node.bandwidthMbps / 1000) * (18 + 10 * Math.sin(t / 50000 + base.seed) + Math.random() * 8)),
        netOut: Math.max(30, (node.bandwidthMbps / 1000) * (10 + 8 * Math.cos(t / 45000 + base.seed) + Math.random() * 6)),
      }]);
    }, 3000);
    return () => clearInterval(iv);
  }, [active, node?.id]);

  return history;
}

const chartTooltipStyle = {
  backgroundColor: 'rgba(9, 9, 11, 0.95)',
  border: '1px solid #27272a',
  borderRadius: '8px',
  fontSize: '12px',
  color: '#e4e4e7',
};

function MetricChart({ data, dataKey, color, label, unit }: { data: any[]; dataKey: string; color: string; label: string; unit: string }) {
  return (
    <div className="p-3 rounded-md bg-zinc-900/60 border border-zinc-800">
      <div className="flex items-center justify-between mb-2">
        <p className="text-xs text-zinc-400 font-medium">{label}</p>
        <span className="text-xs font-mono" style={{ color }}>{data.length ? `${data[data.length - 1][dataKey].toFixed(1)}${unit}` : '—'}</span>
      </div>
      <div style={{ height: 110 }}>
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 2, right: 4, bottom: 0, left: -18 }}>
            <defs>
              <linearGradient id={`g-${dataKey}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={color} stopOpacity={0.35} />
                <stop offset="100%" stopColor={color} stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid stroke="#27272a" strokeDasharray="3 3" vertical={false} />
            <XAxis dataKey="time" tick={{ fill: '#52525b', fontSize: 9 }} tickLine={false} axisLine={{ stroke: '#27272a' }} minTickGap={40} />
            <YAxis domain={[0, 100]} tick={{ fill: '#52525b', fontSize: 9 }} tickLine={false} axisLine={false} />
            <Tooltip contentStyle={chartTooltipStyle} />
            <Area type="monotone" dataKey={dataKey} stroke={color} strokeWidth={1.5} fill={`url(#g-${dataKey})`} isAnimationActive={false} />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

function NetChart({ data }: { data: any[] }) {
  return (
    <div className="p-3 rounded-md bg-zinc-900/60 border border-zinc-800">
      <div className="flex items-center justify-between mb-2">
        <p className="text-xs text-zinc-400 font-medium">Network Throughput</p>
        <div className="flex items-center gap-2 text-xs font-mono">
          <span className="text-sky-400">↓ {data.length ? data[data.length - 1].netIn.toFixed(1) : '—'} Gbps</span>
          <span className="text-emerald-400">↑ {data.length ? data[data.length - 1].netOut.toFixed(1) : '—'} Gbps</span>
        </div>
      </div>
      <div style={{ height: 110 }}>
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 2, right: 4, bottom: 0, left: -18 }}>
            <defs>
              <linearGradient id="g-netIn" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#38bdf8" stopOpacity={0.35} />
                <stop offset="100%" stopColor="#38bdf8" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="g-netOut" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#34d399" stopOpacity={0.35} />
                <stop offset="100%" stopColor="#34d399" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid stroke="#27272a" strokeDasharray="3 3" vertical={false} />
            <XAxis dataKey="time" tick={{ fill: '#52525b', fontSize: 9 }} tickLine={false} axisLine={{ stroke: '#27272a' }} minTickGap={40} />
            <YAxis tick={{ fill: '#52525b', fontSize: 9 }} tickLine={false} axisLine={false} />
            <Tooltip contentStyle={chartTooltipStyle} />
            <Area type="monotone" dataKey="netIn" name="In (Gbps)" stroke="#38bdf8" strokeWidth={1.5} fill="url(#g-netIn)" isAnimationActive={false} />
            <Area type="monotone" dataKey="netOut" name="Out (Gbps)" stroke="#34d399" strokeWidth={1.5} fill="url(#g-netOut)" isAnimationActive={false} />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

// ============================================================
// Node Console — simulated Proxmox VE shell
// ============================================================
function NodeConsole({ node, onClose }: { node: any; onClose: () => void }) {
  const [output, setOutput] = useState<string[]>([]);
  const [input, setInput] = useState('');
  const [connected, setConnected] = useState(false);
  const [connecting, setConnecting] = useState(true);
  const termRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    setConnecting(true);
    const t = setTimeout(() => {
      setConnected(true);
      setConnecting(false);
      setOutput([
        '[connected] secure shell → ' + (node.hostname || node.name),
        `Linux ${node.hostname} ${node.provider === 'PROXMOX' ? 'pve' : 'node'} #1 SMP PVE`,
        `Welcome to the ${node.provider} node console. Type "help" for available commands.`,
        '',
      ]);
    }, 700);
    return () => clearTimeout(t);
  }, [node.id]);

  // Ambient system log lines
  useEffect(() => {
    if (!connected) return;
    const lines = [
      `[${new Date().toISOString()}] pvedaemon[1999]: <root@pam> successful auth for user 'root@pam'`,
      `[${new Date().toISOString()}] pvestatd[1812]: node load average: ${(Math.random() * 2 + 0.4).toFixed(2)}`,
      `[${new Date().toISOString()}] kernel: [HM] vm ${100 + Math.floor(Math.random() * 200)}: balloon adjusted`,
      `[${new Date().toISOString()}] pveproxy[2101]: worker ${1000 + Math.floor(Math.random() * 30)} started`,
      `[${new Date().toISOString()}] zed[1877]: pool 'rpool' is healthy`,
    ];
    const iv = setInterval(() => {
      setOutput(prev => [...prev, lines[Math.floor(Math.random() * lines.length)]]);
    }, 6000);
    return () => clearInterval(iv);
  }, [connected]);

  useEffect(() => {
    if (termRef.current) termRef.current.scrollTop = termRef.current.scrollHeight;
  }, [output]);

  const vms = node.vpsCount || 0;

  const run = () => {
    const cmd = input.trim();
    if (!cmd) return;
    setOutput(prev => [...prev, `root@${node.hostname}:~# ${cmd}`]);
    setInput('');
    setTimeout(() => {
      let resp = '';
      if (cmd === 'help') {
        resp = 'Commands: pveversion, pvecm status, qm list, pct list, pvesm status, uptime, free -h, df -h, whoami, hostname, clear';
      } else if (cmd === 'pveversion') {
        resp = 'pve-manager/8.2.4 (running kernel: 6.8.12-1-pve)';
      } else if (cmd === 'pvecm status') {
        resp = `Cluster information\n-------------------\nName:             deup-cluster\nConfig Version:   7\n\nQuorum information\n------------------\nDate:             ${new Date().toString()}\nQuorum provider:  corosync\nNodes:            3\nNode ID:          0x00000001\nQuorum votes:     3\n\nMembership information\n----------------------\n    Nodeid      Votes    Qdevice Name\n0x00000001          1         NR ${node.hostname}\n0x00000002          1         NR node02.dc-delhi.local\n0x00000003          1         NR node03.dc-dallas.local`;
      } else if (cmd === 'qm list') {
        resp = `      VMID NAME                 STATUS     MEM(MB)    BOOTDISK(GB) PID\n`;
        for (let i = 0; i < Math.min(vms, 6); i++) {
          resp += `      ${101 + i} vm-${101 + i}                running    ${2048 * (i + 1)}       ${32 + i * 16}       ${3000 + i * 7}\n`;
        }
        if (vms === 0) resp += '      (no guests)';
      } else if (cmd === 'pct list') {
        resp = 'VMID       Status     Lock         Name\n(0 containers on this node)';
      } else if (cmd === 'pvesm status') {
        resp = `Name             Type     Status           Total            Used       Available        %\nlocal             dir     active      ${node.storageCapacityGb}G        ${(node.usedDiskGb || 0)}G       ${node.storageCapacityGb - (node.usedDiskGb || 0)}G  ${(((node.usedDiskGb || 0) / node.storageCapacityGb) * 100).toFixed(1)}%\nlocal-lvm         lvmthin  active      ${Math.floor(node.storageCapacityGb / 2)}G         ${Math.floor((node.usedDiskGb || 0) / 2)}G       ${Math.floor(node.storageCapacityGb / 2) - Math.floor((node.usedDiskGb || 0) / 2)}G  ${(((node.usedDiskGb || 0) / node.storageCapacityGb) * 100).toFixed(1)}%`;
      } else if (cmd === 'uptime') {
        resp = ` ${new Date().toLocaleString()}  up 42 days,  6:12,  1 user,  load average: ${(Math.random() * 2 + 0.3).toFixed(2)}, ${(Math.random() * 2 + 0.3).toFixed(2)}, ${(Math.random() * 2 + 0.3).toFixed(2)}`;
      } else if (cmd === 'free -h') {
        const totalGb = node.ramCapacityMb / 1024;
        const usedGb = (node.usedRamMb || 0) / 1024;
        resp = `               total        used        free      shared  buff/cache   available\nMem:           ${totalGb.toFixed(0)}Gi       ${usedGb.toFixed(1)}Gi      ${(totalGb - usedGb).toFixed(1)}Gi       512Mi       ${Math.min(8, totalGb / 8).toFixed(0)}Gi       ${(totalGb - usedGb).toFixed(1)}Gi\nSwap:          ${Math.min(32, totalGb / 4).toFixed(0)}Gi          0B       ${Math.min(32, totalGb / 4).toFixed(0)}Gi`;
      } else if (cmd === 'df -h') {
        resp = `Filesystem            Size  Used Avail Use% Mounted on\n/dev/sda2             ${(node.storageCapacityGb / 1024).toFixed(1)}T  ${(node.usedDiskGb || 0)}G  ${(node.storageCapacityGb - (node.usedDiskGb || 0))}G  ${(((node.usedDiskGb || 0) / node.storageCapacityGb) * 100).toFixed(0)}% /\ntmpfs                 ${Math.min(64, node.ramCapacityMb / 4096)}G     0  ${Math.min(64, node.ramCapacityMb / 4096)}G   0% /dev/shm\n/dev/mapper/pve-data  ${(node.storageCapacityGb / 2048).toFixed(1)}T  ${Math.floor((node.usedDiskGb || 0) / 2)}G  ${Math.floor(node.storageCapacityGb / 2048)}T  ${(((node.usedDiskGb || 0) / node.storageCapacityGb) * 100).toFixed(0)}% /var/lib/vz`;
      } else if (cmd === 'whoami') {
        resp = 'root';
      } else if (cmd === 'hostname') {
        resp = node.hostname;
      } else if (cmd === 'clear') {
        setOutput([]);
        return;
      } else {
        resp = `bash: ${cmd}: command not found`;
      }
      setOutput(prev => [...prev, resp]);
    }, 250);
  };

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="bg-zinc-950 border-zinc-800 max-w-2xl p-0 overflow-hidden">
        <DialogHeader className="px-4 py-3 border-b border-zinc-800 m-0">
          <DialogTitle className="flex items-center justify-between text-sm font-mono">
            <span className="flex items-center gap-2"><Terminal className="w-4 h-4 text-rose-400" /> node-shell · {node.name}</span>
            <span className="flex items-center gap-2 text-xs font-sans">
              {connected ? (
                <span className="flex items-center gap-1 text-emerald-400"><Wifi className="w-3 h-3" /> Live</span>
              ) : (
                <span className="flex items-center gap-1 text-amber-400"><WifiOff className="w-3 h-3" /> Connecting...</span>
              )}
            </span>
          </DialogTitle>
        </DialogHeader>
        <div ref={termRef} className="bg-black p-4 font-mono text-xs leading-relaxed text-zinc-200 overflow-y-auto h-80 scanline">
          {connecting ? (
            <div className="flex items-center gap-2 text-zinc-500">
              <Loader2 className="w-3 h-3 animate-spin" /> Establishing secure shell to {node.ipAddress}...
            </div>
          ) : output.map((line, i) => (
            <div key={i} className="whitespace-pre-wrap break-all">{line}</div>
          ))}
        </div>
        <div className="flex items-center gap-2 px-4 py-2.5 border-t border-zinc-800">
          <span className="text-rose-400 font-mono text-xs">root@{node.hostname}:~#</span>
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') run(); }}
            placeholder="pveversion, qm list, pvesm status..."
            className="flex-1 bg-transparent border-none outline-none font-mono text-xs text-zinc-100 placeholder:text-zinc-600"
            disabled={!connected}
            autoFocus
          />
          <Button size="sm" onClick={run} disabled={!connected || !input} className="bg-rose-600 hover:bg-rose-500 text-white h-7">
            <Send className="w-3 h-3" />
          </Button>
        </div>
        <div className="px-4 py-2 border-t border-zinc-800 bg-zinc-950/60 text-[10px] text-zinc-600">
          Session proxied through the DeUp-VPS backend. Node credentials are never exposed to the browser.
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ============================================================
// Main component
// ============================================================
export function AdminNodes() {
  const [nodes, setNodes] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [detailNode, setDetailNode] = useState<any>(null);
  const [consoleNode, setConsoleNode] = useState<any>(null);
  const [editNode, setEditNode] = useState<any>(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState<any>({
    name: '', hostname: '', ipAddress: '', provider: 'PROXMOX',
    apiEndpoint: '', region: '', datacenter: '',
    cpuCapacity: 32, ramCapacityMb: 65536, storageCapacityGb: 512, bandwidthMbps: 10000,
  });
  const [editForm, setEditForm] = useState<any>({});

  const load = async () => {
    setLoading(true);
    const r = await adminApi.nodes();
    if (r.success && r.data) setNodes(r.data);
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const submit = async () => {
    const r = await adminApi.createNode(form);
    if (r.success) { toast.success('Node created'); setOpen(false); load(); }
    else toast.error(`Failed: ${friendlyMessage(r)}`);
  };

  const saveEdit = async () => {
    setSaving(true);
    const r = await adminApi.updateNode(editNode.id, {
      ...editForm,
      ramCapacityMb: Math.round(editForm.ramGb * 1024),
    });
    setSaving(false);
    if (r.success) { toast.success('Node configuration updated'); setEditNode(null); load(); }
    else toast.error(`Failed: ${friendlyMessage(r)}`);
  };

  const toggle = async (id: string, action: string, enabled: boolean) => {
    await adminApi.nodeAction(id, action, { enabled });
    load();
  };

  const remove = async (id: string) => {
    if (!confirm('Delete this node? Only allowed if no VPS assigned.')) return;
    const r = await adminApi.deleteNode(id);
    if (r.success) { toast.success('Node deleted'); load(); }
    else toast.error(`Failed: ${friendlyMessage(r)}`);
  };

  const openEdit = (n: any) => {
    setEditForm({
      name: n.name, hostname: n.hostname, ipAddress: n.ipAddress, provider: n.provider,
      apiEndpoint: n.apiEndpoint || '', region: n.region || '', datacenter: n.datacenter || '',
      cpuCapacity: n.cpuCapacity, ramGb: n.ramCapacityMb / 1024, storageCapacityGb: n.storageCapacityGb,
      bandwidthMbps: n.bandwidthMbps,
    });
    setEditNode(n);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2">Nodes <Badge variant="outline" className="bg-rose-500/10 text-rose-300 border-rose-500/30">Admin</Badge></h2>
          <p className="text-xs text-zinc-500">Infrastructure compute nodes — graphs, console, and configuration</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={load} variant="outline" size="sm" className="border-zinc-800"><RefreshCw className="w-4 h-4" /></Button>
          <Button onClick={() => setOpen(true)} size="sm" className="bg-rose-600 hover:bg-rose-500 text-white"><Plus className="w-4 h-4" /> Add Node</Button>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-12"><Loader2 className="w-6 h-6 text-rose-400 animate-spin" /></div>
      ) : (
        <div className="grid lg:grid-cols-2 gap-4">
          {nodes.map((n: any) => (
            <Card key={n.id} className="glass-panel p-5">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-rose-500/10 border border-rose-500/30 flex items-center justify-center"><Server className="w-5 h-5 text-rose-400" /></div>
                  <div>
                    <p className="font-semibold">{n.name}</p>
                    <p className="text-xs text-zinc-500 flex items-center gap-1"><MapPin className="w-3 h-3" />{n.region} · {n.datacenter}</p>
                  </div>
                </div>
                <StatusBadge status={n.health} size="sm" />
              </div>

              <div className="grid grid-cols-3 gap-3 text-xs mt-3">
                <div className="p-2 rounded-md bg-zinc-900/60 border border-zinc-800">
                  <p className="text-zinc-500">CPU</p>
                  <p className="font-mono text-zinc-200">{n.usedCpu}/{n.cpuCapacity}</p>
                  <div className="mt-1 h-1 bg-zinc-900 rounded-full overflow-hidden">
                    <div className="h-full bg-rose-500" style={{ width: `${(n.usedCpu / n.cpuCapacity) * 100}%` }} />
                  </div>
                </div>
                <div className="p-2 rounded-md bg-zinc-900/60 border border-zinc-800">
                  <p className="text-zinc-500">RAM</p>
                  <p className="font-mono text-zinc-200">{(n.usedRamMb / 1024).toFixed(0)}/{(n.ramCapacityMb / 1024).toFixed(0)}G</p>
                  <div className="mt-1 h-1 bg-zinc-900 rounded-full overflow-hidden">
                    <div className="h-full bg-amber-500" style={{ width: `${(n.usedRamMb / n.ramCapacityMb) * 100}%` }} />
                  </div>
                </div>
                <div className="p-2 rounded-md bg-zinc-900/60 border border-zinc-800">
                  <p className="text-zinc-500">Disk</p>
                  <p className="font-mono text-zinc-200">{n.usedDiskGb}/{n.storageCapacityGb}G</p>
                  <div className="mt-1 h-1 bg-zinc-900 rounded-full overflow-hidden">
                    <div className="h-full bg-emerald-500" style={{ width: `${(n.usedDiskGb / n.storageCapacityGb) * 100}%` }} />
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between mt-3 pt-3 border-t border-zinc-800">
                <p className="text-xs text-zinc-500">VPS: {n.vpsCount} · {n.provider} · Last heartbeat: {n.lastHeartbeat ? new Date(n.lastHeartbeat).toLocaleString() : '—'}</p>
                <div className="flex gap-1">
                  <Button size="sm" variant="ghost" onClick={() => setDetailNode(n)} className="h-7 w-7 p-0 text-sky-400 hover:text-sky-300" title="Live graphs"><Activity className="w-3.5 h-3.5" /></Button>
                  <Button size="sm" variant="ghost" onClick={() => setConsoleNode(n)} className="h-7 w-7 p-0 text-rose-400 hover:text-rose-300" title="Node console"><Terminal className="w-3.5 h-3.5" /></Button>
                  <Button size="sm" variant="ghost" onClick={() => openEdit(n)} className="h-7 w-7 p-0 text-purple-400 hover:text-purple-300" title="Edit configuration"><Settings2 className="w-3.5 h-3.5" /></Button>
                  <Button size="sm" variant="ghost" onClick={() => toggle(n.id, 'maintenance', !n.maintenanceMode)} className="h-7 w-7 p-0 text-blue-400 hover:text-blue-300" title="Toggle maintenance"><Wrench className="w-3.5 h-3.5" /></Button>
                  <Button size="sm" variant="ghost" onClick={() => toggle(n.id, 'toggle_enabled', !n.enabled)} className={`h-7 w-7 p-0 ${n.enabled ? 'text-emerald-400 hover:text-emerald-300' : 'text-zinc-500'}`} title="Enable/disable"><Check className="w-3.5 h-3.5" /></Button>
                  <Button size="sm" variant="ghost" onClick={() => remove(n.id)} className="h-7 w-7 p-0 text-red-400 hover:text-red-300" title="Delete"><Trash2 className="w-3.5 h-3.5" /></Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* ===== Node detail with live graphs ===== */}
      <NodeDetailDialog node={detailNode} onClose={() => setDetailNode(null)} />

      {/* ===== Node console ===== */}
      {consoleNode && <NodeConsole node={consoleNode} onClose={() => setConsoleNode(null)} />}

      {/* ===== Node edit dialog ===== */}
      <Dialog open={!!editNode} onOpenChange={(o) => !o && setEditNode(null)}>
        <DialogContent className="bg-zinc-950 border-zinc-800 max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><Settings2 className="w-4 h-4 text-purple-400" /> Edit Node Configuration — {editNode?.name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-4 grid grid-cols-2 gap-3">
            <div><Label>Name</Label><Input value={editForm.name || ''} onChange={e => setEditForm({...editForm, name: e.target.value})} className="bg-zinc-950/50 border-zinc-800 font-mono" /></div>
            <div><Label>Hostname</Label><Input value={editForm.hostname || ''} onChange={e => setEditForm({...editForm, hostname: e.target.value})} className="bg-zinc-950/50 border-zinc-800 font-mono" /></div>
            <div><Label>IP Address</Label><Input value={editForm.ipAddress || ''} onChange={e => setEditForm({...editForm, ipAddress: e.target.value})} className="bg-zinc-950/50 border-zinc-800 font-mono" /></div>
            <div><Label>Provider</Label>
              <Select value={editForm.provider || 'PROXMOX'} onValueChange={v => setEditForm({...editForm, provider: v})}>
                <SelectTrigger className="bg-zinc-950/50 border-zinc-800"><SelectValue /></SelectTrigger>
                <SelectContent className="bg-zinc-950 border-zinc-800">
                  <SelectItem value="PROXMOX">Proxmox</SelectItem>
                  <SelectItem value="LXC">LXC (native containers)</SelectItem>
                  <SelectItem value="VMWARE">VMware</SelectItem>
                  <SelectItem value="HYPERV">Hyper-V</SelectItem>
                  <SelectItem value="LIBVIRT">libvirt</SelectItem>
                  <SelectItem value="CLOUD">Cloud</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="col-span-2"><Label>API Endpoint</Label><Input value={editForm.apiEndpoint || ''} onChange={e => setEditForm({...editForm, apiEndpoint: e.target.value})} placeholder={editForm.provider === 'LXC' ? 'root@lxc-host-ip:22 (SSH — runs lxc-create/start/stop)' : 'https://...:8006'} className="bg-zinc-950/50 border-zinc-800 font-mono text-xs" />
              {editForm.provider === 'LXC' && <p className="text-[11px] text-zinc-500 mt-1">LXC nodes connect over key-based SSH. Run scripts/setup-lxc-host.sh on the LXC VPS first, then enter user@host here.</p>}
            </div>
            <div><Label>Region</Label><Input value={editForm.region || ''} onChange={e => setEditForm({...editForm, region: e.target.value})} className="bg-zinc-950/50 border-zinc-800" /></div>
            <div><Label>Datacenter</Label><Input value={editForm.datacenter || ''} onChange={e => setEditForm({...editForm, datacenter: e.target.value})} className="bg-zinc-950/50 border-zinc-800" /></div>
            <div><Label>CPU Capacity (cores)</Label><Input type="number" value={editForm.cpuCapacity || 0} onChange={e => setEditForm({...editForm, cpuCapacity: +e.target.value})} className="bg-zinc-950/50 border-zinc-800" /></div>
            <div><Label>RAM Capacity (GB)</Label><Input type="number" min={1} step={1} value={editForm.ramGb || 0} onChange={e => setEditForm({...editForm, ramGb: +e.target.value})} className="bg-zinc-950/50 border-zinc-800" /></div>
            <div><Label>Storage Capacity (GB)</Label><Input type="number" value={editForm.storageCapacityGb || 0} onChange={e => setEditForm({...editForm, storageCapacityGb: +e.target.value})} className="bg-zinc-950/50 border-zinc-800" /></div>
            <div><Label>Bandwidth (Mbps)</Label><Input type="number" value={editForm.bandwidthMbps || 0} onChange={e => setEditForm({...editForm, bandwidthMbps: +e.target.value})} className="bg-zinc-950/50 border-zinc-800" /></div>
          </div>
          <div className="text-xs text-amber-300 bg-amber-500/10 border border-amber-500/20 p-3 rounded">
            Capacity changes take effect immediately. Reducing capacity below current usage will block new deployments on this node.
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditNode(null)} className="border-zinc-800">Cancel</Button>
            <Button onClick={saveEdit} disabled={saving} className="bg-rose-600 hover:bg-rose-500 text-white">
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />} Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ===== Create node dialog ===== */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="bg-zinc-950 border-zinc-800 max-w-2xl">
          <DialogHeader><DialogTitle>Add Infrastructure Node</DialogTitle></DialogHeader>
          <div className="space-y-3 py-4 grid grid-cols-2 gap-3">
            <div><Label>Name</Label><Input value={form.name} onChange={e => setForm({...form, name: e.target.value})} placeholder="in-mum-01" className="bg-zinc-950/50 border-zinc-800 font-mono" /></div>
            <div><Label>Hostname</Label><Input value={form.hostname} onChange={e => setForm({...form, hostname: e.target.value})} className="bg-zinc-950/50 border-zinc-800 font-mono" /></div>
            <div><Label>IP Address</Label><Input value={form.ipAddress} onChange={e => setForm({...form, ipAddress: e.target.value})} className="bg-zinc-950/50 border-zinc-800 font-mono" /></div>
            <div><Label>Provider</Label>
              <Select value={form.provider} onValueChange={v => setForm({...form, provider: v})}>
                <SelectTrigger className="bg-zinc-950/50 border-zinc-800"><SelectValue /></SelectTrigger>
                <SelectContent className="bg-zinc-950 border-zinc-800">
                  <SelectItem value="PROXMOX">Proxmox</SelectItem>
                  <SelectItem value="LXC">LXC (native containers)</SelectItem>
                  <SelectItem value="VMWARE">VMware</SelectItem>
                  <SelectItem value="HYPERV">Hyper-V</SelectItem>
                  <SelectItem value="LIBVIRT">libvirt</SelectItem>
                  <SelectItem value="CLOUD">Cloud</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="col-span-2"><Label>API Endpoint</Label><Input value={form.apiEndpoint} onChange={e => setForm({...form, apiEndpoint: e.target.value})} placeholder={form.provider === 'LXC' ? 'root@lxc-host-ip:22 (SSH — runs lxc-create/start/stop)' : 'https://...'} className="bg-zinc-950/50 border-zinc-800 font-mono text-xs" />
              {form.provider === 'LXC' && <p className="text-[11px] text-zinc-500 mt-1">LXC nodes connect over key-based SSH. Run scripts/setup-lxc-host.sh on the LXC VPS first, then enter user@host here.</p>}
            </div>
            <div><Label>Region</Label><Input value={form.region} onChange={e => setForm({...form, region: e.target.value})} placeholder="Mumbai" className="bg-zinc-950/50 border-zinc-800" /></div>
            <div><Label>Datacenter</Label><Input value={form.datacenter} onChange={e => setForm({...form, datacenter: e.target.value})} placeholder="Mumbai-DC1" className="bg-zinc-950/50 border-zinc-800" /></div>
            <div><Label>CPU Capacity (cores)</Label><Input type="number" value={form.cpuCapacity} onChange={e => setForm({...form, cpuCapacity: +e.target.value})} className="bg-zinc-950/50 border-zinc-800" /></div>
            <div><Label>RAM Capacity (GB)</Label><Input type="number" value={form.ramCapacityMb / 1024} onChange={e => setForm({...form, ramCapacityMb: Math.round(+e.target.value * 1024)})} className="bg-zinc-950/50 border-zinc-800" /></div>
            <div><Label>Storage Capacity (GB)</Label><Input type="number" value={form.storageCapacityGb} onChange={e => setForm({...form, storageCapacityGb: +e.target.value})} className="bg-zinc-950/50 border-zinc-800" /></div>
            <div><Label>Bandwidth (Mbps)</Label><Input type="number" value={form.bandwidthMbps} onChange={e => setForm({...form, bandwidthMbps: +e.target.value})} className="bg-zinc-950/50 border-zinc-800" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)} className="border-zinc-800">Cancel</Button>
            <Button onClick={submit} className="bg-rose-600 hover:bg-rose-500 text-white">Create Node</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ============================================================
// Node detail dialog — live graphs
// ============================================================
function NodeDetailDialog({ node, onClose }: { node: any; onClose: () => void }) {
  const history = useNodeMetrics(node, !!node);
  if (!node) return null;

  const ramUsed = (node.usedRamMb / 1024).toFixed(0);
  const ramTotal = (node.ramCapacityMb / 1024).toFixed(0);

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="bg-zinc-950 border-zinc-800 max-w-3xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-sky-400" /> {node.name} — Live Metrics
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-2">
          {/* Info strip */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
            <div className="p-2 rounded-md bg-zinc-900/60 border border-zinc-800">
              <p className="text-zinc-500">Host</p>
              <p className="font-mono text-zinc-200 truncate">{node.hostname}</p>
            </div>
            <div className="p-2 rounded-md bg-zinc-900/60 border border-zinc-800">
              <p className="text-zinc-500">Provider</p>
              <p className="text-zinc-200">{node.provider}</p>
            </div>
            <div className="p-2 rounded-md bg-zinc-900/60 border border-zinc-800">
              <p className="text-zinc-500">Allocated</p>
              <p className="font-mono text-zinc-200">{node.vpsCount} VPS</p>
            </div>
            <div className="p-2 rounded-md bg-zinc-900/60 border border-zinc-800">
              <p className="text-zinc-500">RAM</p>
              <p className="font-mono text-zinc-200">{ramUsed}/{ramTotal} GB</p>
            </div>
          </div>

          {/* Charts */}
          <div className="grid md:grid-cols-2 gap-3">
            <MetricChart data={history} dataKey="cpu" color="#f43f5e" label="CPU Load" unit="%" />
            <MetricChart data={history} dataKey="ram" color="#f59e0b" label="RAM Usage" unit="%" />
            <MetricChart data={history} dataKey="disk" color="#10b981" label="Disk Usage" unit="%" />
            <NetChart data={history} />
          </div>

          <p className="text-[10px] text-zinc-600 flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            Live telemetry updates every 3 seconds. Historical buffer: 40 points.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
