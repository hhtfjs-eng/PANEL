'use client';

import { useAppStore, isSuperUser, canProvision } from '@/lib/frontend/store';
import { User } from '@/lib/frontend/store';
import { cn } from '@/lib/utils';
import {
  LayoutDashboard, Users, HardDrive, Activity, Server, Package,
  MonitorSmartphone, Network, LifeBuoy, Bell, ScrollText, HeartPulse,
  Settings, UserCog, LogOut, Menu, X, ShieldCheck, IdCard,
  PanelLeftClose, PanelLeftOpen,
} from 'lucide-react';

interface NavItem {
  id: string;
  label: string;
  icon: any;
  minRole?: 'ADMIN' | 'STAFF';
}

const NAV: NavItem[] = [
  { id: 'admin-dashboard',  label: 'Overview',       icon: LayoutDashboard },
  { id: 'admin-profile',    label: 'Profile',        icon: IdCard },
  { id: 'admin-users',       label: 'Users',          icon: Users },
  { id: 'admin-vps',         label: 'VPS',            icon: HardDrive, minRole: 'STAFF' },
  { id: 'admin-deployments', label: 'Deployments',    icon: Activity, minRole: 'STAFF' },
  { id: 'admin-nodes',       label: 'Nodes',          icon: Server, minRole: 'STAFF' },
  { id: 'admin-plans',       label: 'Plans',          icon: Package, minRole: 'STAFF' },
  { id: 'admin-os',         label: 'OS Templates',   icon: MonitorSmartphone, minRole: 'STAFF' },
  { id: 'admin-ips',        label: 'IP Management',   icon: Network, minRole: 'STAFF' },
  { id: 'admin-support',    label: 'Support',         icon: LifeBuoy },
  { id: 'admin-notifications', label: 'Notifications',icon: Bell },
  { id: 'admin-audit',      label: 'Audit Logs',      icon: ScrollText, minRole: 'STAFF' },
  { id: 'admin-health',     label: 'System Health',   icon: HeartPulse, minRole: 'STAFF' },
  { id: 'admin-settings',   label: 'Settings',        icon: Settings, minRole: 'ADMIN' },
  { id: 'admin-staff',      label: 'Staff',           icon: UserCog, minRole: 'ADMIN' },
  { id: 'admin-roles',      label: 'Role Editor',     icon: ShieldCheck, minRole: 'ADMIN' },
];

export function AdminShell({ user, children }: { user: User; children: React.ReactNode }) {
  const { view, setView, sidebarOpen, setSidebarOpen, sidebarCollapsed, toggleSidebarCollapsed, logout, brand } = useAppStore();
  const isProvisioner = canProvision(user);

  const items = NAV.filter(item => {
    if (!item.minRole) return true;
    if (item.minRole === 'STAFF') return isProvisioner;
    if (item.minRole === 'ADMIN') return isSuperUser(user);
    return true;
  });

  return (
    <div className="min-h-screen relative flex">
      {/* Owner-supplied wallpaper as the post-login background, dimmed so
          content remains readable. Fixed so it doesn't scroll with content. */}
      <div
        aria-hidden="true"
        className="fixed inset-0 z-0 bg-cover bg-center bg-no-repeat pointer-events-none"
        style={{ backgroundImage: 'url(/login-wallpaper.png)' }}
      />
      <div className="fixed inset-0 z-0 bg-gradient-to-br from-black/85 via-zinc-950/80 to-black/90 pointer-events-none" />
      <div className="fixed inset-0 z-0 bg-gradient-to-t from-rose-950/20 via-transparent to-rose-950/10 pointer-events-none" />

      {/* Sidebar — fixed to the viewport so it stays visible while the
          main content scrolls. Full viewport height (h-screen) so it is
          never cropped. Transparent glass (backdrop-blur) lets the owner
          wallpaper show through. On mobile it slides fully off-screen
          (-translate-x-full) until the hamburger opens it. */}
      <aside
        className={cn(
          'fixed top-0 left-0 z-40 flex flex-col h-screen',
          // Transparent sidebar: blurred dark glass so the wallpaper shows
          'bg-zinc-950/40 backdrop-blur-xl border-r border-white/5',
          // Width + transition — smooth slide-in/out animation when
          // collapsing to the rail and back. On mobile it slides fully off.
          'transition-[width,transform] duration-300 ease-in-out',
          sidebarCollapsed ? 'w-16' : 'w-64',
          sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0',
        )}
      >
        <div className={cn(
          'h-16 flex items-center border-b border-white/5',
          sidebarCollapsed ? 'justify-center px-2' : 'px-6',
        )}>
          {sidebarCollapsed ? (
            <div className="w-9 h-9 rounded-md bg-gradient-to-br from-rose-600 to-red-800 flex items-center justify-center glow-red shrink-0" title={brand}>
              <Server className="w-4 h-4 text-white" />
            </div>
          ) : (
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-9 h-9 rounded-md bg-gradient-to-br from-rose-600 to-red-800 flex items-center justify-center glow-red shrink-0">
                <Server className="w-4 h-4 text-white" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-bold tracking-tight truncate">{brand}</p>
                <p className="text-[10px] text-rose-400 -mt-0.5 uppercase tracking-wider font-medium">Admin Console</p>
              </div>
              <span className="hidden xl:inline-flex shrink-0 px-1.5 py-0.5 text-[9px] uppercase tracking-wider bg-rose-500/15 text-rose-300 border border-rose-500/30 rounded">
                {user.role}
              </span>
            </div>
          )}
          <button onClick={() => setSidebarOpen(false)} className="lg:hidden ml-auto text-zinc-400 hover:text-white shrink-0" aria-label="Close sidebar">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Owner watermark moved to the dashboard head area (above
            Infrastructure Overview) per owner request — no longer in the
            sidebar. */}

        <nav className={cn(
          'flex-1 p-2 space-y-0.5 overflow-y-auto',
          sidebarCollapsed && 'px-1',
        )}>
          {items.map(item => (
            <button
              key={item.id}
              onClick={() => setView(item.id)}
              title={sidebarCollapsed ? item.label : undefined}
              className={cn(
                'w-full flex items-center rounded-md text-sm transition-colors',
                sidebarCollapsed ? 'justify-center px-1 py-2.5' : 'gap-3 px-3 py-2',
                view === item.id
                  ? 'bg-rose-500/15 text-rose-200 border border-rose-500/40 glow-red-sm backdrop-blur-sm'
                  : 'text-zinc-300 hover:text-white hover:bg-white/5 border border-transparent',
              )}
            >
              <item.icon className="w-4 h-4 shrink-0" />
              {!sidebarCollapsed && <span className="flex-1 text-left truncate">{item.label}</span>}
            </button>
          ))}
        </nav>

        <div className="border-t border-white/5 p-2">
          {!sidebarCollapsed && (
            <button onClick={() => setView('admin-profile')} className="flex items-center gap-2 px-2 py-2 rounded-md bg-white/5 hover:bg-white/10 backdrop-blur-sm transition-colors w-full text-left mb-1" title="Open Profile">
              <div className="w-8 h-8 rounded-full bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-200 text-xs font-bold uppercase shrink-0">
                {user.name.charAt(0)}
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-zinc-100 truncate">{user.name}</p>
                <p className="text-xs text-rose-400 truncate uppercase">{user.role}</p>
              </div>
            </button>
          )}
          {sidebarCollapsed && (
            <button onClick={() => setView('admin-profile')} className="flex items-center justify-center px-1 py-2 rounded-md bg-white/5 hover:bg-white/10 backdrop-blur-sm transition-colors w-full mb-1" title={`${user.name} · ${user.role}`}>
              <div className="w-8 h-8 rounded-full bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-200 text-xs font-bold uppercase shrink-0">
                {user.name.charAt(0)}
              </div>
            </button>
          )}
          <button onClick={logout} title="Sign out" className={cn(
            'w-full flex items-center rounded-md text-xs text-zinc-400 hover:text-rose-300 hover:bg-white/5 transition-colors',
            sidebarCollapsed ? 'justify-center px-1 py-2' : 'justify-center gap-2 px-2 py-1.5',
          )}>
            <LogOut className="w-3.5 h-3.5" /> {!sidebarCollapsed && 'Sign out'}
          </button>
        </div>
      </aside>

      {sidebarOpen && (
        <div className="fixed inset-0 z-30 bg-black/70 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Content area — offset on desktop by the sidebar width (which is
          fixed and out of flow). On mobile the sidebar is off-screen so
          no offset is needed. The transition matches the sidebar's width
          transition so they stay in sync when collapsing/expanding. */}
      <div className={cn(
        'flex-1 flex flex-col min-w-0 relative z-10',
        'transition-[margin] duration-300 ease-in-out',
        sidebarCollapsed ? 'lg:ml-16' : 'lg:ml-64',
      )}>
        <header className="h-14 lg:h-16 sticky top-0 z-20 bg-zinc-950/60 backdrop-blur-xl border-b border-white/5 flex items-center px-3 lg:px-6 gap-2">
          <button onClick={() => setSidebarOpen(true)} className="lg:hidden text-zinc-300 hover:text-white" aria-label="Open sidebar">
            <Menu className="w-5 h-5" />
          </button>
          {/* Collapse toggle — only on desktop, slides the sidebar in/out */}
          <button
            onClick={toggleSidebarCollapsed}
            className="hidden lg:inline-flex items-center justify-center w-8 h-8 rounded-md text-zinc-400 hover:text-rose-300 hover:bg-white/5 transition-colors"
            title={sidebarCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          >
            {sidebarCollapsed ? <PanelLeftOpen className="w-4 h-4" /> : <PanelLeftClose className="w-4 h-4" />}
          </button>
          <div className="flex-1 min-w-0">
            <h1 className="text-sm lg:text-base font-semibold capitalize truncate">
              {items.find(n => n.id === view)?.label || 'Dashboard'}
            </h1>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <span className="px-2 py-0.5 text-[10px] uppercase tracking-wider bg-rose-500/15 text-rose-300 border border-rose-500/30 rounded">
              Admin Console
            </span>
            <span className="hidden md:inline-flex px-2 py-0.5 text-[10px] uppercase tracking-wider bg-white/5 text-zinc-400 border border-white/10 rounded">
              {user.role}
            </span>
          </div>
        </header>
        <main className="flex-1 p-3 sm:p-4 lg:p-6 max-w-7xl mx-auto w-full">
          {/* Keyed by view so every navigation replays the entrance animation */}
          <div key={view} className="view-enter">{children}</div>
        </main>
      </div>
    </div>
  );
}
