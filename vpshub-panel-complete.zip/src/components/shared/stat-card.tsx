'use client';

import { Card } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { LucideIcon } from 'lucide-react';

export interface StatCardProps {
  label: string;
  value: number | string;
  icon: LucideIcon;
  hint?: string;
  tone?: 'default' | 'red' | 'emerald' | 'amber' | 'blue';
  className?: string;
}

const TONES: Record<string, string> = {
  default: 'text-zinc-400',
  red: 'text-rose-400',
  emerald: 'text-emerald-400',
  amber: 'text-amber-400',
  blue: 'text-sky-400',
};

const ICON_BG: Record<string, string> = {
  default: 'bg-zinc-500/10 text-zinc-300 border-zinc-500/20',
  red: 'bg-rose-500/10 text-rose-300 border-rose-500/30',
  emerald: 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30',
  amber: 'bg-amber-500/10 text-amber-300 border-amber-500/30',
  blue: 'bg-sky-500/10 text-sky-300 border-sky-500/30',
};

export function StatCard({ label, value, icon: Icon, hint, tone = 'default', className }: StatCardProps) {
  return (
    <Card className={cn('glass-panel relative p-4 overflow-hidden hover-lift', className)}>
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <p className="text-xs uppercase tracking-wider text-zinc-500 font-medium">{label}</p>
          <p className="text-2xl font-bold text-zinc-100 mt-1 font-mono tabular-nums truncate">{value}</p>
          {hint && <p className={cn('text-xs mt-1', TONES[tone])}>{hint}</p>}
        </div>
        <div className={cn('flex items-center justify-center w-10 h-10 rounded-lg border shrink-0', ICON_BG[tone])}>
          <Icon className="w-4 h-4" />
        </div>
      </div>
      <div className="absolute -bottom-8 -right-8 w-24 h-24 rounded-full bg-rose-500/5 blur-2xl pointer-events-none" />
    </Card>
  );
}
