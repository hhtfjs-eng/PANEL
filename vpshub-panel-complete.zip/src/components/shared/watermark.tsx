'use client';

// ============================================================
// Watermark — fixed, non-interactive owner watermark rendered
// on every page (login, admin console, customer panel).
// Text comes from Settings → Branding & Links (site.watermark_text,
// default "YT"). Clearing the text hides the watermark.
// ============================================================

import { useAppStore } from '@/lib/frontend/store';

export function Watermark() {
  const watermarkText = useAppStore(s => s.branding.watermarkText);
  if (!watermarkText) return null;

  return (
    <div
      aria-hidden="true"
      className="fixed bottom-3 right-5 z-40 pointer-events-none select-none"
    >
      <span className="text-5xl font-black italic tracking-tighter text-rose-500/15 drop-shadow-[0_0_12px_rgba(244,63,94,0.15)]">
        {watermarkText}
      </span>
    </div>
  );
}
