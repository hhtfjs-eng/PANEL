'use client';

// ============================================================
// BrandBar — owner identity row: "YT Owner" (YouTube channel)
// and "Discord Server" link buttons + "Developer" credit button.
// Fully driven by Settings → Branding & Links (site.youtube_url,
// site.discord_url, site.owner_credit, site.made_by_url). Buttons
// whose URL is cleared in settings simply hide.
// ============================================================

import { useAppStore } from '@/lib/frontend/store';
import { Youtube, Code2 } from 'lucide-react';
import { cn } from '@/lib/utils';

function DiscordIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
      <path d="M20.317 4.37a19.79 19.79 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.058a.082.082 0 0 0 .031.056 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994a.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128c.126-.094.252-.192.372-.291a.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.009c.12.099.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03ZM8.02 15.331c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418Zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418Z"/>
    </svg>
  );
}

export function BrandBar({ className }: { className?: string }) {
  const branding = useAppStore(s => s.branding);

  // The owner-credit (default "Made by YT") is now rendered as a "Developer"
  // button — a Code2 icon + the credit text. Wrapped in an <a> when
  // madeByUrl is set, so clicking opens the owner's developer channel
  // (default: https://www.youtube.com/@DevAVoid).
  const developerBtn = branding.ownerCredit ? (
    branding.madeByUrl ? (
      <a
        href={branding.madeByUrl}
        target="_blank"
        rel="noopener noreferrer"
        title="Developer channel"
        className="w-full inline-flex items-center justify-center gap-2 px-3 py-2 rounded-md text-xs font-semibold border border-rose-500/30 bg-rose-500/10 text-rose-200 hover:bg-rose-500/20 hover:border-rose-500/50 transition-colors backdrop-blur-sm"
      >
        <Code2 className="w-4 h-4 shrink-0" />
        <span>Developer</span>
      </a>
    ) : (
      <div className="w-full inline-flex items-center justify-center gap-2 px-3 py-2 rounded-md text-xs font-semibold border border-zinc-700 bg-zinc-900/60 text-zinc-400">
        <Code2 className="w-4 h-4 shrink-0" />
        <span>Developer</span>
      </div>
    )
  ) : null;

  return (
    <div className={cn('space-y-2', className)}>
      {(branding.youtubeUrl || branding.discordUrl) && (
        // On phones, stack the YT/Discord buttons vertically (grid-cols-1);
        // on larger screens show them side by side (sm:grid-cols-2).
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {branding.youtubeUrl && (
            <a
              href={branding.youtubeUrl}
              target="_blank"
              rel="noopener noreferrer"
              title="YT Owner — YouTube channel"
              className="inline-flex items-center justify-center gap-2 px-3 py-2 rounded-md text-xs font-semibold border border-red-500/30 bg-red-500/10 text-red-300 hover:bg-red-500/20 hover:border-red-500/50 transition-colors backdrop-blur-sm"
            >
              <Youtube className="w-4 h-4 shrink-0" /> YT Owner
            </a>
          )}
          {branding.discordUrl && (
            <a
              href={branding.discordUrl}
              target="_blank"
              rel="noopener noreferrer"
              title="Discord Server"
              className="inline-flex items-center justify-center gap-2 px-3 py-2 rounded-md text-xs font-semibold border border-indigo-500/30 bg-indigo-500/10 text-indigo-300 hover:bg-indigo-500/20 hover:border-indigo-500/50 transition-colors backdrop-blur-sm"
            >
              <DiscordIcon className="w-4 h-4 shrink-0" /> Discord Server
            </a>
          )}
        </div>
      )}
      {developerBtn}
    </div>
  );
}
