'use client';

import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

const STATUS_CONFIG: Record<string, { label: string; color: string; dot: string }> = {
  // VPS statuses
  PENDING:        { label: 'Pending',        color: 'bg-amber-500/15 text-amber-300 border-amber-500/30', dot: 'bg-amber-400' },
  QUEUED:         { label: 'Queued',         color: 'bg-slate-500/15 text-slate-300 border-slate-500/30', dot: 'bg-slate-400' },
  PROVISIONING:   { label: 'Provisioning',    color: 'bg-blue-500/15 text-blue-300 border-blue-500/30', dot: 'bg-blue-400 animate-pulse' },
  RUNNING:        { label: 'Running',         color: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30', dot: 'bg-emerald-400' },
  STOPPED:        { label: 'Stopped',         color: 'bg-zinc-500/15 text-zinc-300 border-zinc-500/30', dot: 'bg-zinc-400' },
  REBOOTING:      { label: 'Rebooting',       color: 'bg-blue-500/15 text-blue-300 border-blue-500/30', dot: 'bg-blue-400 animate-pulse' },
  REINSTALLING:   { label: 'Reinstalling',    color: 'bg-orange-500/15 text-orange-300 border-orange-500/30', dot: 'bg-orange-400 animate-pulse' },
  SUSPENDED:      { label: 'Suspended',       color: 'bg-red-500/15 text-red-300 border-red-500/30', dot: 'bg-red-400' },
  ERROR:          { label: 'Error',           color: 'bg-red-500/20 text-red-200 border-red-500/40', dot: 'bg-red-500' },
  DELETING:       { label: 'Deleting',        color: 'bg-orange-500/15 text-orange-300 border-orange-500/30', dot: 'bg-orange-400 animate-pulse' },
  DELETED:        { label: 'Deleted',         color: 'bg-zinc-700/15 text-zinc-500 border-zinc-700/30', dot: 'bg-zinc-600' },

  // Node health
  ONLINE:     { label: 'Online',     color: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30', dot: 'bg-emerald-400' },
  DEGRADED:   { label: 'Degraded',   color: 'bg-amber-500/15 text-amber-300 border-amber-500/30', dot: 'bg-amber-400' },
  OFFLINE:    { label: 'Offline',    color: 'bg-red-500/15 text-red-300 border-red-500/30', dot: 'bg-red-500' },
  MAINTENANCE:{ label: 'Maintenance',color: 'bg-blue-500/15 text-blue-300 border-blue-500/30', dot: 'bg-blue-400' },

  // User status
  ACTIVE:     { label: 'Active',     color: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30', dot: 'bg-emerald-400' },
  PENDING_USER: { label: 'Pending', color: 'bg-amber-500/15 text-amber-300 border-amber-500/30', dot: 'bg-amber-400' },

  // Deployment states
  COMPLETED:  { label: 'Completed',  color: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30', dot: 'bg-emerald-400' },
  FAILED:     { label: 'Failed',     color: 'bg-red-500/15 text-red-300 border-red-500/30', dot: 'bg-red-500' },
  CANCELLED:  { label: 'Cancelled', color: 'bg-zinc-500/15 text-zinc-400 border-zinc-500/30', dot: 'bg-zinc-500' },

  // IP states
  AVAILABLE:  { label: 'Available',  color: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30', dot: 'bg-emerald-400' },
  ASSIGNED:   { label: 'Assigned',   color: 'bg-blue-500/15 text-blue-300 border-blue-500/30', dot: 'bg-blue-400' },
  RESERVED:   { label: 'Reserved',   color: 'bg-amber-500/15 text-amber-300 border-amber-500/30', dot: 'bg-amber-400' },
  BLOCKED:    { label: 'Blocked',    color: 'bg-red-500/15 text-red-300 border-red-500/30', dot: 'bg-red-500' },
};

export function StatusBadge({ status, size = 'default' }: { status: string; size?: 'sm' | 'default' }) {
  const cfg = STATUS_CONFIG[status] || { label: status, color: 'bg-zinc-500/15 text-zinc-300 border-zinc-500/30', dot: 'bg-zinc-400' };
  return (
    <Badge variant="outline" className={cn('inline-flex items-center gap-1.5 font-medium', cfg.color, size === 'sm' && 'text-xs px-2 py-0.5')}>
      <span className={cn('inline-block w-1.5 h-1.5 rounded-full', cfg.dot)} />
      {cfg.label}
    </Badge>
  );
}
