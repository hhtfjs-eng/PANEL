'use client';

// Shared Profile page — works for customers AND admins.
//  • Everyone can edit their own profile (name / username / email / password)
//  • Users holding users.edit can also switch to any other account and edit
//    ALL of its fields (role incl. custom roles, status, password reset,
//    email verification) — the "edit others" panel.

import { useEffect, useState } from 'react';
import { useAppStore, userCan } from '@/lib/frontend/store';
import { api, authApi, adminApi, friendlyMessage } from '@/lib/frontend/api';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { toast } from 'sonner';
import {
  Loader2, IdCard, Save, KeyRound, Users, ShieldCheck, MailCheck,
  LockKeyhole, Search,
} from 'lucide-react';

interface ProfileData {
  id: string; name: string; username: string; email: string;
  role: string; status: string; emailVerified: boolean;
  lastLogin?: string | null; createdAt?: string | null;
}

export function ProfilePage() {
  const { user, refreshUser } = useAppStore();
  const canEditOthers = userCan(user, 'users.edit');
  const canResetPasswords = userCan(user, 'users.reset_password');

  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  // password change
  const [pw, setPw] = useState({ current: '', next: '', confirm: '' });

  // "edit another user" state
  const [others, setOthers] = useState<any[]>([]);
  const [otherSearch, setOtherSearch] = useState('');
  const [selectedOther, setSelectedOther] = useState<ProfileData | null>(null);
  const [roles, setRoles] = useState<any[]>([]);
  const [savingOther, setSavingOther] = useState(false);

  const loadSelf = async () => {
    setLoading(true);
    const r = await authApi.profile();
    if (r.success && r.data) setProfile(r.data);
    setLoading(false);
  };
  useEffect(() => { loadSelf(); }, []);

  // Load users list + roles once when the admin panel is opened
  useEffect(() => {
    if (!canEditOthers) return;
    adminApi.users({ pageSize: 200 }).then(r => { if (r.success && r.data) setOthers(r.data); });
    adminApi.roles().then(r => { if (r.success && r.data) setRoles(r.data); });
  }, [canEditOthers]);

  const saveSelf = async () => {
    if (!profile) return;
    if (!profile.name.trim()) { toast.error('Name is required'); return; }
    setSaving(true);
    const r = await authApi.updateProfile({
      name: profile.name.trim(),
      username: profile.username.trim(),
      email: profile.email.trim(),
    });
    setSaving(false);
    if (r.success) {
      toast.success('Profile saved');
      if ((r as any).user) await refreshUser();
      loadSelf();
    } else {
      toast.error(friendlyMessage(r));
    }
  };

  const changePassword = async () => {
    if (!pw.next) { toast.error('Enter a new password'); return; }
    if (pw.next.length < 8) { toast.error('New password must be at least 8 characters'); return; }
    if (pw.next !== pw.confirm) { toast.error('New passwords do not match'); return; }
    setSaving(true);
    const r = await authApi.updateProfile({ currentPassword: pw.current, newPassword: pw.next });
    setSaving(false);
    if (r.success) {
      toast.success('Password changed');
      setPw({ current: '', next: '', confirm: '' });
    } else {
      toast.error(friendlyMessage(r));
    }
  };

  const pickOther = async (id: string) => {
    const r = await api.get(`/api/admin/users/${id}`);
    if (r.success && r.data) setSelectedOther(r.data);
    else toast.error(friendlyMessage(r));
  };

  const saveOther = async () => {
    if (!selectedOther) return;
    setSavingOther(true);
    const patch: any = {
      name: selectedOther.name.trim(),
      username: selectedOther.username.trim(),
      email: selectedOther.email.trim(),
      role: selectedOther.role,
      status: selectedOther.status,
    };
    const r = await adminApi.updateUser(selectedOther.id, patch);
    if (r.success) {
      // optional password reset in the same panel
      if ((selectedOther as any).newPassword) {
        const pr = await adminApi.userAction(selectedOther.id, 'reset_password', { password: (selectedOther as any).newPassword });
        if (!pr.success) toast.error(`Password reset failed: ${friendlyMessage(pr)}`);
      }
      toast.success('User updated');
      setSelectedOther({ ...selectedOther, newPassword: '' } as any);
    } else {
      toast.error(friendlyMessage(r));
    }
    setSavingOther(false);
  };

  const filteredOthers = otherSearch
    ? others.filter((u: any) =>
        `${u.name} ${u.username} ${u.email}`.toLowerCase().includes(otherSearch.toLowerCase()))
    : others;

  if (loading) {
    return <div className="flex justify-center py-12"><Loader2 className="w-6 h-6 text-rose-400 animate-spin" /></div>;
  }

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-lg font-semibold flex items-center gap-2">
          <IdCard className="w-5 h-5 text-rose-400" /> Profile
        </h2>
        <p className="text-xs text-zinc-500">Your account details and security</p>
      </div>

      {/* ── Own profile ───────────────────────────────────────── */}
      <div className="grid lg:grid-cols-3 gap-4">
        {/* Identity card */}
        <Card className="glass-panel p-5 flex flex-col items-center text-center">
          <div className="w-20 h-20 rounded-full bg-gradient-to-br from-rose-600 to-red-800 border border-rose-500/40 flex items-center justify-center text-3xl font-bold text-white glow-red">
            {profile?.name?.charAt(0).toUpperCase() || '?'}
          </div>
          <p className="mt-3 font-semibold">{profile?.name}</p>
          <p className="text-xs text-zinc-500 font-mono">@{profile?.username}</p>
          <div className="flex items-center gap-1.5 mt-2 flex-wrap justify-center">
            <Badge variant="outline" className="bg-rose-500/10 text-rose-300 border-rose-500/30 uppercase">{profile?.role}</Badge>
            {profile?.emailVerified
              ? <Badge variant="outline" className="bg-emerald-500/10 text-emerald-300 border-emerald-500/30"><MailCheck className="w-3 h-3 mr-1" />Verified</Badge>
              : <Badge variant="outline" className="bg-amber-500/10 text-amber-300 border-amber-500/30">Unverified</Badge>}
          </div>
          <p className="text-[11px] text-zinc-600 mt-3">
            {profile?.lastLogin ? `Last login ${new Date(profile.lastLogin).toLocaleString()}` : 'Never logged in'}
          </p>
          <p className="text-[11px] text-zinc-600">
            {profile?.createdAt ? `Member since ${new Date(profile.createdAt).toLocaleDateString()}` : ''}
          </p>
        </Card>

        {/* Edit details */}
        <Card className="glass-panel p-5 lg:col-span-2">
          <h3 className="text-sm font-semibold uppercase tracking-wider text-zinc-500 mb-4 flex items-center gap-2">
            <IdCard className="w-3.5 h-3.5" /> Account Details
          </h3>
          <div className="space-y-3">
            <div><Label>Full Name</Label>
              <Input value={profile?.name || ''} onChange={e => setProfile(p => p ? { ...p, name: e.target.value } : p)} className="bg-zinc-950/50 border-zinc-800" /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Username</Label>
                <Input value={profile?.username || ''} onChange={e => setProfile(p => p ? { ...p, username: e.target.value } : p)} className="bg-zinc-950/50 border-zinc-800 font-mono" /></div>
              <div><Label>Email</Label>
                <Input type="text" inputMode="email" value={profile?.email || ''} onChange={e => setProfile(p => p ? { ...p, email: e.target.value } : p)} className="bg-zinc-950/50 border-zinc-800" /></div>
            </div>
            <p className="text-[11px] text-zinc-600">Changing your email will require re-verification.</p>
            <Button onClick={saveSelf} disabled={saving} className="bg-rose-600 hover:bg-rose-500 text-white">
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />} Save Changes
            </Button>
          </div>
        </Card>

        {/* Password change */}
        <Card className="glass-panel p-5 lg:col-span-3">
          <h3 className="text-sm font-semibold uppercase tracking-wider text-zinc-500 mb-4 flex items-center gap-2">
            <KeyRound className="w-3.5 h-3.5" /> Change Password
          </h3>
          <div className="grid md:grid-cols-3 gap-3">
            <div><Label>Current Password</Label>
              <Input type="password" value={pw.current} onChange={e => setPw({ ...pw, current: e.target.value })} className="bg-zinc-950/50 border-zinc-800" /></div>
            <div><Label>New Password</Label>
              <Input type="password" value={pw.next} onChange={e => setPw({ ...pw, next: e.target.value })} className="bg-zinc-950/50 border-zinc-800" /></div>
            <div><Label>Confirm New Password</Label>
              <Input type="password" value={pw.confirm} onChange={e => setPw({ ...pw, confirm: e.target.value })} className="bg-zinc-950/50 border-zinc-800" /></div>
          </div>
          <Button onClick={changePassword} disabled={saving} className="mt-3 bg-rose-600 hover:bg-rose-500 text-white">
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <LockKeyhole className="w-4 h-4" />} Update Password
          </Button>
        </Card>
      </div>

      {/* ── Edit another user (admin) ─────────────────────────── */}
      {canEditOthers && (
        <Card className="glass-panel p-5">
          <h3 className="text-sm font-semibold uppercase tracking-wider text-zinc-500 mb-1 flex items-center gap-2">
            <Users className="w-3.5 h-3.5" /> Edit Another User
          </h3>
          <p className="text-xs text-zinc-600 mb-4">Full field editing — role changes are audited.</p>

          <div className="flex items-center gap-2 mb-3">
            <div className="relative flex-1 max-w-sm">
              <Search className="w-4 h-4 text-zinc-600 absolute left-3 top-1/2 -translate-y-1/2" />
              <Input value={otherSearch} onChange={e => setOtherSearch(e.target.value)}
                placeholder="Search name, username, email…" className="bg-zinc-950/50 border-zinc-800 pl-9" />
            </div>
          </div>

          <div className="grid lg:grid-cols-3 gap-4">
            {/* User list */}
            <div className="max-h-80 overflow-y-auto space-y-1 pr-1">
              {filteredOthers.map((u: any) => (
                <button key={u.id} onClick={() => pickOther(u.id)}
                  className={`w-full text-left p-2.5 rounded-md border transition-colors ${selectedOther?.id === u.id ? 'bg-rose-500/10 border-rose-500/40' : 'bg-zinc-900/40 border-zinc-800 hover:border-zinc-700'}`}>
                  <p className="text-sm font-medium truncate">{u.name} <span className="text-zinc-600 font-normal">@{u.username}</span></p>
                  <p className="text-xs text-zinc-500 truncate">{u.email}</p>
                  <p className="text-[10px] text-rose-400/80 uppercase mt-0.5">{u.role} · {u.status}</p>
                </button>
              ))}
              {filteredOthers.length === 0 && <p className="text-xs text-zinc-600 py-4 text-center">No users match.</p>}
            </div>

            {/* Editor */}
            <div className="lg:col-span-2">
              {selectedOther ? (
                <div className="space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    <div><Label>Name</Label>
                      <Input value={selectedOther.name} onChange={e => setSelectedOther(o => o ? { ...o, name: e.target.value } : o)} className="bg-zinc-950/50 border-zinc-800" /></div>
                    <div><Label>Username</Label>
                      <Input value={selectedOther.username} onChange={e => setSelectedOther(o => o ? { ...o, username: e.target.value } : o)} className="bg-zinc-950/50 border-zinc-800 font-mono" /></div>
                    <div><Label>Email</Label>
                      <Input type="text" inputMode="email" value={selectedOther.email} onChange={e => setSelectedOther(o => o ? { ...o, email: e.target.value } : o)} className="bg-zinc-950/50 border-zinc-800" /></div>
                    <div><Label>Role</Label>
                      <Select value={selectedOther.role} onValueChange={v => setSelectedOther(o => o ? { ...o, role: v } : o)}>
                        <SelectTrigger className="bg-zinc-950/50 border-zinc-800"><SelectValue /></SelectTrigger>
                        <SelectContent className="bg-zinc-950 border-zinc-800">
                          {(roles.length ? roles : [
                            { key: 'USER', name: 'User' }, { key: 'SUPPORT', name: 'Support' },
                            { key: 'STAFF', name: 'Staff' }, { key: 'ADMIN', name: 'Admin' },
                            { key: 'SUPER_ADMIN', name: 'Super Admin' },
                          ]).map((r: any) => (
                            <SelectItem key={r.key} value={r.key}>
                              {r.name}{r.isSystem ? '' : ' (custom)'}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select></div>
                    <div><Label>Status</Label>
                      <Select value={selectedOther.status} onValueChange={v => setSelectedOther(o => o ? { ...o, status: v } : o)}>
                        <SelectTrigger className="bg-zinc-950/50 border-zinc-800"><SelectValue /></SelectTrigger>
                        <SelectContent className="bg-zinc-950 border-zinc-800">
                          <SelectItem value="ACTIVE">ACTIVE</SelectItem>
                          <SelectItem value="SUSPENDED">SUSPENDED</SelectItem>
                          <SelectItem value="PENDING">PENDING</SelectItem>
                        </SelectContent>
                      </Select></div>
                    {canResetPasswords && (
                      <div><Label>Set New Password (optional)</Label>
                        <Input type="password" value={(selectedOther as any).newPassword || ''} onChange={e => setSelectedOther(o => ({ ...(o as any), newPassword: e.target.value }))} placeholder="min 8 chars" className="bg-zinc-950/50 border-zinc-800" /></div>
                    )}
                  </div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <Button onClick={saveOther} disabled={savingOther} className="bg-rose-600 hover:bg-rose-500 text-white">
                      {savingOther ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />} Save User
                    </Button>
                    {!selectedOther.emailVerified && (
                      <Button variant="outline" size="sm"
                        onClick={async () => {
                          const r = await adminApi.userAction(selectedOther.id, 'verify');
                          if (r.success) { toast.success('Email verified'); setSelectedOther({ ...selectedOther, emailVerified: true }); }
                          else toast.error(friendlyMessage(r));
                        }}
                        className="border-emerald-500/40 text-emerald-300 hover:bg-emerald-500/10">
                        <MailCheck className="w-4 h-4" /> Mark Email Verified
                      </Button>
                    )}
                  </div>
                </div>
              ) : (
                <div className="h-full flex flex-col items-center justify-center py-12 text-zinc-600">
                  <ShieldCheck className="w-10 h-10 mb-2 opacity-40" />
                  <p className="text-sm">Select a user to edit every field</p>
                </div>
              )}
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}
