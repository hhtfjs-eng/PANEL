'use client';

// ============================================================
// Port Forwarding — shared tab used by BOTH the customer VPS
// detail and the admin VPS detail. Talks to whichever API base
// is passed in. Limit: 5 active forwards per person (enforced
// server-side; the badge here just mirrors it).
// ============================================================

import { useEffect, useState, useCallback } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  ArrowRightLeft, Plus, Loader2, Trash2, ArrowRight, Network, Info,
} from 'lucide-react';
import { toast } from 'sonner';

type ApiFn = {
  list: (id: string) => Promise<any>;
  add: (id: string, data: any) => Promise<any>;
  remove: (id: string, forwardId: string) => Promise<any>;
};

export function VpsPortForwards({
  vpsId, vpsStatus, api, disabled = false,
}: {
  vpsId: string;
  vpsStatus?: string;
  api: ApiFn;
  disabled?: boolean; // suspended / provisioning etc.
}) {
  const [data, setData] = useState<any>(null); // { forwards, nodeIp, limit, used, remaining }
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [form, setForm] = useState({ protocol: 'tcp', externalPort: '', internalPort: '', label: '' });

  const load = useCallback(async () => {
    const r = await api.list(vpsId);
    if (r.success && r.data) setData(r.data);
    setLoading(false);
  }, [vpsId]);

  useEffect(() => { load(); }, [load]);

  const isSuspended = vpsStatus === 'SUSPENDED';
  const canAdd = !disabled && !isSuspended && vpsStatus !== 'PROVISIONING'
    && (data ? data.remaining > 0 : true);

  const submit = async () => {
    const internalPort = parseInt(form.internalPort, 10);
    if (!internalPort || internalPort < 1 || internalPort > 65535) {
      toast.error('Internal port must be 1-65535');
      return;
    }
    setBusy(true);
    const ext = form.externalPort.trim();
    const r = await api.add(vpsId, {
      protocol: form.protocol,
      internalPort,
      externalPort: ext === '' ? undefined : parseInt(ext, 10),
      label: form.label.trim() || undefined,
    });
    setBusy(false);
    if (r.success) {
      toast.success(`Forward added — ${r.data.externalPort}/${r.data.protocol} → :${r.data.internalPort}`);
      setOpen(false);
      setForm({ protocol: 'tcp', externalPort: '', internalPort: '', label: '' });
      await load();
    } else {
      const msgs: Record<string, string> = {
        PORT_LIMIT_REACHED: r.message || 'Limit reached — max 5 port forwards per person',
        PORT_IN_USE: r.message || 'That external port is already in use on this node',
        INVALID_INTERNAL_PORT: 'Internal port must be 1-65535',
        INVALID_EXTERNAL_PORT: r.message || 'External port must be 1024-65535',
        VPS_SUSPENDED: 'This VPS is suspended',
        VPS_PROVISIONING: 'Wait for provisioning to finish first',
      };
      toast.error(msgs[r.error] || r.message || `Failed: ${r.error}`);
    }
  };

  const remove = async (forwardId: string) => {
    setDeletingId(forwardId);
    const r = await api.remove(vpsId, forwardId);
    setDeletingId(null);
    if (r.success) {
      toast.success('Forward removed');
      await load();
    } else {
      toast.error(`Failed: ${r.error}`);
    }
  };

  if (loading) {
    return <div className="flex justify-center py-12"><Loader2 className="w-6 h-6 text-rose-400 animate-spin" /></div>;
  }

  const forwards: any[] = data?.forwards || [];
  const limit: number = data?.limit ?? 5;
  const used: number = data?.used ?? 0;
  const remaining: number = data?.remaining ?? limit;

  return (
    <div className="space-y-4">
      <Card className="glass-panel p-5">
        <div className="flex items-center justify-between flex-wrap gap-3 mb-4">
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-zinc-500 flex items-center gap-2">
              <ArrowRightLeft className="w-4 h-4 text-rose-400" /> Port Forwarding
            </h3>
            <p className="text-xs text-zinc-500 mt-1">
              Forward ports from {data?.nodeIp ? <span className="font-mono text-zinc-300">{data.nodeIp}</span> : 'your node\u2019s public IP'} to this VPS
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Badge
              variant="outline"
              className={remaining === 0
                ? 'bg-red-500/10 text-red-300 border-red-500/30'
                : 'bg-rose-500/10 text-rose-300 border-rose-500/30'}
            >
              {used} / {limit} used
            </Badge>
            <Button size="sm" onClick={() => setOpen(true)} disabled={!canAdd}
              className="bg-rose-600 hover:bg-rose-500 text-white">
              <Plus className="w-4 h-4" /> Add Forward
            </Button>
          </div>
        </div>

        {isSuspended && (
          <div className="text-xs text-red-300 bg-red-500/10 border border-red-500/20 p-3 rounded mb-3">
            This VPS is suspended — port forwarding is disabled.
          </div>
        )}

        {forwards.length === 0 ? (
          <div className="text-center py-10">
            <Network className="w-8 h-8 text-zinc-700 mx-auto mb-3" />
            <p className="text-sm text-zinc-400">No port forwards yet</p>
            <p className="text-xs text-zinc-600 mt-1">
              You can create up to {limit} forwards ({remaining} remaining)
            </p>
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow className="border-zinc-800">
                <TableHead className="text-zinc-500">Label</TableHead>
                <TableHead className="text-zinc-500">Protocol</TableHead>
                <TableHead className="text-zinc-500">External (public)</TableHead>
                <TableHead className="text-zinc-500"></TableHead>
                <TableHead className="text-zinc-500">Internal (VPS)</TableHead>
                <TableHead className="text-zinc-500 text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {forwards.map((f: any) => (
                <TableRow key={f.id} className="border-zinc-800">
                  <TableCell className="text-zinc-300">{f.label || <span className="text-zinc-600">—</span>}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className="bg-blue-500/10 text-blue-300 border-blue-500/30 uppercase">{f.protocol}</Badge>
                  </TableCell>
                  <TableCell className="font-mono text-zinc-200">
                    {data?.nodeIp ? `${data.nodeIp}:` : ''}{f.externalPort}
                  </TableCell>
                  <TableCell><ArrowRight className="w-3.5 h-3.5 text-zinc-600" /></TableCell>
                  <TableCell className="font-mono text-zinc-200">{f.internalPort}</TableCell>
                  <TableCell className="text-right">
                    <Button size="sm" variant="outline" disabled={deletingId === f.id}
                      onClick={() => remove(f.id)}
                      className="border-zinc-800 text-zinc-400 hover:text-red-300 hover:border-red-500/40 hover:bg-red-500/10 h-8">
                      {deletingId === f.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}

        <div className="flex items-start gap-2 mt-4 text-xs text-zinc-600">
          <Info className="w-3.5 h-3.5 shrink-0 mt-0.5" />
          <p>
            Limit: {limit} active forwards per person across all your VPSes.
            External port is auto-assigned (20000-60999) when left empty; manual ports must be 1024-65535.
          </p>
        </div>
      </Card>

      {/* Add Forward Dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="bg-zinc-950 border-zinc-800">
          <DialogHeader><DialogTitle>Add Port Forward</DialogTitle></DialogHeader>
          <div className="space-y-3 py-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Protocol</Label>
                <Select value={form.protocol} onValueChange={v => setForm(p => ({ ...p, protocol: v }))}>
                  <SelectTrigger className="bg-zinc-950/50 border-zinc-800"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-zinc-950 border-zinc-800">
                    <SelectItem value="tcp">TCP</SelectItem>
                    <SelectItem value="udp">UDP</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Internal port (in VPS)</Label>
                <Input type="number" min={1} max={65535} value={form.internalPort}
                  onChange={e => setForm(p => ({ ...p, internalPort: e.target.value }))}
                  placeholder="25565" className="bg-zinc-950/50 border-zinc-800 font-mono" />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>External port (public) — optional</Label>
              <Input type="number" min={1024} max={65535} value={form.externalPort}
                onChange={e => setForm(p => ({ ...p, externalPort: e.target.value }))}
                placeholder="Auto-assign (20000-60999)" className="bg-zinc-950/50 border-zinc-800 font-mono" />
            </div>
            <div className="space-y-1.5">
              <Label>Label — optional</Label>
              <Input value={form.label}
                onChange={e => setForm(p => ({ ...p, label: e.target.value }))}
                placeholder="Minecraft server" className="bg-zinc-950/50 border-zinc-800" />
            </div>
            <div className="text-xs text-zinc-500 bg-zinc-900/50 border border-zinc-800 p-3 rounded flex items-start gap-2">
              <Info className="w-3.5 h-3.5 shrink-0 mt-0.5 text-rose-400" />
              <span>
                Traffic to <span className="font-mono text-zinc-300">{data?.nodeIp || 'node IP'}:{form.externalPort.trim() || 'auto'}</span>/{form.protocol} will
                reach <span className="font-mono text-zinc-300">:{form.internalPort || '…'}</span> inside this VPS.
                You have {remaining} of {limit} forwards left.
              </span>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)} className="border-zinc-800">Cancel</Button>
            <Button onClick={submit} disabled={busy || !form.internalPort}
              className="bg-rose-600 hover:bg-rose-500 text-white">
              {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />} Add Forward
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
