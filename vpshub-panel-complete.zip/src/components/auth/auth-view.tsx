'use client';

import { useState } from 'react';
import { useAppStore } from '@/lib/frontend/store';
import { authApi, friendlyMessage } from '@/lib/frontend/api';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { BrandBar } from '@/components/shared/brand-bar';
import { Loader2, Shield, Server, Zap, Lock } from 'lucide-react';

export function AuthView() {
  const { login, register, error, setError, brand, branding } = useAppStore();
  const [mode, setMode] = useState<'login' | 'register' | 'forgot' | 'reset'>('login');
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    name: '', username: '', email: '', password: '', confirmPassword: '',
  });
  const [resetToken, setResetToken] = useState('');
  const [resetMsg, setResetMsg] = useState<string | null>(null);

  const set = (k: string, v: string) => setForm(prev => ({ ...prev, [k]: v }));

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true); setError(null);
    await login(form.email, form.password);
    setLoading(false);
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true); setError(null);
    await register(form);
    setLoading(false);
  };

  const handleForgot = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true); setResetMsg(null);
    const r = await authApi.forgotPassword(form.email);
    setLoading(false);
    if (r.success && (r as any).resetToken) {
      setResetToken((r as any).resetToken);
      setResetMsg('Reset token generated (sandbox). Use the reset form to set a new password.');
    } else if (r.success) {
      setResetMsg('If the email exists, a reset link has been sent.');
    } else {
      setResetMsg(friendlyMessage(r));
    }
  };

  const handleReset = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true); setResetMsg(null);
    const r = await authApi.resetPassword(resetToken, form.password);
    setLoading(false);
    if (r.success) {
      setResetMsg('Password reset successfully. You can now log in.');
      setMode('login');
    } else {
      setResetMsg(friendlyMessage(r));
    }
  };

  return (
    <div className="min-h-screen flex grid-bg relative overflow-hidden">
      {/* Background wallpaper — covers the full login screen, dimmed so the
          form stays readable. Image lives in /public/login-wallpaper.png
          (uploaded by the owner). */}
      <div
        aria-hidden="true"
        className="absolute inset-0 z-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: 'url(/login-wallpaper.png)' }}
      />
      <div className="absolute inset-0 z-0 bg-gradient-to-br from-black/85 via-zinc-950/80 to-black/85" />
      <div className="absolute inset-0 z-0 bg-gradient-to-t from-rose-950/30 via-transparent to-rose-950/10 pointer-events-none" />

      {/* Left brand panel */}
      <div className="hidden lg:flex flex-col justify-between p-12 w-1/2 relative z-10 overflow-hidden">
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-rose-500 to-transparent" />
        <div className="relative z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-rose-500 flex items-center justify-center glow-red">
              <Server className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="text-xl font-bold tracking-tight">{brand}</p>
              <p className="text-xs text-zinc-500 -mt-0.5">Infrastructure Platform</p>
            </div>
          </div>
        </div>

        <div className="relative z-10 space-y-8">
          <div>
            <h1 className="text-4xl font-bold tracking-tight">
              {/* Headline is editable from Admin → Settings → Login Page */}
              {branding.heroTop && (
                <span className="text-rose-500">{branding.heroTop}</span>
              )}
              {branding.heroTop && branding.heroBottom && <br />}
              {branding.heroBottom}
            </h1>
            <p className="text-zinc-400 mt-4 max-w-md">
              {branding.heroDescription}
            </p>
          </div>
          <div className="space-y-3">
            {[
              { icon: Shield, title: 'RBAC + Backend Enforcement', desc: 'Server-side permission checks on every API call' },
              { icon: Server, title: 'Infrastructure Provider Abstraction', desc: 'Proxmox, VMware, Hyper-V, libvirt' },
              { icon: Zap, title: 'Real-time WebSockets', desc: 'Console, deployment progress, live metrics' },
              { icon: Lock, title: 'Secure by Design', desc: 'Argon2id passwords, JWT sessions, audit logs' },
            ].map((f, i) => (
              <div key={i} className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-md bg-rose-500/10 border border-rose-500/20 flex items-center justify-center shrink-0">
                  <f.icon className="w-4 h-4 text-rose-400" />
                </div>
                <div>
                  <p className="text-sm font-medium text-zinc-200">{f.title}</p>
                  <p className="text-xs text-zinc-500">{f.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="relative z-10 text-xs text-zinc-600">
          <p>© 2026 {brand} · Production Build</p>
        </div>
      </div>

      {/* Right form panel */}
      <div className="flex-1 relative z-10 flex items-center justify-center p-4 sm:p-6 lg:p-12">
        <div className="w-full max-w-md">
          {/* Mobile brand */}
          <div className="lg:hidden mb-8 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-rose-500 flex items-center justify-center glow-red">
              <Server className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="text-lg font-bold tracking-tight">{brand}</p>
              <p className="text-xs text-zinc-500 -mt-0.5">Infrastructure Platform</p>
            </div>
          </div>

          {mode === 'login' && (
            <Card className="glass-panel p-5 sm:p-8">
              <h2 className="text-2xl font-bold">Sign In</h2>
              <p className="text-sm text-zinc-400 mt-1 mb-6">
                Access your VPS hosting dashboard
              </p>
              <form onSubmit={handleLogin} className="space-y-4">
                <div className="space-y-1.5">
                  <Label htmlFor="email">Email or Username</Label>
                  <Input id="email" type="text" inputMode="email" autoComplete="username" required value={form.email}
                    onChange={(e) => set('email', e.target.value)}
                    placeholder="you@hosting.com or your username"
                    className="bg-zinc-950/50 border-zinc-800 focus:border-rose-500/50" />
                </div>
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="password">Password</Label>
                    <button type="button" onClick={() => setMode('forgot')} className="text-xs text-rose-400 hover:text-rose-300">
                      Forgot password?
                    </button>
                  </div>
                  <Input id="password" type="password" required value={form.password}
                    onChange={(e) => set('password', e.target.value)}
                    className="bg-zinc-950/50 border-zinc-800 focus:border-rose-500/50" />
                </div>
                {error && (
                  <div className="text-xs text-red-400 bg-red-500/10 border border-red-500/20 rounded px-3 py-2">
                    {error === 'INVALID_CREDENTIALS' ? 'Invalid email/username or password.' :
                     error === 'ACCOUNT_SUSPENDED' ? 'Your account has been suspended.' :
                     error === 'EMAIL_TAKEN' ? 'An account with this email already exists.' :
                     error === 'USERNAME_TAKEN' ? 'This username is taken.' :
                     friendlyMessage({ error: error as string })}
                  </div>
                )}
                <Button type="submit" disabled={loading}
                  className="w-full bg-rose-600 hover:bg-rose-500 text-white">
                  {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Sign In'}
                </Button>
              </form>
              <p className="text-center text-sm text-zinc-400 mt-6">
                Don't have an account?{' '}
                <button onClick={() => { setMode('register'); setError(null); }} className="text-rose-400 hover:text-rose-300 font-medium">
                  Register
                </button>
              </p>
            </Card>
          )}

          {mode === 'register' && (
            <Card className="glass-panel p-5 sm:p-8">
              <h2 className="text-2xl font-bold">Create Account</h2>
              <p className="text-sm text-zinc-400 mt-1 mb-6">
                Customer registration — VPS are provisioned by admins
              </p>
              <form onSubmit={handleRegister} className="space-y-4">
                <div className="space-y-1.5">
                  <Label htmlFor="name">Full Name</Label>
                  <Input id="name" required value={form.name}
                    onChange={(e) => set('name', e.target.value)}
                    className="bg-zinc-950/50 border-zinc-800 focus:border-rose-500/50" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="username">Username</Label>
                  <Input id="username" required value={form.username}
                    onChange={(e) => set('username', e.target.value)}
                    className="bg-zinc-950/50 border-zinc-800 focus:border-rose-500/50 font-mono"
                    placeholder=" alphanumeric or _" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="remail">Email</Label>
                  <Input id="remail" type="text" inputMode="email" autoComplete="email" required value={form.email}
                    onChange={(e) => set('email', e.target.value)}
                    className="bg-zinc-950/50 border-zinc-800 focus:border-rose-500/50" />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label htmlFor="rpass">Password</Label>
                    <Input id="rpass" type="password" required value={form.password}
                      onChange={(e) => set('password', e.target.value)}
                      className="bg-zinc-950/50 border-zinc-800 focus:border-rose-500/50" />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="rpass2">Confirm</Label>
                    <Input id="rpass2" type="password" required value={form.confirmPassword}
                      onChange={(e) => set('confirmPassword', e.target.value)}
                      className="bg-zinc-950/50 border-zinc-800 focus:border-rose-500/50" />
                  </div>
                </div>
                {error && (
                  <div className="text-xs text-red-400 bg-red-500/10 border border-red-500/20 rounded px-3 py-2">
                    {error === 'EMAIL_TAKEN' ? 'An account with this email already exists.' :
                     error === 'USERNAME_TAKEN' ? 'This username is taken.' :
                     error === 'VALIDATION_ERROR' ? 'Please fill all fields correctly (password min 8 chars).' :
                     friendlyMessage({ error: error as string })}
                  </div>
                )}
                <Button type="submit" disabled={loading}
                  className="w-full bg-rose-600 hover:bg-rose-500 text-white">
                  {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Create Account'}
                </Button>
                <p className="text-xs text-zinc-500 text-center">
                  By registering, you agree that VPS provisioning is performed by administrators only.
                </p>
              </form>
              <p className="text-center text-sm text-zinc-400 mt-6">
                Already have an account?{' '}
                <button onClick={() => { setMode('login'); setError(null); }} className="text-rose-400 hover:text-rose-300 font-medium">
                  Sign in
                </button>
              </p>
            </Card>
          )}

          {mode === 'forgot' && (
            <Card className="glass-panel p-5 sm:p-8">
              <h2 className="text-2xl font-bold">Reset Password</h2>
              <p className="text-sm text-zinc-400 mt-1 mb-6">Enter your email to receive a reset link</p>
              <form onSubmit={handleForgot} className="space-y-4">
                <div className="space-y-1.5">
                  <Label htmlFor="femail">Email</Label>
                  <Input id="femail" type="text" inputMode="email" autoComplete="email" required value={form.email}
                    onChange={(e) => set('email', e.target.value)}
                    className="bg-zinc-950/50 border-zinc-800 focus:border-rose-500/50" />
                </div>
                {resetMsg && (
                  <div className="text-xs text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 rounded px-3 py-2">
                    {resetMsg}
                  </div>
                )}
                <Button type="submit" disabled={loading}
                  className="w-full bg-rose-600 hover:bg-rose-500 text-white">
                  {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Send Reset Link'}
                </Button>
              </form>
              <div className="mt-6 text-center">
                <button onClick={() => { setMode('reset'); }} className="text-xs text-zinc-500 hover:text-zinc-300">
                  Have a reset token? Click here →
                </button>
              </div>
              <p className="text-center text-sm text-zinc-400 mt-3">
                <button onClick={() => { setMode('login'); setResetMsg(null); }} className="text-rose-400 hover:text-rose-300 font-medium">
                  Back to sign in
                </button>
              </p>
            </Card>
          )}

          {mode === 'reset' && (
            <Card className="glass-panel p-5 sm:p-8">
              <h2 className="text-2xl font-bold">Set New Password</h2>
              <p className="text-sm text-zinc-400 mt-1 mb-6">Use the token from your reset email</p>
              <form onSubmit={handleReset} className="space-y-4">
                <div className="space-y-1.5">
                  <Label htmlFor="rtoken">Reset Token</Label>
                  <Input id="rtoken" required value={resetToken}
                    onChange={(e) => setResetToken(e.target.value)}
                    className="bg-zinc-950/50 border-zinc-800 focus:border-rose-500/50 font-mono text-xs" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="rpass3">New Password</Label>
                  <Input id="rpass3" type="password" required value={form.password}
                    onChange={(e) => set('password', e.target.value)}
                    className="bg-zinc-950/50 border-zinc-800 focus:border-rose-500/50" />
                </div>
                {resetMsg && (
                  <div className="text-xs text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 rounded px-3 py-2">
                    {resetMsg}
                  </div>
                )}
                <Button type="submit" disabled={loading}
                  className="w-full bg-rose-600 hover:bg-rose-500 text-white">
                  {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Reset Password'}
                </Button>
              </form>
              <p className="text-center text-sm text-zinc-400 mt-6">
                <button onClick={() => { setMode('login'); setResetMsg(null); }} className="text-rose-400 hover:text-rose-300 font-medium">
                  Back to sign in
                </button>
              </p>
            </Card>
          )}

          {/* Owner identity — YT Owner / Discord Server buttons + credit */}
          <BrandBar className="mt-6" />
        </div>
      </div>
    </div>
  );
}
