#!/bin/bash
# Test: custom roles, role assignment, profile API, auto-suspend presets
set -e
BASE=http://localhost:3000
JAR=/tmp/noctis-jar.txt
rm -f $JAR
SUFFIX=$(date +%s)
ROLE_NAME="Billing Support $SUFFIX"

echo "=== 1. Login as super admin (username) ==="
curl -s -c $JAR -X POST $BASE/api/auth/login -H 'Content-Type: application/json' \
  -d '{"identifier":"『NØCTIS』","password":"123"}' | python3 -c "import json,sys; d=json.load(sys.stdin); print('login:', d['success'], '| perms:', len(d.get('user',{}).get('permissions',[])))"

echo "=== 2. GET /api/admin/roles (built-ins + custom) ==="
curl -s -b $JAR $BASE/api/admin/roles | python3 -c "
import json,sys; d=json.load(sys.stdin)
print('built-in:', [(r['name'], r['userCount'], len(r['permissions'])) for r in d['data']['builtIn']])
print('custom:', d['data']['custom'])
"

echo "=== 3. Create custom role '$ROLE_NAME' ==="
ROLE_ID=$(curl -s -b $JAR -X POST $BASE/api/admin/roles -H 'Content-Type: application/json' \
  -d "{\"name\":\"$ROLE_NAME\",\"description\":\"View users + support tickets only\",\"color\":\"#3b82f6\",\"permissions\":[\"users.view\",\"support.view\",\"support.manage\",\"vps.view\"]}" \
  | python3 -c "import json,sys; d=json.load(sys.stdin); print(d['data']['id'] if d['success'] else 'FAIL:'+d.get('error',''))")
echo "role id: $ROLE_ID"

echo "=== 3b. Duplicate name should fail ==="
curl -s -b $JAR -X POST $BASE/api/admin/roles -H 'Content-Type: application/json' \
  -d '{"name":"Billing Support","permissions":["users.view"]}' | python3 -c "import json,sys; d=json.load(sys.stdin); print('dup:', d['success']==False, d.get('error'))"

echo "=== 3c. Reserved name should fail ==="
curl -s -b $JAR -X POST $BASE/api/admin/roles -H 'Content-Type: application/json' \
  -d '{"name":"admin","permissions":["users.view"]}' | python3 -c "import json,sys; d=json.load(sys.stdin); print('reserved:', d['success']==False, d.get('error'))"

echo "=== 4. Pick a test customer ==="
USER_ID=$(curl -s -b $JAR "$BASE/api/admin/users?pageSize=5" | python3 -c "
import json,sys; d=json.load(sys.stdin)
users=[u for u in d['data'] if u['role']=='USER' and not u.get('customRole')]
print(users[0]['id'] if users else 'NONE')
")
echo "test user: $USER_ID"

echo "=== 5. Assign custom role to user ==="
curl -s -b $JAR -X PATCH $BASE/api/admin/users/$USER_ID -H 'Content-Type: application/json' \
  -d "{\"customRoleId\":\"$ROLE_ID\"}" | python3 -c "import json,sys; d=json.load(sys.stdin); print('assign:', d['success'], d.get('data'))"

echo "=== 5b. Verify user now has custom role ==="
curl -s -b $JAR $BASE/api/admin/users/$USER_ID | python3 -c "import json,sys; d=json.load(sys.stdin); print('customRole:', d['data']['customRole'], '| base role:', d['data']['role'])"

echo "=== 6. Create staff via /api/admin/staff with custom role ==="
curl -s -b $JAR -X POST $BASE/api/admin/staff -H 'Content-Type: application/json' \
  -d "{\"name\":\"Test Support Agent\",\"username\":\"testsupport$SUFFIX\",\"email\":\"testsupport$SUFFIX@vps.local\",\"password\":\"Passw0rd!23\",\"role\":\"STAFF\",\"customRoleId\":\"$ROLE_ID\"}" \
  | python3 -c "import json,sys; d=json.load(sys.stdin); print('staff create:', d['success'], d.get('data') or d.get('error'))"

echo "=== 6b. Short password error ==="
curl -s -b $JAR -X POST $BASE/api/admin/staff -H 'Content-Type: application/json' \
  -d '{"name":"X","username":"shortpw","email":"shortpw@vps.local","password":"123","role":"SUPPORT"}' \
  | python3 -c "import json,sys; d=json.load(sys.stdin); print('shortpw:', d.get('error'))"

echo "=== 7. Login as the custom-role staff — permissions must come from the role ==="
curl -s -c /tmp/staff-jar.txt -X POST $BASE/api/auth/login -H 'Content-Type: application/json' \
  -d "{\"identifier\":\"testsupport$SUFFIX@vps.local\",\"password\":\"Passw0rd!23\"}" | python3 -c "
import json,sys; d=json.load(sys.stdin); u=d.get('user',{})
print('login:', d['success'], '| customRoleName:', u.get('customRoleName'), '| perms:', u.get('permissions'))
"

echo "=== 7b. Custom-role staff CAN view users (users.view granted) ==="
curl -s -b /tmp/staff-jar.txt "$BASE/api/admin/users?pageSize=1" | python3 -c "import json,sys; d=json.load(sys.stdin); print('users.view:', d['success'])"

echo "=== 7c. Custom-role staff CANNOT create plans (not granted) ==="
curl -s -b /tmp/staff-jar.txt -X POST $BASE/api/admin/plans -H 'Content-Type: application/json' \
  -d '{"name":"x","cpu":1,"ramMb":512,"diskGb":10,"bandwidthMbps":10}' | python3 -c "import json,sys; d=json.load(sys.stdin); print('plans.create blocked:', d['success']==False, d.get('error'))"

echo "=== 7d. Custom-role staff CANNOT manage staff ==="
curl -s -b /tmp/staff-jar.txt $BASE/api/admin/staff | python3 -c "import json,sys; d=json.load(sys.stdin); print('staff.manage blocked:', d['success']==False, d.get('error'))"

echo "=== 8. Profile API — read + update own ==="
curl -s -b /tmp/staff-jar.txt $BASE/api/profile | python3 -c "import json,sys; d=json.load(sys.stdin); print('profile get:', d['success'], '| name:', d['data']['name'], '| customRole:', d['data']['customRoleName'])"
curl -s -b /tmp/staff-jar.txt -X PATCH $BASE/api/profile -H 'Content-Type: application/json' \
  -d '{"name":"Renamed Agent"}' | python3 -c "import json,sys; d=json.load(sys.stdin); print('profile rename:', d['success'])"
curl -s -b /tmp/staff-jar.txt -X PATCH $BASE/api/profile -H 'Content-Type: application/json' \
  -d '{"currentPassword":"WRONG","newPassword":"NewPassw0rd!9"}' | python3 -c "import json,sys; d=json.load(sys.stdin); print('wrong current pw:', d['success']==False, d.get('error'))"
curl -s -b /tmp/staff-jar.txt -X PATCH $BASE/api/profile -H 'Content-Type: application/json' \
  -d '{"currentPassword":"Passw0rd!23","newPassword":"NewPassw0rd!9"}' | python3 -c "import json,sys; d=json.load(sys.stdin); print('password change:', d['success'])"

echo "=== 9. Self role change must be blocked ==="
MYID=$(curl -s -b $JAR $BASE/api/auth/me | python3 -c "import json,sys; print(json.load(sys.stdin)['user']['id'])")
curl -s -b $JAR -X PATCH $BASE/api/admin/users/$MYID -H 'Content-Type: application/json' \
  -d '{"role":"USER"}' | python3 -c "import json,sys; d=json.load(sys.stdin); print('self role change blocked:', d['success']==False, d.get('error'))"

echo "=== 10. Role edit + delete lifecycle ==="
curl -s -b $JAR -X PATCH $BASE/api/admin/roles/$ROLE_ID -H 'Content-Type: application/json' \
  -d '{"description":"Updated description","permissions":["users.view","support.view","support.manage","vps.view","audit.view"]}' \
  | python3 -c "import json,sys; d=json.load(sys.stdin); print('role update:', d['success'])"
curl -s -b $JAR -X DELETE $BASE/api/admin/roles/$ROLE_ID | python3 -c "import json,sys; d=json.load(sys.stdin); print('role delete (in use):', d['success']==False, d.get('error'))"

echo "=== 11. Unassign custom role from test user (back to USER) ==="
curl -s -b $JAR -X PATCH $BASE/api/admin/users/$USER_ID -H 'Content-Type: application/json' \
  -d '{"customRoleId":null,"role":"USER"}' | python3 -c "import json,sys; d=json.load(sys.stdin); print('unassign:', d['success'])"

echo "=== 12. Cleanup: delete test staff + role ==="
STAFF_ID=$(curl -s -b $JAR "$BASE/api/admin/users?search=testsupport$SUFFIX" | python3 -c "import json,sys; d=json.load(sys.stdin); print(d['data'][0]['id'] if d['data'] else 'NONE')")
curl -s -b $JAR -X POST $BASE/api/admin/users/$STAFF_ID -H 'Content-Type: application/json' -d '{"action":"suspend"}' > /dev/null
# Also unassign any stragglers from earlier failed runs (userCount must hit 0)
for RID in $(curl -s -b $JAR $BASE/api/admin/roles | python3 -c "import json,sys; d=json.load(sys.stdin); [print(r['id']) for r in d['data']['custom'] if r['userCount']>0]"); do
  for TUID in $(curl -s -b $JAR "$BASE/api/admin/users?pageSize=100" | python3 -c "import json,sys; d=json.load(sys.stdin); [print(u['id']) for u in d['data'] if u.get('customRole')]"); do
    curl -s -b $JAR -X PATCH $BASE/api/admin/users/$TUID -H 'Content-Type: application/json' -d '{"customRoleId":null,"role":"USER"}' > /dev/null
  done
done
curl -s -b $JAR -X DELETE $BASE/api/admin/roles/$ROLE_ID | python3 -c "import json,sys; d=json.load(sys.stdin); print('role deleted after unassign:', d['success'])"
# Remove leftover custom roles from earlier failed runs
for RID in $(curl -s -b $JAR $BASE/api/admin/roles | python3 -c "import json,sys; d=json.load(sys.stdin); [print(r['id']) for r in d['data']['custom'] if 'Billing Support' in r['name']]"); do
  curl -s -b $JAR -X DELETE $BASE/api/admin/roles/$RID > /dev/null && echo "cleaned leftover role $RID"
done

echo "=== 13. me endpoint for super admin ==="
curl -s -b $JAR $BASE/api/auth/me | python3 -c "import json,sys; d=json.load(sys.stdin); u=d['user']; print('super perms:', len(u['permissions']), '| staff.manage:', 'staff.manage' in u['permissions'])"

echo "ALL DONE"
