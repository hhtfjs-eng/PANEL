// Create the 『NØCTIS』 super admin account in the current database + sync site.name branding.
// Run: bunx tsx scripts/create-noctis-admin.ts   (or npx tsx)
import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const db = new PrismaClient();

async function main() {
  const email = 'nøctis@gmail.com';
  const username = '『NØCTIS』';
  const password = '123';

  const passwordHash = await bcrypt.hash(password, 10);

  // Look for an existing row by email (case-insensitive source of truth: stored lowercase)
  let user = await db.user.findFirst({
    where: { OR: [{ email }, { username }] },
  });

  if (user) {
    user = await db.user.update({
      where: { id: user.id },
      data: {
        name: username,
        username,
        email,
        passwordHash,
        role: 'SUPER_ADMIN',
        status: 'ACTIVE',
        emailVerified: true,
      },
    });
    console.log('Updated existing account:', user.email, '|', user.username, '|', user.role);
  } else {
    user = await db.user.create({
      data: {
        name: username,
        username,
        email,
        passwordHash,
        role: 'SUPER_ADMIN',
        status: 'ACTIVE',
        emailVerified: true,
      },
    });
    console.log('Created super admin:', user.email, '|', user.username, '|', user.role);
  }

  // Branding: site.name now drives the whole UI — keep it consistent with the current look
  await db.setting.upsert({
    where: { key: 'site.name' },
    update: { value: 'DeUp-VPS' },
    create: { key: 'site.name', value: 'DeUp-VPS' },
  });
  const siteName = await db.setting.findUnique({ where: { key: 'site.name' } });
  console.log('site.name =', siteName?.value);

  // Verify login credentials hash
  const ok = await bcrypt.compare(password, user.passwordHash);
  console.log('password "123" verifies:', ok);
}

main()
  .catch(e => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());
