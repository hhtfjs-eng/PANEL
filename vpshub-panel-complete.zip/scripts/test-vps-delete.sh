#!/bin/bash
# ============================================================
# VPS deletion E2E — verifies the "shows deleted but stays in
# list" fix plus every resurrection guard.
# Idempotent: cleans up every record it creates.
# ============================================================
set -u
BASE="http://localhost:3000"
CJ=$(mktemp)
ADMIN_CJ=$(mktemp)
J() { python3 -c "import sys,json; d=json.load(sys.stdin); print($1)" 2>/dev/null; }

PASS=0; FAIL=0
ok()   { PASS=$((PASS+1)); echo "  PASS: $1"; }
bad()  { FAIL=$((FAIL+1)); echo "  FAIL: $1"; }

echo "== login =="
LOGIN=$(curl -s -c "$ADMIN_CJ" -X POST "$BASE/api/auth/login" -H 'Content-Type: application/json' \
  -d '{"identifier":"nøctis@gmail.com","password":"123"}')
OWNER_ID=$(echo "$LOGIN" | J "d['user']['id']")
[ -n "$OWNER_ID" ] && ok "super admin login" || { bad "login"; exit 1; }
AUTH="Cookie: $(grep -o 'session[^ ]*=[^ ]*' "$ADMIN_CJ" | head -1 | tr '\n' ';')"
# verify session cookie works
WHO=$(curl -s -b "$ADMIN_CJ" "$BASE/api/auth/me")
echo "$WHO" | grep -q '"success":true' || { bad "session cookie invalid"; exit 1; }

# pick first node + os
NODE=$(curl -s "$BASE/api/admin/nodes" -b "$ADMIN_CJ" | J "d['data'][0]['id']")
OS=$(curl -s "$BASE/api/admin/os" -b "$ADMIN_CJ" | J "d['data'][0]['id']")
echo "  node=$NODE os=$OS"

deploy() { # $1 = name -> echoes vpsId
  curl -s -b "$ADMIN_CJ" -X POST "$BASE/api/admin/vps" -H 'Content-Type: application/json' \
    -d "{\"ownerId\":\"$OWNER_ID\",\"name\":\"$1\",\"hostname\":\"$1\",\"cpu\":1,\"ramMb\":512,\"diskGb\":10,\"bandwidthMbps\":10,\"nodeId\":\"$NODE\",\"osId\":\"$OS\"}" \
    | J "d['data']['vpsId']"
}

echo ""
echo "== SCENARIO A: delete a provisioned VPS =="
A=$(deploy "del-test-a")
sleep 14   # let the deployment pipeline finish (~8 steps x 1.4-2s)
STATUS_A=$(curl -s "$BASE/api/admin/vps/$A" -b "$ADMIN_CJ" | J "d['data']['status']")
echo "  after deploy: status=$STATUS_A"

DEL=$(curl -s -X DELETE "$BASE/api/admin/vps/$A" -b "$ADMIN_CJ")
echo "$DEL" | grep -q '"success":true' && ok "DELETE succeeds" || bad "DELETE failed: $DEL"

# 1. gone from default admin list
IN_LIST=$(curl -s "$BASE/api/admin/vps" -b "$ADMIN_CJ" | J "'FOUND' if any(v['id']=='$A' for v in d['data']) else 'ABSENT'")
[ "$IN_LIST" = "ABSENT" ] && ok "admin default list: deleted VPS absent" || bad "admin default list still shows deleted VPS"

# 2. gone from search too
IN_SEARCH=$(curl -s "$BASE/api/admin/vps?search=del-test-a" -b "$ADMIN_CJ" | J "'FOUND' if any(v['id']=='$A' for v in d['data']) else 'ABSENT'")
[ "$IN_SEARCH" = "ABSENT" ] && ok "admin search: deleted VPS absent" || bad "admin search still shows deleted VPS"

# 3. visible via explicit DELETED filter (audit)
IN_DEL=$(curl -s "$BASE/api/admin/vps?status=DELETED&search=del-test-a" -b "$ADMIN_CJ" | J "'FOUND' if any(v['id']=='$A' for v in d['data']) else 'ABSENT'")
[ "$IN_DEL" = "FOUND" ] && ok "status=DELETED audit filter still finds it" || bad "audit filter cannot find deleted VPS"

# 4. gone from customer list
CUST_CJ=$(mktemp)
CUST_LOGIN=$(curl -s -c "$CUST_CJ" -X POST "$BASE/api/auth/login" -H 'Content-Type: application/json' \
  -d '{"identifier":"victus@gmail.com","password":"victus123"}')
CUST_OK=$(echo "$CUST_LOGIN" | J "d.get('success')")
if [ "$CUST_OK" = "True" ]; then
  CUST_LIST=$(curl -s -b "$CUST_CJ" "$BASE/api/customer/vps" | J "'FOUND' if any(v['id']=='$A' for v in d['data']) else 'ABSENT'")
  [ "$CUST_LIST" = "ABSENT" ] && ok "customer list: deleted VPS absent" || bad "customer list still shows deleted VPS"
else
  echo "  (skip customer check — no sample customer: $CUST_LOGIN)"
fi

# 5. resurrection attempts
P1=$(curl -s -o /dev/null -w "%{http_code}" -X POST "$BASE/api/admin/vps/$A/power" -b "$ADMIN_CJ" -H 'Content-Type: application/json' -d '{"action":"start"}')
P2=$(curl -s -o /dev/null -w "%{http_code}" -X POST "$BASE/api/customer/vps/$A/start" -b "$ADMIN_CJ")
P3=$(curl -s -X PATCH "$BASE/api/admin/vps/$A" -b "$ADMIN_CJ" -H 'Content-Type: application/json' -d '{"name":"zombie"}' | J "d.get('error','')")
P4=$(curl -s -o /dev/null -w "%{http_code}" -X POST "$BASE/api/admin/vps/$A/suspend" -b "$ADMIN_CJ" -H 'Content-Type: application/json' -d '{"reason":"x"}')
P5=$(curl -s -o /dev/null -w "%{http_code}" -X POST "$BASE/api/admin/vps/$A/unsuspend" -b "$ADMIN_CJ")
[ "$P1" = "404" ] && ok "admin power on deleted -> 404" || bad "admin power returned $P1"
[ "$P2" = "404" ] && ok "customer power on deleted -> 404" || bad "customer power returned $P2"
[ "$P3" = "VPS_DELETED" ] && ok "PATCH rename on deleted -> VPS_DELETED" || bad "PATCH returned '$P3'"
[ "$P4" = "404" ] && ok "suspend on deleted -> 404" || bad "suspend returned $P4"
[ "$P5" = "404" ] && ok "unsuspend on deleted -> 404" || bad "unsuspend returned $P5"

# 6. status must still be DELETED (not resurrected)
FINAL_A=$(curl -s "$BASE/api/admin/vps/$A" -b "$ADMIN_CJ" | J "d['data']['status']")
[ "$FINAL_A" = "DELETED" ] && ok "status stays DELETED after all attempts" || bad "status drifted to $FINAL_A"

# 7. IPs released
IPS=$(python3 -c "
import sqlite3
c = sqlite3.connect('/home/z/my-project/db/custom.db')
print(c.execute('SELECT COUNT(*) FROM IpAddress WHERE vpsId=?', ('$A',)).fetchone()[0])")
[ "$IPS" = "0" ] && ok "IPs released" || bad "$IPS IPs still bound"

# 8. suspendAt cleared
SUSP=$(python3 -c "
import sqlite3
c = sqlite3.connect('/home/z/my-project/db/custom.db')
print(c.execute('SELECT suspendAt FROM Vps WHERE id=?', ('$A',)).fetchone()[0])")
[ "$SUSP" = "None" ] && ok "suspendAt cleared on delete" || bad "suspendAt=$SUSP"

echo ""
echo "== SCENARIO B: delete DURING deployment =="
B=$(deploy "del-test-b")
sleep 2   # pipeline is mid-flight now
DEL_B=$(curl -s -X DELETE "$BASE/api/admin/vps/$B" -b "$ADMIN_CJ")
echo "$DEL_B" | grep -q '"success":true' && ok "DELETE mid-deployment succeeds" || bad "mid-deploy DELETE failed"
sleep 16  # let the pipeline run out
JOB_STATE=$(python3 -c "
import sqlite3
c = sqlite3.connect('/home/z/my-project/db/custom.db')
print(c.execute('SELECT state FROM DeploymentJob WHERE vpsId=? ORDER BY createdAt DESC LIMIT 1', ('$B',)).fetchone()[0])")
STATUS_B=$(python3 -c "
import sqlite3
c = sqlite3.connect('/home/z/my-project/db/custom.db')
print(c.execute('SELECT status FROM Vps WHERE id=?', ('$B',)).fetchone()[0])")
[ "$JOB_STATE" = "CANCELLED" ] && ok "in-flight job -> CANCELLED" || bad "job state=$JOB_STATE"
[ "$STATUS_B" = "DELETED" ] && ok "deleted VPS NOT resurrected by worker" || bad "worker resurrected VPS to $STATUS_B"

echo ""
echo "== SCENARIO C: customer GET on deleted VPS =="
if [ "$CUST_OK" = "True" ]; then
  CGET=$(curl -s -o /dev/null -w "%{http_code}" -b "$CUST_CJ" "$BASE/api/customer/vps/$A")
  AGET=$(curl -s -o /dev/null -w "%{http_code}" -b "$ADMIN_CJ" "$BASE/api/customer/vps/$A")
  [ "$CGET" = "404" ] && ok "customer GET deleted -> 404" || bad "customer GET returned $CGET"
  [ "$AGET" = "200" ] && ok "admin GET deleted -> 200 (audit)" || bad "admin GET returned $AGET"
fi

echo ""
echo "== cleanup =="
python3 - <<EOF
import sqlite3
c = sqlite3.connect('/home/z/my-project/db/custom.db')
for vps_id in ('$A', '$B'):
    c.execute('DELETE FROM VpsMetric WHERE vpsId=?', (vps_id,))
    c.execute('DELETE FROM VpsActivity WHERE vpsId=?', (vps_id,))
    c.execute('DELETE FROM DeploymentStep WHERE jobId IN (SELECT id FROM DeploymentJob WHERE vpsId=?)', (vps_id,))
    c.execute('DELETE FROM DeploymentJob WHERE vpsId=?', (vps_id,))
    c.execute('DELETE FROM Vps WHERE id=?', (vps_id,))
    c.execute('DELETE FROM Notification WHERE json_extract(metadata, \"$.vpsId\")=?', (vps_id,))
    c.execute('DELETE FROM AuditLog WHERE targetId=? AND action LIKE \"VPS_%\"', (vps_id,))
c.commit()
print('  test VPS purged')
EOF

echo ""
echo "RESULT: $PASS passed, $FAIL failed"
[ "$FAIL" = "0" ]
