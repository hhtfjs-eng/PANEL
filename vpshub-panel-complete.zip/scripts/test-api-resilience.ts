// Test the api client resilience: NON_JSON_RESPONSE must never surface again.
// Spins up flaky HTTP endpoints and calls them through the real api client.
import { api, friendlyMessage } from '../src/lib/frontend/api';

const results: string[] = [];
function check(name: string, ok: boolean) {
  results.push(`${ok ? 'OK  ' : 'FAIL'} ${name}`);
}

const server = Bun.serve({
  port: 3999,
  fetch(req) {
    const url = new URL(req.url);
    const hits = (hitCounts[url.pathname] = (hitCounts[url.pathname] || 0) + 1);

    if (url.pathname === '/flaky-502') {
      // First 2 hits: HTML 502 (like Caddy when Next restarts). Then JSON.
      if (hits <= 2) return new Response('<html>502 Bad Gateway</html>', { status: 502, headers: { 'content-type': 'text/html' } });
      return Response.json({ success: true, data: { recovered: true } });
    }

    if (url.pathname === '/flaky-html-404') {
      // HTML error page with a wrong status — still retries then succeeds
      if (hits <= 1) return new Response('<html>error page</html>', { status: 502 });
      return Response.json({ success: true, data: { ok: 1 } });
    }

    if (url.pathname === '/json-wrong-ctype') {
      // Valid JSON but text/plain content-type — must parse leniently
      return new Response(JSON.stringify({ success: true, data: { x: 42 } }), {
        status: 200, headers: { 'content-type': 'text/plain' },
      });
    }

    if (url.pathname === '/empty-204') {
      return new Response(null, { status: 204 });
    }

    if (url.pathname === '/always-html') {
      // Permanent HTML failure — GET retries 3x then gives up with SERVICE_UNAVAILABLE
      return new Response('<html>down</html>', { status: 503 });
    }

    if (url.pathname === '/mutation-flaky') {
      // Mutation: first hit 502 (proxy never reached app), second succeeds
      if (hits <= 1) return new Response('<html>502</html>', { status: 502 });
      return Response.json({ success: true, data: { id: 'created' } });
    }

    if (url.pathname === '/app-error-json') {
      // App-level JSON error — must NOT be retried, code preserved
      return Response.json({ success: false, error: 'NODE_CPU_FULL' }, { status: 400 });
    }

    if (url.pathname === '/401-json') {
      return Response.json({ success: false, error: 'UNAUTHENTICATED' }, { status: 401 });
    }

    return new Response(null, { status: 404 });
  },
});
const hitCounts: Record<string, number> = {};

const base = 'http://localhost:3999';

// 1. 502 twice then success — GET retries silently
let r = await api.get(`${base}/flaky-502`);
check('GET recovers after 2× HTML 502', r.success === true && r.data?.recovered === true);
check('no NON_JSON_RESPONSE error code', r.error !== 'NON_JSON_RESPONSE');

// 2. HTML error page with retries
r = await api.get(`${base}/flaky-html-404`);
check('GET recovers after HTML error page', r.success === true);

// 3. JSON with wrong content-type parses fine
r = await api.get(`${base}/json-wrong-ctype`);
check('lenient JSON parse (text/plain body)', r.success === true && r.data?.x === 42);

// 4. Empty 204 = success
r = await api.get(`${base}/empty-204`);
check('empty 204 counts as success', r.success === true);

// 5. Permanently down — 8 attempts (extended ladder), friendly error, never NON_JSON_RESPONSE
const t0 = Date.now();
r = await api.get(`${base}/always-html`);
const elapsed = Date.now() - t0;
check('permanent failure → SERVICE_UNAVAILABLE (not NON_JSON_RESPONSE)', r.error === 'SERVICE_UNAVAILABLE');
check(`retried with backoff (${elapsed}ms ≥ 1800ms)`, elapsed >= 1800);
check('friendly message is human text', friendlyMessage(r) === 'The server is briefly unavailable (restarting or busy) — your action was retried automatically. Please try again in a moment.');
check('hit count is 8 attempts (extended ladder)', hitCounts['/always-html'] === 8);

// 6. Mutation retries once on proxy-level 502 then succeeds
r = await api.post(`${base}/mutation-flaky`, { a: 1 });
check('POST recovers after proxy 502 (single retry)', r.success === true && r.data?.id === 'created');
check('mutation only sent twice', hitCounts['/mutation-flaky'] === 2);

// 7. App-level JSON error code preserved (no retry)
r = await api.get(`${base}/app-error-json`);
check('app error code preserved (NODE_CPU_FULL)', r.error === 'NODE_CPU_FULL');
check('app error hit exactly once (no retry)', hitCounts['/app-error-json'] === 1);
check('friendly message for NODE_CPU_FULL', friendlyMessage(r) === 'Not enough CPU capacity left on that node.');

// 8. 401 does not crash the client (session handler runs, user is null → no-op)
r = await api.get(`${base}/401-json`);
check('401 handled gracefully', r.error === 'UNAUTHENTICATED');

// 9. friendlyMessage fallback for unknown codes
check('unknown code → readable text', friendlyMessage({ error: 'SOMETHING_NEW' }) === 'something new');

server.stop(true);

console.log(results.join('\n'));
const fails = results.filter(x => x.startsWith('FAIL')).length;
console.log(`\n${results.length - fails}/${results.length} checks passed`);
process.exit(fails ? 1 : 0);
