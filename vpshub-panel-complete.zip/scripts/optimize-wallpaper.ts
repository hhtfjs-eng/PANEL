// Convert the uploaded wallpaper PNG to an optimized JPEG for web background use
import sharp from 'sharp';
import { readFileSync, statSync } from 'fs';

const SRC = '/home/z/my-project/upload/updated wallpaper.png';
const OUT = '/home/z/my-project/public/wallpaper.jpg';

const before = statSync(SRC).size;
await sharp(readFileSync(SRC))
  .resize({ width: 1920, withoutEnlargement: true }) // cap at 1920 wide
  .jpeg({ quality: 80, progressive: true, mozjpeg: true })
  .toFile(OUT);

const after = statSync(OUT).size;
console.log(`PNG ${(before / 1024 / 1024).toFixed(2)} MB → JPEG ${(after / 1024).toFixed(0)} KB`);
const meta = await sharp(OUT).metadata();
console.log('dimensions:', meta.width, 'x', meta.height);
