/**
 * Idempotent: sets the owner-branding settings to the URLs the user provided:
 *   site.youtube_url   → https://www.youtube.com/channel/UCILvOqZhASpc_Pk0ULdrKUQ
 *   site.made_by_url   → https://www.youtube.com/@DevAVoid
 *   site.discord_url   → https://discord.com   (kept; user didn't override)
 *   site.owner_credit  → "Made by YT"
 *   site.watermark_text → ""  (disabled — bottom-left watermark removed per user request)
 *
 * Never overwrites an existing non-empty value unless explicitly reset with
 * RESET=1 in env. So if the admin customizes later via the Settings UI,
 * re-running this script is safe.
 */
const { PrismaClient } = require('@prisma/client');
const db = new PrismaClient();

const DEFAULTS = {
  'site.youtube_url':    'https://www.youtube.com/channel/UCILvOqZhASpc_Pk0ULdrKUQ',
  'site.made_by_url':    'https://www.youtube.com/@DevAVoid',
  'site.discord_url':    'https://discord.com',
  'site.owner_credit':   'Made by YT',
  'site.watermark_text': '',  // empty = hidden
};

const RESET = process.env.RESET === '1';

async function main() {
  for (const [key, value] of Object.entries(DEFAULTS)) {
    const existing = await db.setting.findUnique({ where: { key } });
    if (existing && !RESET) {
      console.log(`skip   ${key} (already set: ${JSON.stringify(existing.value)})`);
      continue;
    }
    await db.setting.upsert({
      where: { key },
      update: { value },
      create: { key, value },
    });
    console.log(`upsert ${key} = ${JSON.stringify(value)}`);
  }

  console.log('\nFinal branding settings:');
  for (const key of Object.keys(DEFAULTS)) {
    const s = await db.setting.findUnique({ where: { key } });
    console.log(`  ${key} = ${JSON.stringify(s?.value)}`);
  }
}

main()
  .catch(e => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());
