import { PrismaClient } from '@prisma/client';
const db = new PrismaClient();
async function main() {
  await db.user.deleteMany({ where: { email: 'demostaff@gmail.com' } });
  await db.notification.deleteMany({ where: { type: 'ROLE_CHANGED' } });
  await db.user.updateMany({ where: { email: 'nøctis@gmail.com' }, data: { role: 'SUPER_ADMIN' } });
  const users = await db.user.findMany({ select: { name: true, email: true, role: true } });
  users.forEach(u => console.log(`· ${u.name} <${u.email}> role=${u.role}`));
}
main().finally(() => db.$disconnect());
