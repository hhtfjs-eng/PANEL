import { PrismaClient } from '@prisma/client';
const db = new PrismaClient();
const users = await db.user.findMany({ select: { email: true, role: true, status: true, emailVerified: true, passwordHash: true } });
for (const u of users) console.log(u.email, '|', u.role, '|', u.status, '| verified:', u.emailVerified, '| hash:', u.passwordHash.slice(0, 7));
console.log('sessions:', await db.session.count());
await db.$disconnect();
