const BASE = 'http://localhost:3000';
async function api(method: string, path: string, body?: any, cookie?: string) {
  const res = await fetch(`${BASE}${path}`, { method, headers: { 'Content-Type': 'application/json', ...(cookie ? { Cookie: cookie } : {}) }, body: body ? JSON.stringify(body) : undefined });
  let json: any = null; try { json = await res.json(); } catch {}
  return { status: res.status, json, cookie: res.headers.get('set-cookie') };
}
(async () => {
  // 1. register test customer
  const uname = 'reinstalltest';
  let r = await api('POST', '/api/auth/register', { name: 'Reinstall Tester', username: uname, email: uname + '@t.local', password: 'Password@123', confirmPassword: 'Password@123' });
  if (!r.json?.success) { console.log('register:', JSON.stringify(r.json)); return; }
  const testUserId = r.json.user.id;

  // 2. admin login + fetch node + os
  r = await api('POST', '/api/auth/login', { email: 'nøctis@gmail.com', password: '123' });
  const admin = (r.cookie || '').split(';')[0];
  const nodes = await api('GET', '/api/admin/nodes', undefined, admin);
  const node = (nodes.json?.data || [])[0];
  const osList = await api('GET', '/api/admin/os', undefined, admin);
  const os = (osList.json?.data || []).find((o: any) => o.available);

  // 3. create VPS for the test user
  r = await api('POST', '/api/admin/vps', {
    ownerId: testUserId, name: 'Reinstall Test VPS', cpu: 1, ramMb: 512, diskGb: 10,
    bandwidthMbps: 100, nodeId: node.id, osId: os.id, autoStart: true,
  }, admin);
  console.log('vps created:', r.json?.success, r.json?.data?.id || JSON.stringify(r.json).slice(0, 200));
  console.log('TEST_USER_EMAIL=' + uname + '@t.local');
})();
