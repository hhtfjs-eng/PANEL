// Debug seed step-by-step
import { db } from '../src/lib/db';
import { hashPassword, generateRootPassword, generateToken } from '../src/lib/auth';

async function main() {
  console.log('1. findFirst...');
  const adminExists = await db.user.findFirst({ where: { role: 'SUPER_ADMIN' } });
  console.log('1. done. adminExists =', adminExists?.email);
  if (adminExists) { console.log('already seeded'); return; }

  console.log('2. hash password...');
  const passwordHash = await hashPassword('Admin@2024!');
  console.log('2. ok');

  console.log('3. create super admin...');
  const superAdmin = await db.user.create({
    data: {
      name: 'Super Admin', username: 'superadmin', email: 'admin@vps-platform.local',
      passwordHash, role: 'SUPER_ADMIN', status: 'ACTIVE', emailVerified: true,
    },
  });
  console.log('3. ok id:', superAdmin.id);

  console.log('4. create staff...');
  const staffHash = await hashPassword('Staff@2024!');
  await db.user.create({
    data: { name: 'Demo Staff', username: 'staff', email: 'staff@vps-platform.local',
      passwordHash: staffHash, role: 'STAFF', status: 'ACTIVE', emailVerified: true },
  });
  console.log('4. ok');

  console.log('5. create customer...');
  const customerHash = await hashPassword('Customer@2024!');
  const customer = await db.user.create({
    data: { name: 'Demo Customer', username: 'customer', email: 'customer@vps-platform.local',
      passwordHash: customerHash, role: 'USER', status: 'ACTIVE', emailVerified: true },
  });
  console.log('5. ok id:', customer.id);

  console.log('6. create IP pool...');
  const pool = await db.ipPool.create({
    data: {
      name: 'main-v4', family: 4, cidr: '10.0.0.0/24',
      gateway: '10.0.0.1', dnsPrimary: '1.1.1.1', dnsSecondary: '8.8.8.8',
    },
  });
  console.log('6. ok id:', pool.id);

  for (let i = 2; i < 30; i++) {
    await db.ipAddress.create({
      data: { poolId: pool.id, address: `10.0.0.${i}`, family: 4, state: 'AVAILABLE' },
    });
  }
  console.log('7. created 28 IPs');

  console.log('DONE!');
}

main().catch(e => { console.error('FAILED:', e.message); console.error(e.stack); });
