(() => {
  const codes = [...document.querySelectorAll('code')].map(c => c.textContent.trim());
  return JSON.stringify({
    loginCodes: codes.slice(0, 3),
    hasRootAtNoctis: codes.some(c => c === 'root@NØCTIS'),
    hasSshCmd: codes.some(c => c.startsWith('ssh root@'))
  });
})()
