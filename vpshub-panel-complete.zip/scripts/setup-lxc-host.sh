#!/usr/bin/env bash
# ============================================================
# DeUp-VPS — LXC Host Bootstrap
# ============================================================
# Run this ON YOUR DEDICATED LXC VPS (the machine that will host
# the customer containers). The panel VPS connects to it over SSH.
#
#   bash setup-lxc-host.sh
#
# What it does:
#   1. Installs LXC + bridge utilities + SSH server
#   2. Creates the br0 NAT bridge (10.10.0.1/24 → containers get
#      10.10.0.x, outbound NAT through the host)
#   3. Enables unprivileged containers + downloads templates
#   4. Prints the authorized_keys line to add on the PANEL VPS
#   5. Verifies everything with a test container
#
# After this script finishes:
#   - Panel → Admin → Nodes → Add Node
#   - Provider: "LXC (native containers)"
#   - API Endpoint: root@<this-host-ip>
#   - Deploy VPS → containers are created on this machine
# ============================================================
set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
ok()   { echo -e "${GREEN}[OK]${NC} $1"; }
warn() { echo -e "${YELLOW}[!!]${NC} $1"; }
info() { echo -e "${GREEN}[>>]${NC} $1"; }

if [[ $EUID -ne 0 ]]; then
  echo -e "${RED}Run as root:${NC} sudo bash setup-lxc-host.sh"
  exit 1
fi

echo "=========================================="
echo " DeUp-VPS LXC Host Bootstrap"
echo "=========================================="

# ---------- 1. Packages ----------
info "Installing LXC, bridge utils and SSH..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq lxc lxc-templates debootstrap bridge-utils \
  dnsmasq-base iptables openssh-server uidmap >/dev/null
ok "Packages installed"

# ---------- 2. Kernel modules + sysctl ----------
info "Enabling kernel networking..."
cat >/etc/modules-load.d/lxc.conf <<EOF
veth
bridge
overlay
EOF
modprobe veth 2>/dev/null || true
modprobe bridge 2>/dev/null || true

cat >/etc/sysctl.d/99-lxc.conf <<EOF
net.ipv4.ip_forward=1
net.ipv4.conf.all.forwarding=1
net.ipv6.conf.all.forwarding=1
fs.inotify.max_user_instances=1024
kernel.unprivileged_userns_clone=1
EOF
sysctl --system >/dev/null 2>&1
ok "IP forwarding + userns enabled"

# ---------- 3. Bridge (br0, NAT) ----------
info "Creating NAT bridge br0 (10.10.0.1/24)..."
if ! ip link show br0 &>/dev/null; then
  cat >/etc/network/interfaces.d/br0 <<EOF
auto br0
iface br0 inet static
    bridge_ports none
    bridge_fd 0
    bridge_maxwait 0
    address 10.10.0.1
    netmask 255.255.255.0
EOF
  ip link add br0 type bridge 2>/dev/null || true
  ip addr add 10.10.0.1/24 dev br0 2>/dev/null || true
  ip link set br0 up
fi
ok "br0 is up: $(ip -4 addr show br0 | grep -oP '(?<=inet\s)\d+(\.\d+){3}')"

# Persistent NAT rule (applied at boot via systemd unit)
cat >/etc/systemd/system/lxc-nat.service <<EOF
[Unit]
Description=NAT for LXC container bridge br0
After=network.target

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/sbin/iptables -t nat -C POSTROUTING -s 10.10.0.0/24 ! -o br0 -j MASQUERADE 2>/dev/null || /sbin/iptables -t nat -A POSTROUTING -s 10.10.0.0/24 ! -o br0 -j MASQUERADE
ExecStart=/sbin/iptables -C FORWARD -i br0 -j ACCEPT 2>/dev/null || /sbin/iptables -A FORWARD -i br0 -j ACCEPT

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable --now lxc-nat >/dev/null 2>&1
ok "NAT enabled (10.10.0.0/24 → internet)"

# ---------- 4. Default container config ----------
info "Writing default LXC config..."
mkdir -p /etc/lxc/default.conf.d
cat >/etc/lxc/default.conf <<EOF
# DeUp-VPS managed default container config
lxc.net.0.type = veth
lxc.net.0.link = br0
lxc.net.0.flags = up
# DHCP-less static IPs are pushed per-container by the panel
lxc.start.auto = 1
lxc.apparmor.profile = generated
EOF
ok "Default config written (veth → br0)"

# Allow unprivileged root to map uids (needed for `root` SSH usage)
if ! grep -q '^lxc.idmap' /etc/lxc/default.conf 2>/dev/null; then
  echo "lxc.idmap = u 0 100000 65536" >> /etc/lxc/default.conf
  echo "lxc.idmap = g 0 100000 65536" >> /etc/lxc/default.conf
fi

# ---------- 5. SSH hardening for the panel ----------
info "Ensuring SSH allows key auth..."
systemctl enable --now ssh >/dev/null 2>&1 || true
grep -q '^PubkeyAuthentication yes' /etc/ssh/sshd_config || {
  echo 'PubkeyAuthentication yes' >> /etc/ssh/sshd_config
  systemctl reload ssh 2>/dev/null || systemctl reload sshd
}
ok "SSH ready"

# ---------- 6. Templates ----------
info "Pre-caching common OS templates (ubuntu/debian/alpine)..."
for t in ubuntu:22.04 ubuntu:24.04 debian:12 alpine:3.19; do
  d="${t%%:*}"; r="${t##*:}"
  lxc-create -n "tpl-cache-${d}-${r}" -t download -- -d "$d" -r "$r" -a amd64 >/dev/null 2>&1 \
    && lxc-destroy -n "tpl-cache-${d}-${r}" -f >/dev/null 2>&1 \
    && ok "cached $t" || warn "could not cache $t (will download at first deploy)"
done

# ---------- 7. Smoke test ----------
info "Running a smoke-test container..."
if lxc-create -n deup-selftest -t download -- -d ubuntu -r 22.04 -a amd64 >/dev/null 2>&1; then
  lxc-start -n deup-selftest 2>/dev/null || true
  sleep 3
  if lxc-info -n deup-selftest -sH 2>/dev/null | grep -qi RUNNING; then
    ok "Smoke test PASSED — container boots"
  else
    warn "Container created but not running (check: lxc-info -n deup-selftest)"
  fi
  lxc-stop -n deup-selftest 2>/dev/null || true
  lxc-destroy -n deup-selftest -f >/dev/null 2>&1 || true
else
  warn "Smoke test container creation failed — check /var/log/lxc/"
fi

# ---------- 8. Instructions ----------
PANEL_PUBKEY=$(echo "")
IP=$(curl -s --max-time 5 ifconfig.me || hostname -I | awk '{print $1}')
echo
echo "=========================================="
echo -e "${GREEN}LXC HOST READY${NC}"
echo "=========================================="
cat <<EOF

Next steps — connect the panel to THIS machine:

1. On the PANEL VPS, generate an SSH key for the panel (if you don't
   already have one):

       ssh-keygen -t ed25519 -f /root/.ssh/id_ed25519 -N ""

2. Authorize it HERE (on this LXC host) — run this on the PANEL VPS:

       ssh-copy-id root@${IP}

   ...or manually append the panel's /root/.ssh/id_ed25519.pub to
   this host's /root/.ssh/authorized_keys.

3. Test from the PANEL VPS (must work without a password prompt):

       ssh -o BatchMode=yes root@${IP} 'lxc-ls'

4. In the panel:  Admin → Nodes → Add Node
       Provider:      LXC (native containers)
       API Endpoint:  root@${IP}
       Capacities:    set to this machine's real cores/RAM/disk

5. Deploy a VPS from the wizard — it will run lxc-create here.

Container networking: containers get static IPs 10.10.0.10+ on br0
with NAT outbound. To expose ports (e.g. SSH 22) to the internet,
add on this host:

       iptables -t nat -A PREROUTING -p tcp --dport 2222 \\
         -j DNAT --to 10.10.0.10:22
EOF
echo
ok "Done."
