// Verify the NEW mutation retry behavior introduced for the deploy fix:
// a deploy-style POST that hits proxy 502s while the dev server restarts/
// recompiles must retry through the full ~4s ladder and succeed, while
// possibly-executed failures (HTML 500 crash page) keep the single retry.
import { api } from '../src/lib/frontend/api';

const results: string[] = [];
function check(name: string, ok: boolean) {
  results.push(`${ok ? 'OK  ' : 'FAIL'} ${name}`);
}

const hitCounts: Record<string, number> = {};

const server = Bun.serve({
  port: 3998,
  fetch(req) {
    const url = new URL(req.url);
    const hits = (hitCounts[url.pathname] = (hitCounts[url.pathname] || 0) + 1);

    // The user's exact scenario: deploy POST while server restarts.
    // 3 proxy-level 502 HTML pages (~2s of downtime), THEN the app answers.
    if (url.pathname === '/deploy-restart') {
      if (hits <= 3) return new Response('<html>502 Bad Gateway</html>', { status: 502, headers: { 'content-type': 'text/html' } });
      return Response.json({ success: true, data: { vpsId: 'vps_123', jobId: 'job_1' } });
    }

    // Network-level refusal (server fully down for 2 attempts), then up
    if (url.pathname === '/deploy-down') {
      if (hits <= 2) return new Response('<html>connection refused</html>', { status: 502 });
      return Response.json({ success: true, data: { vpsId: 'vps_456' } });
    }

    // HTML 500 crash page (request MAY have executed) — single retry only.
    // After 2 hits we still return HTML 500: must give up after exactly 2 attempts.
    if (url.pathname === '/crash-500') {
      return new Response('<html>500 Internal Server Error</html>', { status: 500 });
    }

    // App-level JSON error — never retried, code preserved (unchanged rule)
    if (url.pathname === '/app-error') {
      return Response.json({ success: false, error: 'NODE_CPU_FULL' }, { status: 400 });
    }

    return new Response(null, { status: 404 });
  },
});

async function main() {
  const base = 'http://localhost:3998';

  // 1. Deploy POST survives 3 consecutive proxy 502s (~2.2s) and succeeds
  const t0 = Date.now();
  const r1 = await api.post(`${base}/deploy-restart`, { anything: 1 });
  const dt = Date.now() - t0;
  check(`deploy POST survives server restart (3x 502) — got vpsId ${r1?.data?.vpsId}`, r1.success === true && r1?.data?.vpsId === 'vps_123');
  check(`retried through the backoff ladder (took ${dt}ms, expected >1800ms)`, dt >= 1800 && dt < 10000);
  check(`exactly 4 attempts made (got ${hitCounts['/deploy-restart']})`, hitCounts['/deploy-restart'] === 4);

  // 2. Network-refused style failures also extend the ladder
  const r2 = await api.post(`${base}/deploy-down`, {});
  check(`deploy POST survives 2x downtime then succeeds`, r2.success === true && r2?.data?.vpsId === 'vps_456');

  // 3. HTML 500 crash page — conservative: exactly 2 attempts, then error
  const r3 = await api.post(`${base}/crash-500`, {});
  check(`HTML 500 crash page: gives up after single retry (attempts=${hitCounts['/crash-500']})`, hitCounts['/crash-500'] === 2);
  check(`HTML 500 crash page: returns SERVICE_UNAVAILABLE`, r3.error === 'SERVICE_UNAVAILABLE');

  // 4. App-level JSON errors still never retried
  const r4 = await api.post(`${base}/app-error`, {});
  check(`app JSON error not retried (attempts=${hitCounts['/app-error']}), code preserved`, hitCounts['/app-error'] === 1 && r4.error === 'NODE_CPU_FULL');

  server.stop(true);
  console.log(results.join('\n'));
  const fails = results.filter(r => r.startsWith('FAIL')).length;
  console.log(`\n${results.length - fails}/${results.length} checks passed`);
  process.exit(fails ? 1 : 0);
}

main();
