// Test the login race fix: a stale 401 arriving AFTER a successful login
// must NOT log the user out. And a real session expiry MUST log them out.
const realFetch = globalThis.fetch;

// Bun's fetch can't resolve relative URLs — resolve them against the test server.
const BASE = 'http://localhost:3998';
(globalThis as any).fetch = (input: any, init?: any) => {
  const url = typeof input === 'string' && input.startsWith('/') ? `${BASE}${input}` : input;
  return realFetch(url, init);
};

// Patch localStorage (Bun may not have it)
if (!(globalThis as any).localStorage) {
  const store = new Map<string, string>();
  (globalThis as any).localStorage = {
    getItem: (k: string) => store.get(k) ?? null,
    setItem: (k: string, v: string) => store.set(k, v),
    removeItem: (k: string) => store.delete(k),
  };
}

// Import AFTER patches
const { api } = await import('../src/lib/frontend/api');
const { useAppStore } = await import('../src/lib/frontend/store');

const results: string[] = [];
function check(name: string, ok: boolean) {
  results.push(`${ok ? 'OK  ' : 'FAIL'} ${name}`);
}

// Toggle: does the (re-verification) /api/auth/me call see a valid session?
let meEndpointReturnsUser = true;
let meCallCount = 0;

const server = Bun.serve({
  port: 3998,
  fetch(req) {
    const url = new URL(req.url);
    if (url.pathname === '/api/auth/me') {
      meCallCount++;
      if (meEndpointReturnsUser) {
        return Response.json({ success: true, user: { id: 'u1', email: 'a@b.c', role: 'ADMIN' } });
      }
      return Response.json({ success: false, error: 'UNAUTHENTICATED' }, { status: 401 });
    }
    if (url.pathname === '/old-poll') {
      // A stale 401 from a poll that fired BEFORE the user logged back in
      return Response.json({ success: false, error: 'UNAUTHENTICATED' }, { status: 401 });
    }
    return new Response(null, { status: 404 });
  },
});

// Simulate logged-in state (user just logged in successfully)
useAppStore.setState({ user: { id: 'u1', email: 'a@b.c', username: 'a', name: 'A', role: 'ADMIN', emailVerified: true, status: 'ACTIVE' } as any, loading: false });

// 1. STALE 401 race: me() says session is valid → user must STAY logged in
let r = await api.get('/old-poll');
await new Promise(res => setTimeout(res, 100)); // let async handler settle
check('stale 401 returns UNAUTHENTICATED', r.error === 'UNAUTHENTICATED');
check('RACE FIX: user stays logged in after stale 401', useAppStore.getState().user !== null);
check('re-verified with /api/auth/me', meCallCount === 1);

// 2. REAL expiry: me() also 401s → user must be logged out
meEndpointReturnsUser = false;
useAppStore.setState({ user: { id: 'u1', email: 'a@b.c', username: 'a', name: 'A', role: 'ADMIN', emailVerified: true, status: 'ACTIVE' } as any, loading: false });
r = await api.get('/old-poll');
await new Promise(res => setTimeout(res, 100));
check('real expiry: user logged out', useAppStore.getState().user === null);

// 3. Parallel 401s dedupe to a single me() re-check
meCallCount = 0;
meEndpointReturnsUser = true;
useAppStore.setState({ user: { id: 'u1', email: 'a@b.c', username: 'a', name: 'A', role: 'ADMIN', emailVerified: true, status: 'ACTIVE' } as any, loading: false });
await Promise.all([api.get('/old-poll'), api.get('/old-poll'), api.get('/old-poll')]);
await new Promise(res => setTimeout(res, 100));
check('3 parallel 401s → deduped (≤2 me() checks)', meCallCount <= 2);
check('user still logged in (valid session)', useAppStore.getState().user !== null);

server.stop(true);

console.log(results.join('\n'));
const fails = results.filter(x => x.startsWith('FAIL')).length;
console.log(`\n${results.length - fails}/${results.length} checks passed`);
process.exit(fails ? 1 : 0);
