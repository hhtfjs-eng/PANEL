// List all users with role/status and test password verification for staff accounts.
import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const db = new PrismaClient();

async function main() {
  const users = await db.user.findMany({
    select: {
      id: true, name: true, username: true, email: true,
      role: true, status: true, emailVerified: true,
      passwordHash: true, lastLogin: true, createdAt: true,
    },
    orderBy: { createdAt: 'asc' },
  });
  for (const u of users) {
    const hashLooksValid = typeof u.passwordHash === 'string' && u.passwordHash.startsWith('$2');
    console.log(
      `· ${u.name} (@${u.username}) <${u.email}> role=${u.role} status=${u.status} verified=${u.emailVerified} bcryptHash=${hashLooksValid} lastLogin=${u.lastLogin?.toISOString?.() ?? 'never'} created=${u.createdAt.toISOString()}`
    );
  }
  // Also list custom roles from the Role Editor
  const roles = await db.role.findMany();
  console.log('\nCustom roles:', JSON.stringify(roles.map(r => ({ key: r.key, isSystem: r.isSystem })), null, 2));
}

main().catch(console.error).finally(() => db.$disconnect());
