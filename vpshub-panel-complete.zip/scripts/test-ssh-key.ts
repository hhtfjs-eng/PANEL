// Quick test of the SSH keypair generator
import { generateSshKeyPair } from '../src/lib/auth';

const { publicKey, fingerprint } = generateSshKeyPair('web-prod-01');
console.log('publicKey:', publicKey);
console.log('fingerprint:', fingerprint);

// Sanity checks
const [algo, b64, comment] = publicKey.split(' ');
console.log('\nchecks:');
console.log('algorithm:', algo === 'ssh-ed25519' ? 'OK' : 'FAIL');
console.log('base64 length:', b64.length >= 68 ? 'OK' : 'FAIL');
console.log('comment:', comment === 'web-prod-01' ? 'OK' : 'FAIL');
console.log('fingerprint format:', /^SHA256:[A-Za-z0-9+/]{43}$/.test(fingerprint) ? 'OK' : 'FAIL');

// Two calls must produce different keys
const k2 = generateSshKeyPair('other');
console.log('unique keys:', k2.publicKey !== publicKey ? 'OK' : 'FAIL');

// Base64 must decode to valid ssh wire format
const buf = Buffer.from(b64, 'base64');
const nameLen = buf.readUInt32BE(0);
const name = buf.subarray(4, 4 + nameLen).toString();
const rawLen = buf.readUInt32BE(4 + nameLen);
console.log('wire format:', name === 'ssh-ed25519' && rawLen === 32 && buf.length === 4 + nameLen + 4 + 32 ? 'OK' : 'FAIL');
