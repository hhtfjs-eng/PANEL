// E2E for main-19: role management + staff creation validation.
import { PrismaClient } from '@prisma/client';
const db = new PrismaClient();
const BASE = 'http://localhost:3000';
let PASS = 0, FAIL = 0;

// Idempotency: remove test users + make sure the owner keeps SUPER_ADMIN.
async function resetState() {
  for (const email of ['roletester@t.local', 'plainadmin@t.local', 'badpass1@t.local', 'baduser@t.local', 'badmail1@t.local', 'teststaffer@t.local']) {
    await db.user.deleteMany({ where: { email } });
  }
  await db.user.updateMany({ where: { email: 'nøctis@gmail.com' }, data: { role: 'SUPER_ADMIN', status: 'ACTIVE' } });
  await db.notification.deleteMany({ where: { type: 'ROLE_CHANGED' } });
  await db.auditLog.deleteMany({ where: { action: 'USER_ROLE_CHANGED' } });
}

async function api(method: string, path: string, body?: any, cookie?: string) {
  const res = await fetch(BASE + path, {
    method,
    headers: { 'Content-Type': 'application/json', ...(cookie ? { Cookie: cookie } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  const setCookie = res.headers.get('set-cookie');
  let json: any = null;
  try { json = await res.json(); } catch { /* no body */ }
  return { status: res.status, json, cookie: setCookie ? setCookie.split(';')[0] : undefined };
}

function check(name: string, cond: boolean, extra?: any) {
  if (cond) { PASS++; console.log(`  ✓ ${name}`); }
  else { FAIL++; console.log(`  ✗ ${name}${extra !== undefined ? ' — ' + JSON.stringify(extra) : ''}`); }
}

async function main() {
  await resetState();
  console.log('\n── 1. Staff creation validation ──');
  const login = await api('POST', '/api/auth/login', { email: 'nøctis@gmail.com', password: '123' });
  const superCookie = login.cookie!;
  check('super admin login', login.status === 200);

  // short password → specific error
  let r = await api('POST', '/api/admin/staff', { name: 'Bad Pass', username: 'badpass1', email: 'badpass1@t.local', role: 'STAFF', password: '123' }, superCookie);
  check('short password → 400 PASSWORD_TOO_SHORT', r.status === 400 && r.json?.error === 'PASSWORD_TOO_SHORT', r.json);

  // bad username
  r = await api('POST', '/api/admin/staff', { name: 'Bad User', username: 'bad.user!', email: 'baduser@t.local', role: 'STAFF', password: 'password123' }, superCookie);
  check('bad username → 400 USERNAME_INVALID', r.status === 400 && r.json?.error === 'USERNAME_INVALID', r.json);

  // bad email
  r = await api('POST', '/api/admin/staff', { name: 'Bad Mail', username: 'badmail1', email: 'not-an-email', role: 'STAFF', password: 'password123' }, superCookie);
  check('bad email → 400 EMAIL_INVALID', r.status === 400 && r.json?.error === 'EMAIL_INVALID', r.json);

  // unauthenticated
  r = await api('POST', '/api/admin/staff', { name: 'X', username: 'xxxxxxx', email: 'x@t.local', role: 'STAFF', password: 'password123' });
  check('staff create w/o auth → 401', r.status === 401);

  console.log('\n── 2. Create staff properly → login works ──');
  r = await api('POST', '/api/admin/staff', { name: 'Role Tester', username: 'roletester', email: 'roletester@t.local', role: 'SUPPORT', password: 'password123' }, superCookie);
  check('valid staff created (SUPPORT)', r.status === 200 && r.json?.success, r.json);
  const testerId = r.json?.data?.id;

  const staffLogin = await api('POST', '/api/auth/login', { email: 'roletester@t.local', password: 'password123' });
  check('new staff CAN log in', staffLogin.status === 200 && staffLogin.json?.user?.role === 'SUPPORT', staffLogin.json?.error);
  check('login by username also works', (await api('POST', '/api/auth/login', { email: 'roletester', password: 'password123' })).status === 200);

  console.log('\n── 3. Role management ──');
  // promote SUPPORT → STAFF
  r = await api('PATCH', `/api/admin/users/${testerId}`, { role: 'STAFF' }, superCookie);
  check('SUPPORT → STAFF promoted', r.status === 200 && r.json?.success, r.json);

  // verify DB + immediate effect on the user's next request
  const meAfter = await api('GET', '/api/auth/me', undefined, staffLogin.cookie);
  check('role visible immediately on /me', meAfter.json?.user?.role === 'STAFF', meAfter.json?.user?.role);
  check('permissions upgraded (vps.create now present)', (meAfter.json?.permissions || []).includes('vps.create'));

  // demote back → USER
  r = await api('PATCH', `/api/admin/users/${testerId}`, { role: 'USER' }, superCookie);
  check('STAFF → USER demoted', r.status === 200);
  const meAfter2 = await api('GET', '/api/auth/me', undefined, staffLogin.cookie);
  check('demotion immediate, provisioning perms gone', meAfter2.json?.user?.role === 'USER' && !(meAfter2.json?.permissions || []).includes('vps.create'));

  // notification created for target
  const notifs = await api('GET', '/api/customer/notifications', undefined, staffLogin.cookie);
  check('target got ROLE_CHANGED notification', (notifs.json?.data || []).some((n: any) => n.type === 'ROLE_CHANGED'));

  console.log('\n── 4. Role change guards ──');
  // self role change
  const noctisId = login.json?.user?.id;
  r = await api('PATCH', `/api/admin/users/${noctisId}`, { role: 'USER' }, superCookie);
  check('self role change → 400 CANNOT_CHANGE_OWN_ROLE', r.status === 400 && r.json?.error === 'CANNOT_CHANGE_OWN_ROLE', r.json);

  // invalid role key
  r = await api('PATCH', `/api/admin/users/${testerId}`, { role: 'HACKER_ADMIN' }, superCookie);
  check('unknown role → 400 INVALID_ROLE', r.status === 400 && r.json?.error === 'INVALID_ROLE', r.json);

  // non-privileged user can't change roles
  const custLogin = await api('POST', '/api/auth/login', { email: 'roletester@t.local', password: 'password123' });
  r = await api('PATCH', `/api/admin/users/${noctisId}`, { role: 'USER' }, custLogin.cookie);
  check('regular user changing roles → 403', r.status === 403, r.json);

  // STAFF (has users.edit but NOT staff.manage) can't grant roles
  await api('PATCH', `/api/admin/users/${testerId}`, { role: 'STAFF' }, superCookie);
  const staffSess = await api('POST', '/api/auth/login', { email: 'roletester@t.local', password: 'password123' });
  r = await api('PATCH', `/api/admin/users/${noctisId}`, { role: 'STAFF' }, staffSess.cookie);
  check('STAFF w/ users.edit cannot grant roles → 403', r.status === 403, r.json);
  // but STAFF can still edit profile fields (name) — existing behavior preserved
  r = await api('PATCH', `/api/admin/users/${testerId}`, { name: 'Role Tester II' }, staffSess.cookie);
  check('users.edit still works for name (no role in body)', r.status === 200, r.json);

  console.log('\n── 5. SUPER_ADMIN protection ──');
  // create an ADMIN, who has staff.manage but is not SUPER_ADMIN
  r = await api('POST', '/api/admin/staff', { name: 'Plain Admin', username: 'plainadmin', email: 'plainadmin@t.local', role: 'ADMIN', password: 'password123' }, superCookie);
  const adminId = r.json?.data?.id;
  const adminLogin = await api('POST', '/api/auth/login', { email: 'plainadmin@t.local', password: 'password123' });
  check('ADMIN staff created + can login', adminLogin.status === 200 && adminLogin.json?.user?.role === 'ADMIN');

  // ADMIN trying to assign SUPER_ADMIN → 403
  r = await api('PATCH', `/api/admin/users/${testerId}`, { role: 'SUPER_ADMIN' }, adminLogin.cookie);
  check('ADMIN assigning SUPER_ADMIN → 403 ROLE_CHANGE_FORBIDDEN', r.status === 403 && r.json?.error === 'ROLE_CHANGE_FORBIDDEN', r.json);

  // ADMIN trying to change a SUPER_ADMIN account → 403
  r = await api('PATCH', `/api/admin/users/${noctisId}`, { role: 'STAFF' }, adminLogin.cookie);
  check('ADMIN touching SUPER_ADMIN account → 403', r.status === 403 && r.json?.error === 'ROLE_CHANGE_FORBIDDEN', r.json);

  // ADMIN CAN assign STAFF (normal op)
  await api('PATCH', `/api/admin/users/${testerId}`, { role: 'USER' }, superCookie);
  r = await api('PATCH', `/api/admin/users/${testerId}`, { role: 'STAFF' }, adminLogin.cookie);
  check('ADMIN assigning STAFF works', r.status === 200, r.json);

  // SUPER_ADMIN CAN assign SUPER_ADMIN
  r = await api('PATCH', `/api/admin/users/${testerId}`, { role: 'SUPER_ADMIN' }, superCookie);
  check('SUPER_ADMIN assigning SUPER_ADMIN works', r.status === 200, r.json);

  console.log('\n── 6. Audit trail ──');
  const audit = await api('GET', '/api/admin/audit?pageSize=200', undefined, superCookie);
  const entries = audit.json?.data || [];
  const roleAudits = entries.filter((a: any) => a.action === 'USER_ROLE_CHANGED');
  check('USER_ROLE_CHANGED audit entries exist', roleAudits.length >= 4, roleAudits.length);
  const sample = roleAudits[0];
  check('audit metadata has from/to', sample && sample.metadata && JSON.parse(sample.metadata).from && JSON.parse(sample.metadata).to, sample?.metadata);

  console.log(`\n═══════ RESULT: ${PASS} passed, ${FAIL} failed ═══════`);
  const failed = FAIL > 0;
  await cleanup();
  process.exit(failed ? 1 : 0);
}

// Remove all test users; keep the three real accounts intact.
async function cleanup() {
  for (const email of ['roletester@t.local', 'plainadmin@t.local', 'teststaffer@t.local']) {
    await db.user.deleteMany({ where: { email } });
  }
  await db.user.updateMany({ where: { email: 'nøctis@gmail.com' }, data: { role: 'SUPER_ADMIN', status: 'ACTIVE' } });
  await db.notification.deleteMany({ where: { type: 'ROLE_CHANGED' } });
  await db.$disconnect();
}

main().catch(e => { console.error('FATAL', e); process.exit(1); });
