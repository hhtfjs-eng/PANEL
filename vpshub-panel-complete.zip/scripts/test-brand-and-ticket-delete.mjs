/**
 * Smoke test: branding settings + ticket delete (admin + customer paths).
 * Run with node against localhost:3000.
 */
const BASE = 'http://localhost:3000';

async function j(method, path, body, cookie) {
  const res = await fetch(BASE + path, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(cookie ? { Cookie: cookie } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  let data = null;
  try { data = JSON.parse(text); } catch { data = { raw: text.slice(0, 80) }; }
  return { status: res.status, data, setCookie: res.headers.get('set-cookie') };
}

let pass = 0, fail = 0;
function check(name, cond, extra = '') {
  if (cond) { pass++; console.log(`  PASS  ${name}`); }
  else { fail++; console.log(`  FAIL  ${name} ${extra}`); }
}

(async () => {
  // 1. Public settings expose the new branding keys
  console.log('1) Public settings');
  const s = await j('GET', '/api/settings');
  check('GET /api/settings 200', s.status === 200);
  // Updated expectations to match the user's specific channel URLs (main-13 round)
  check('site.youtube_url present', s.data?.data?.['site.youtube_url'] === 'https://www.youtube.com/channel/UCILvOqZhASpc_Pk0ULdrKUQ');
  check('site.discord_url present', s.data?.data?.['site.discord_url'] === 'https://discord.com');
  check('site.watermark_text present (empty by design — global watermark removed)', s.data?.data?.['site.watermark_text'] === '');
  check('site.owner_credit present', s.data?.data?.['site.owner_credit'] === 'Made by YT');

  // 2. Login as super admin
  console.log('2) Login');
  const login = await j('POST', '/api/auth/login', { email: 'nøctis@gmail.com', password: '123' });
  check('login ok', login.status === 200 && login.data?.success, JSON.stringify(login.data).slice(0, 120));
  const cookie = (login.setCookie || '').split(';')[0];
  check('cookie captured', !!cookie);

  // 3. Create a ticket (customer API works for any authenticated user)
  console.log('3) Create ticket');
  const create = await j('POST', '/api/customer/support', {
    subject: 'Delete-button smoke test',
    category: 'general',
    priority: 'normal',
    message: 'testing the new delete button',
  }, cookie);
  check('ticket created', create.status === 200 || create.status === 201, JSON.stringify(create.data).slice(0, 160));
  const ticketId = create.data?.data?.id || create.data?.id;
  check('ticketId present', !!ticketId);

  // 4. Admin list shows it
  console.log('4) Admin sees ticket');
  const list = await j('GET', '/api/admin/support', null, cookie);
  check('ticket in admin list', (list.data?.data || []).some(t => t.id === ticketId));

  // 5. Admin DELETE
  console.log('5) Admin delete');
  const del = await j('DELETE', `/api/admin/support/${ticketId}`, null, cookie);
  check('admin DELETE 200', del.status === 200 && del.data?.success, JSON.stringify(del.data).slice(0, 160));

  // 6. Gone from list + detail 404
  const list2 = await j('GET', '/api/admin/support', null, cookie);
  check('ticket gone from list', !(list2.data?.data || []).some(t => t.id === ticketId));
  const detail = await j('GET', `/api/admin/support/${ticketId}`, null, cookie);
  check('detail 404', detail.status === 404);

  // 7. Customer-side delete (own ticket)
  console.log('6) Customer-side delete');
  const c2 = await j('POST', '/api/customer/support', {
    subject: 'Customer delete test',
    category: 'general',
    priority: 'low',
    message: 'customer deletes own ticket',
  }, cookie);
  const tid2 = c2.data?.data?.id || c2.data?.id;
  check('second ticket created', !!tid2);
  const del2 = await j('DELETE', `/api/customer/support/${tid2}`, null, cookie);
  check('customer DELETE 200', del2.status === 200 && del2.data?.success, JSON.stringify(del2.data).slice(0, 160));
  const detail2 = await j('GET', `/api/customer/support/${tid2}`, null, cookie);
  check('customer detail 404', detail2.status === 404);

  // 8. Unauthenticated delete rejected
  console.log('7) Auth guard');
  const noauth = await j('DELETE', `/api/admin/support/${tid2}`);
  check('unauth admin DELETE 401', noauth.status === 401);

  console.log(`\n${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error('FATAL', e); process.exit(1); });
