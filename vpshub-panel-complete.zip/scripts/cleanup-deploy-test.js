// Cleanup helper — delete the test VPS created during deploy-restart testing
const { PrismaClient } = require('@prisma/client');
const db = new PrismaClient();

async function main() {
  const v = await db.vps.findFirst({ where: { name: 'deploy-restart-test' } });
  if (!v) { console.log('no test VPS found'); return; }
  // cascade-related rows — use try/catch per call (model may not exist on this schema)
  const safeDelete = (model, where) => {
    if (!db[model] || typeof db[model].deleteMany !== 'function') return Promise.resolve(null);
    return db[model].deleteMany({ where }).catch(() => null);
  };
  await safeDelete('deploymentJob', { vpsId: v.id });
  await safeDelete('vpsActivity', { vpsId: v.id });
  await safeDelete('vpsMetric', { vpsId: v.id });
  await safeDelete('consoleSession', { vpsId: v.id });
  await safeDelete('vpsStateHistory', { vpsId: v.id });
  await safeDelete('notification', { userId: v.ownerId });
  try { await db.vps.delete({ where: { id: v.id } }); console.log('deleted', v.id); }
  catch (e) { console.log('vps delete err:', e.message); }
}

main().catch(e => { console.error(e); process.exit(1); }).finally(() => db.$disconnect());
