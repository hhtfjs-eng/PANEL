// Quick test script to debug the seed endpoint
const r = await fetch('http://localhost:3000/api/seed', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
});
console.log('status:', r.status);
console.log('content-type:', r.headers.get('content-type'));
const text = await r.text();
console.log('body (first 500 chars):', text.slice(0, 500));
