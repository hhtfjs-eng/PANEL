#!/bin/bash
# Customer-side deletion visibility test with a fresh account
set -u
BASE="http://localhost:3000"
ADMIN_CJ=$(mktemp); CUST_CJ=$(mktemp)
J() { python3 -c "import sys,json; d=json.load(sys.stdin); print($1)" 2>/dev/null; }
PASS=0; FAIL=0
ok()  { PASS=$((PASS+1)); echo "  PASS: $1"; }
bad() { FAIL=$((FAIL+1)); echo "  FAIL: $1"; }

curl -s -c "$ADMIN_CJ" -X POST "$BASE/api/auth/login" -H 'Content-Type: application/json' \
  -d '{"identifier":"nøctis@gmail.com","password":"123"}' > /dev/null

# register a fresh customer
REG=$(curl -s -c "$CUST_CJ" -X POST "$BASE/api/auth/register" -H 'Content-Type: application/json' \
  -d '{"name":"Del Tester","username":"deltester","email":"deltester@example.com","password":"testpass123","confirmPassword":"testpass123"}')
CUST_ID=$(echo "$REG" | J "d['user']['id']")
echo "cust=$CUST_ID"

NODE=$(curl -s -b "$ADMIN_CJ" "$BASE/api/admin/nodes" | J "d['data'][0]['id']")
OS=$(curl -s -b "$ADMIN_CJ" "$BASE/api/admin/os" | J "d['data'][0]['id']")

VPS=$(curl -s -b "$ADMIN_CJ" -X POST "$BASE/api/admin/vps" -H 'Content-Type: application/json' \
  -d "{\"ownerId\":\"$CUST_ID\",\"name\":\"cust-del-test\",\"hostname\":\"cust-del-test\",\"cpu\":1,\"ramMb\":512,\"diskGb\":10,\"bandwidthMbps\":10,\"nodeId\":\"$NODE\",\"osId\":\"$OS\"}" | J "d['data']['vpsId']")
echo "vps=$VPS"

# customer sees it
SEEN=$(curl -s -b "$CUST_CJ" "$BASE/api/customer/vps" | J "'FOUND' if any(v['id']=='$VPS' for v in d['data']) else 'ABSENT'")
[ "$SEEN" = "FOUND" ] && ok "customer sees live VPS" || bad "customer cannot see live VPS"

# admin deletes it
curl -s -b "$ADMIN_CJ" -X DELETE "$BASE/api/admin/vps/$VPS" > /dev/null

# customer: gone from list
SEEN2=$(curl -s -b "$CUST_CJ" "$BASE/api/customer/vps" | J "'FOUND' if any(v['id']=='$VPS' for v in d['data']) else 'ABSENT'")
[ "$SEEN2" = "ABSENT" ] && ok "customer list: deleted VPS absent" || bad "customer list still shows deleted VPS"

# customer: GET 404
CGET=$(curl -s -o /dev/null -w "%{http_code}" -b "$CUST_CJ" "$BASE/api/customer/vps/$VPS")
[ "$CGET" = "404" ] && ok "customer GET deleted -> 404" || bad "customer GET returned $CGET"

# customer: power on deleted -> 404
CPOW=$(curl -s -o /dev/null -w "%{http_code}" -b "$CUST_CJ" -X POST "$BASE/api/customer/vps/$VPS/start")
[ "$CPOW" = "404" ] && ok "customer power on deleted -> 404" || bad "customer power returned $CPOW"

# admin GET still 200 (audit)
AGET=$(curl -s -o /dev/null -w "%{http_code}" -b "$ADMIN_CJ" "$BASE/api/admin/vps/$VPS")
[ "$AGET" = "200" ] && ok "admin GET deleted -> 200 (audit)" || bad "admin GET returned $AGET"

# cleanup: VPS + user + notifications
python3 - <<EOF
import sqlite3
c = sqlite3.connect('/home/z/my-project/db/custom.db')
c.execute('DELETE FROM VpsMetric WHERE vpsId=?', ('$VPS',))
c.execute('DELETE FROM VpsActivity WHERE vpsId=?', ('$VPS',))
c.execute('DELETE FROM DeploymentStep WHERE jobId IN (SELECT id FROM DeploymentJob WHERE vpsId=?)', ('$VPS',))
c.execute('DELETE FROM DeploymentJob WHERE vpsId=?', ('$VPS',))
c.execute('DELETE FROM Vps WHERE id=?', ('$VPS',))
c.execute('DELETE FROM Notification WHERE userId=?', ('$CUST_ID',))
c.execute('DELETE FROM AuditLog WHERE actorId=?', ('$CUST_ID',))
c.execute('DELETE FROM User WHERE id=?', ('$CUST_ID',))
c.commit()
print('  purged')
EOF
echo "RESULT: $PASS passed, $FAIL failed"
[ "$FAIL" = "0" ]
