/**
 * Cleanup script:
 * 1. Restore the owner's super-admin account: NØCTIS / nøctis@gmail.com / 123
 *    (it was wiped by a re-seed — root cause of "can't login with nøctis@gmail.com")
 * 2. Delete the demo seed accounts (admin@/staff@/customer@vps-platform.local)
 *    and all their data (demo VPS web-prod-01, notifications, tickets, audit logs)
 * 3. Purge any legacy soft-deleted VPS rows (status = 'DELETED') left by the old
 *    soft-delete bug, releasing their IPs back to the pool
 * 4. Print final state for verification
 */
const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const db = new PrismaClient();

const DEMO_EMAILS = [
  'admin@vps-platform.local',
  'staff@vps-platform.local',
  'customer@vps-platform.local',
];

async function main() {
  // ---------- 1. Restore NØCTIS super admin ----------
  const passwordHash = await bcrypt.hash('123', 10);
  const noctis = await db.user.upsert({
    where: { email: 'nøctis@gmail.com' },
    update: {
      name: 'NØCTIS',
      username: 'noctis',
      role: 'SUPER_ADMIN',
      status: 'ACTIVE',
      emailVerified: true,
    },
    create: {
      name: 'NØCTIS',
      username: 'noctis',
      email: 'nøctis@gmail.com',
      passwordHash,
      role: 'SUPER_ADMIN',
      status: 'ACTIVE',
      emailVerified: true,
    },
  });
  console.log('✓ Super admin restored:', noctis.email, noctis.role, noctis.status);

  // ---------- 2. Delete demo accounts + their data ----------
  const demoUsers = await db.user.findMany({ where: { email: { in: DEMO_EMAILS } } });
  const demoIds = demoUsers.map(u => u.id);

  if (demoIds.length > 0) {
    // Delete VPS owned/assigned to demo users (cascades: metrics, activity, jobs, console sessions)
    const demoVps = await db.vps.findMany({
      where: { OR: [{ ownerId: { in: demoIds } }, { assignedToId: { in: demoIds } }] },
      select: { id: true, name: true },
    });
    for (const v of demoVps) {
      await db.ipAddress.updateMany({
        where: { vpsId: v.id },
        data: { state: 'AVAILABLE', vpsId: null },
      });
      await db.vps.delete({ where: { id: v.id } });
      console.log('✓ Deleted demo VPS:', v.name);
    }

    // Reassign stray VPS that might reference demo users as owner but owned by others (safety)
    await db.vps.updateMany({ where: { assignedToId: { in: demoIds } }, data: { assignedToId: null } });

    // Delete audit logs / notifications / tickets referencing demo users
    await db.auditLog.deleteMany({ where: { OR: [{ actorId: { in: demoIds } }, { targetId: { in: demoIds } }] } });
    await db.notification.deleteMany({ where: { userId: { in: demoIds } } });
    await db.supportTicket.deleteMany({ where: { OR: [{ userId: { in: demoIds } }, { assignedToId: { in: demoIds } }] } });

    // Delete the demo users themselves
    await db.user.deleteMany({ where: { id: { in: demoIds } } });
    console.log(`✓ Deleted ${demoIds.length} demo accounts:`, DEMO_EMAILS.join(', '));
  } else {
    console.log('• No demo accounts found (already clean)');
  }

  // ---------- 3. Purge legacy soft-deleted VPS rows ----------
  const legacyDeleted = await db.vps.findMany({ where: { status: 'DELETED' }, select: { id: true, name: true } });
  for (const v of legacyDeleted) {
    await db.ipAddress.updateMany({
      where: { vpsId: v.id },
      data: { state: 'AVAILABLE', vpsId: null },
    });
    await db.vps.delete({ where: { id: v.id } });
    console.log('✓ Purged legacy soft-deleted VPS row:', v.name);
  }

  // ---------- 4. Final state ----------
  const users = await db.user.findMany({
    select: { email: true, username: true, name: true, role: true, status: true },
    orderBy: { createdAt: 'asc' },
  });
  const vpsCount = await db.vps.count();
  const availableIps = await db.ipAddress.count({ where: { state: 'AVAILABLE' } });
  console.log('\n=== FINAL STATE ===');
  console.log('Users:');
  for (const u of users) console.log(`  ${u.email} (${u.username}) — ${u.role} / ${u.status}`);
  console.log(`VPS remaining: ${vpsCount}`);
  console.log(`Available IPs: ${availableIps}`);
}

main()
  .catch(e => { console.error('FAILED:', e); process.exit(1); })
  .finally(() => db.$disconnect());
