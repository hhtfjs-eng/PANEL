// Seed owner branding settings (idempotent — never overwrites values the
// admin has already customized). Defaults make the buttons + watermark + credit
// visible immediately; everything is editable in Settings → Branding & Links.
const { PrismaClient } = require('@prisma/client');
const db = new PrismaClient();

const DEFAULTS = {
  'site.youtube_url': 'https://www.youtube.com/',
  'site.discord_url': 'https://discord.com/',
  'site.watermark_text': 'YT',
  'site.owner_credit': 'Made by YT',
};

(async () => {
  for (const [key, value] of Object.entries(DEFAULTS)) {
    const existing = await db.setting.findUnique({ where: { key } });
    if (!existing) {
      await db.setting.create({ data: { key, value } });
      console.log(`created  ${key} = ${value}`);
    } else {
      console.log(`kept     ${key} = ${existing.value}`);
    }
  }
  const all = await db.setting.findMany({ where: { key: { startsWith: 'site.' } } });
  console.log('\nSite settings now:', all.map(s => `${s.key}=${s.value}`).join(', '));
  await db.$disconnect();
})().catch(e => { console.error(e); process.exit(1); });
