(() => {
  const wm = [...document.querySelectorAll('p')].find(p => p.textContent.includes('made by'));
  const aside = document.querySelector('aside');
  const asideStyle = aside ? getComputedStyle(aside) : null;
  const infraLabel = [...document.querySelectorAll('p')].find(p => p.textContent.trim() === 'Infrastructure Overview');
  return JSON.stringify({
    watermarkFound: !!wm,
    watermarkText: wm ? wm.textContent.trim() : null,
    wmInSidebar: !!(wm && aside && aside.contains(wm)),
    wmAboveInfraLabel: wm && infraLabel ? !!(wm.compareDocumentPosition(infraLabel) & Node.DOCUMENT_POSITION_FOLLOWING) : null,
    sidebarPosition: asideStyle ? asideStyle.position : null,
    sidebarHeight: asideStyle ? asideStyle.height : null
  });
})()
