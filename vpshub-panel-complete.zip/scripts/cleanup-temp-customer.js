// Remove the temporary E2E test customer + all its data (idempotent)
const { PrismaClient } = require('@prisma/client');
const db = new PrismaClient();

(async () => {
  const u = await db.user.findUnique({ where: { email: 'tempcustomer@test.local' } });
  if (!u) { console.log('temp customer already gone'); await db.$disconnect(); return; }
  // cascades wipe tickets/messages/ssh keys/api keys/notifications/sessions
  await db.user.delete({ where: { id: u.id } });
  const left = await db.user.count({ where: { email: 'tempcustomer@test.local' } });
  console.log('temp customer deleted, remaining:', left);
  const tickets = await db.supportTicket.count();
  const users = await db.user.count();
  console.log('tickets left:', tickets, '| users left:', users);
  await db.$disconnect();
})().catch(e => { console.error(e); process.exit(1); });
