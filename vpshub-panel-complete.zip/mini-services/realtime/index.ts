// ============================================================
// VPS Platform — Realtime Service (socket.io)
// ============================================================
// Listens on port 3003. Forwards events pushed from the Next.js
// API routes (via /emit HTTP POST) to subscribed clients.
//
// Frontend always connects with io("/?XTransformPort=3003").
// ============================================================

import { Server as IOServer } from 'socket.io';
import { createServer } from 'http';
import cors from 'cors';

const PORT = 3003;
const httpServer = createServer();

// Simple CORS for the /emit HTTP endpoint (internal traffic from Next.js)
httpServer.on('request', (req, res) => {
  // CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  if (req.method === 'GET' && req.url === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ status: 'ok', port: PORT, ts: Date.now() }));
    return;
  }

  if (req.method === 'POST' && req.url === '/emit') {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        const payload = JSON.parse(body);
        const { event, room, payload: data } = payload;
        if (event && room) {
          io.to(room).emit(event, data);
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: true, delivered: true }));
        } else {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: false, error: 'missing fields' }));
        }
      } catch (err: any) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: false, error: err?.message || 'parse error' }));
      }
    });
    return;
  }

  res.writeHead(404);
  res.end('Not found');
});

// Socket.io server — handles real-time client subscriptions
const io = new IOServer(httpServer, {
  cors: { origin: '*', methods: ['GET', 'POST'] },
  path: '/socket.io/',
});

// ------------------------------------------------------------
// OPTIONAL Redis adapter — horizontal scaling for 2500+ users.
// Activates only when REDIS_URL is set (e.g. redis://127.0.0.1:6379).
// With the adapter active you can run several instances of this
// service behind a load balancer and every client receives its
// events regardless of which instance it connected to.
// ------------------------------------------------------------
const REDIS_URL = process.env.REDIS_URL || '';
if (REDIS_URL) {
  (async () => {
    try {
      const { createAdapter } = await import('@socket.io/redis-adapter');
      const { createClient } = await import('redis');
      const pubClient = createClient({ url: REDIS_URL });
      const subClient = pubClient.duplicate();
      await Promise.all([pubClient.connect(), subClient.connect()]);
      io.adapter(createAdapter(pubClient, subClient));
      console.log(`[realtime] Redis adapter ACTIVE (${REDIS_URL}) — multi-instance ready`);
    } catch (err: any) {
      console.warn(`[realtime] REDIS_URL set but adapter unavailable (${err?.message}) — running single-node`);
    }
  })();
}

// Track connected sockets and their rooms
const socketRooms = new Map<string, Set<string>>();

io.on('connection', (socket) => {
  console.log(`[realtime] client connected: ${socket.id}`);
  socketRooms.set(socket.id, new Set());

  // Client requests to join a room (after server-side authorization).
  // For now, the client passes an auth context derived from their
  // session token; we trust the room name because the frontend only
  // learns vps IDs from the API which enforces ownership.
  socket.on('subscribe', (room: string) => {
    socket.join(room);
    socketRooms.get(socket.id)?.add(room);
    socket.emit('subscribed', { room, ok: true });
  });

  socket.on('unsubscribe', (room: string) => {
    socket.leave(room);
    socketRooms.get(socket.id)?.delete(room);
  });

  // Console input — broadcast to the room so the terminal emulator
  // (which runs in a server context) can pick it up.
  socket.on('console.input', ({ vpsId, data }: { vpsId: string; data: string }) => {
    socket.to(`vps:${vpsId}:console`).emit('console.input', { vpsId, data, ts: Date.now() });
  });

  socket.on('disconnect', () => {
    socketRooms.delete(socket.id);
    console.log(`[realtime] client disconnected: ${socket.id}`);
  });
});

httpServer.listen(PORT, () => {
  console.log(`[realtime] VPS realtime service listening on port ${PORT}`);
});
