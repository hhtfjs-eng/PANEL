// ============================================================
// VPSHUB (DeUp-VPS) — Production Database Seed
// ============================================================
// Creates everything a FRESH database needs to run the panel:
//
//   1. Super admin account  — NØCTIS / nøctis@gmail.com / 123
//   2. Site settings        — branding (site.name, hero text, socials...)
//   3. VPS plans            — Starter / Standard / Performance / Enterprise
//   4. OS templates         — Ubuntu, Debian, Alma, Rocky, Windows, Proxmox
//   5. IP pools + addresses — main-v4 (10.0.0.0/24) + main-v6 (fd00::/64)
//
// Safe to run any number of times (idempotent — existing rows are
// left untouched, missing rows are created).
//
// Works for BOTH schemas:
//   SQLite     →  DATABASE_URL="file:./db/custom.db" node prisma/seed.mjs
//   PostgreSQL →  DATABASE_URL="postgresql://deup:...@127.0.0.1:5432/deup" node prisma/seed.mjs
//   Via Prisma →  npx prisma db seed [--schema prisma/schema.postgres.prisma]
//
// Node 18+ required. No TypeScript runner, no extra dependencies —
// uses @prisma/client and bcryptjs from package.json.
// ============================================================

import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

// --- load .env (does NOT override variables already set in the shell) ----
try {
  const fs = await import('node:fs');
  if (fs.existsSync('.env')) {
    for (const line of fs.readFileSync('.env', 'utf8').split('\n')) {
      const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m || line.trim().startsWith('#')) continue;
      const key = m[1];
      let val = m[2].replace(/^["']|["']$/g, '');
      if (!(key in process.env)) process.env[key] = val;
    }
  }
} catch { /* .env is optional */ }

const db = new PrismaClient();

// --- 1. Super admin -------------------------------------------------
const SUPER_ADMIN = {
  email: 'nøctis@gmail.com',
  username: 'noctis',
  name: 'NØCTIS',
  initialPassword: '123', // change immediately after first login!
};

// --- 2. Site settings (branding mirrors the live panel) --------------
const SETTINGS = [
  { key: 'site.name', value: 'VPSHUB Platform' },
  { key: 'site.support_email', value: 'support@vps-platform.local' },
  { key: 'customer.no_provision_message', value: 'VPS provisioning is managed by administrators. Contact support or your hosting administrator to request a VPS.' },
  { key: 'auth.registration_enabled', value: 'true' },
  { key: 'auth.email_verification_required', value: 'true' },
  { key: 'site.youtube_url', value: 'https://www.youtube.com/channel/UCILvOqZhASpc_Pk0ULdrKUQ' },
  { key: 'site.discord_url', value: 'https://discord.com' },
  { key: 'site.watermark_text', value: '' },
  { key: 'site.owner_credit', value: 'Made by YT' },
  { key: 'site.made_by_url', value: 'https://www.youtube.com/@DevAVoid' },
  { key: 'auth.hero_top', value: 'Admin-Controlled' },
  { key: 'auth.hero_bottom', value: 'VPS Provisioning' },
  { key: 'auth.hero_description', value: 'A production-grade virtual infrastructure management platform. Built for hosting providers who need strict separation between customer and administrative actions.' },
];

// --- 3. VPS plans -----------------------------------------------------
const PLANS = [
  { name: 'Starter VPS',     cpu: 2,  ramMb: 4096,  diskGb: 80,  bandwidthMbps: 2000,  priceMonthly: 5,  setupFee: 0 },
  { name: 'Standard VPS',    cpu: 4,  ramMb: 8192,  diskGb: 160, bandwidthMbps: 4000,  priceMonthly: 15, setupFee: 0 },
  { name: 'Performance VPS', cpu: 8,  ramMb: 16384, diskGb: 320, bandwidthMbps: 8000,  priceMonthly: 35, setupFee: 0 },
  { name: 'Enterprise VPS',  cpu: 16, ramMb: 32768, diskGb: 640, bandwidthMbps: 16000, priceMonthly: 75, setupFee: 0 },
];

// --- 4. OS templates --------------------------------------------------
// providerTemplateId notes:
//   · "ubuntu-2404"-style ids are fine for the LXC provider defaults;
//     for LXC `download` templates use "distro:version" (e.g. ubuntu:22.04)
//     — editable per template in Admin → OS Templates at any time.
const OS_TEMPLATES = [
  { name: 'Ubuntu 24.04 LTS', distribution: 'ubuntu', version: '24.04', providerTemplateId: 'ubuntu:24.04' },
  { name: 'Ubuntu 22.04 LTS', distribution: 'ubuntu', version: '22.04', providerTemplateId: 'ubuntu:22.04' },
  { name: 'Debian 13', distribution: 'debian', version: '13', providerTemplateId: 'debian:13' },
  { name: 'Debian 12', distribution: 'debian', version: '12', providerTemplateId: 'debian:12' },
  { name: 'AlmaLinux 9', distribution: 'almalinux', version: '9', providerTemplateId: 'almalinux:9' },
  { name: 'Rocky Linux 9', distribution: 'rocky', version: '9', providerTemplateId: 'rockylinux:9' },
  { name: 'Windows Server 2022', distribution: 'windows', version: '2022', providerTemplateId: 'win-2022' },
  { name: 'Proxmox VE 8.2', distribution: 'proxmox', version: '8.2', providerTemplateId: 'pve-ve-8.2' },
  { name: 'Proxmox VE 8.1', distribution: 'proxmox', version: '8.1', providerTemplateId: 'pve-ve-8.1' },
  { name: 'Ubuntu 24.04 Cloud-Init (Proxmox)', distribution: 'ubuntu', version: '24.04', providerTemplateId: 'pve-ubuntu-2404-cloudinit' },
  { name: 'Ubuntu 22.04 Cloud-Init (Proxmox)', distribution: 'ubuntu', version: '22.04', providerTemplateId: 'pve-ubuntu-2204-cloudinit' },
  { name: 'Debian 12 Cloud-Init (Proxmox)', distribution: 'debian', version: '12', providerTemplateId: 'pve-debian-12-cloudinit' },
  { name: 'AlmaLinux 9 Cloud-Init (Proxmox)', distribution: 'almalinux', version: '9', providerTemplateId: 'pve-almalinux-9-cloudinit' },
  { name: 'Rocky Linux 9 Cloud-Init (Proxmox)', distribution: 'rocky', version: '9', providerTemplateId: 'pve-rocky-9-cloudinit' },
  { name: 'Windows Server 2022 VirtIO (Proxmox)', distribution: 'windows', version: '2022', providerTemplateId: 'pve-win-2022-virtio' },
];

// --- 5. IP pools --------------------------------------------------------
const IP_POOLS = [
  { name: 'main-v4', family: 4, cidr: '10.0.0.0/24', gateway: '10.0.0.1', dnsPrimary: '1.1.1.1', dnsSecondary: '8.8.8.8', ips: Array.from({ length: 28 }, (_, i) => `10.0.0.${i + 2}`) },
  { name: 'main-v6', family: 6, cidr: 'fd00::/64', gateway: 'fd00::1', dnsPrimary: '2606:4700:4700::1111', dnsSecondary: '2606:4700:4700::1001', ips: Array.from({ length: 10 }, (_, i) => `fd00::${i + 2}`) },
];

async function main() {
  console.log('Seeding database…');

  // 1 — Super admin
  let admin = await db.user.findFirst({ where: { OR: [{ email: SUPER_ADMIN.email }, { username: SUPER_ADMIN.username }] } });
  if (!admin) {
    admin = await db.user.create({
      data: {
        name: SUPER_ADMIN.name,
        username: SUPER_ADMIN.username,
        email: SUPER_ADMIN.email,
        passwordHash: await bcrypt.hash(SUPER_ADMIN.initialPassword, 10),
        role: 'SUPER_ADMIN',
        status: 'ACTIVE',
        emailVerified: true,
      },
    });
    console.log(`  [+] Super admin created: ${admin.email} / "${admin.username}" (initial password: ${SUPER_ADMIN.initialPassword} — CHANGE IT after first login)`);
  } else {
    // keep any existing account (and any changed password) — just ensure it stays SUPER_ADMIN/ACTIVE
    if (admin.role !== 'SUPER_ADMIN' || admin.status !== 'ACTIVE') {
      await db.user.update({ where: { id: admin.id }, data: { role: 'SUPER_ADMIN', status: 'ACTIVE' } });
      console.log('  [=] Super admin found — role/status refreshed (password untouched)');
    } else {
      console.log('  [=] Super admin already present (password untouched)');
    }
  }

  // 2 — Settings
  for (const s of SETTINGS) {
    await db.setting.upsert({ where: { key: s.key }, update: {}, create: s });
  }
  console.log(`  [=] Settings present (${SETTINGS.length} keys)`);

  // 3 — Plans
  let plansCreated = 0;
  for (const p of PLANS) {
    const exists = await db.vpsPlan.findFirst({ where: { name: p.name } });
    if (!exists) {
      await db.vpsPlan.create({ data: { ...p, ipv4Included: true, ipv6Included: true, region: 'global', enabled: true } });
      plansCreated++;
    }
  }
  console.log(`  [=] VPS plans present (${PLANS.length} total, ${plansCreated} created)`);

  // 4 — OS templates
  let osCreated = 0;
  for (const os of OS_TEMPLATES) {
    const exists = await db.operatingSystem.findFirst({ where: { name: os.name } });
    if (!exists) {
      await db.operatingSystem.create({ data: { ...os, architecture: 'x86_64', available: true } });
      osCreated++;
    }
  }
  console.log(`  [=] OS templates present (${OS_TEMPLATES.length} total, ${osCreated} created)`);

  // 5 — IP pools + addresses
  let ipsCreated = 0;
  for (const pool of IP_POOLS) {
    let p = await db.ipPool.findFirst({ where: { name: pool.name } });
    if (!p) {
      p = await db.ipPool.create({
        data: { name: pool.name, family: pool.family, cidr: pool.cidr, gateway: pool.gateway, dnsPrimary: pool.dnsPrimary, dnsSecondary: pool.dnsSecondary },
      });
    }
    for (const addr of pool.ips) {
      const exists = await db.ipAddress.findFirst({ where: { address: addr } });
      if (!exists) {
        await db.ipAddress.create({ data: { poolId: p.id, address: addr, family: pool.family, state: 'AVAILABLE' } });
        ipsCreated++;
      }
    }
  }
  console.log(`  [=] IP pools present (2 pools, ${ipsCreated} addresses created)`);

  console.log('\nSeed complete. Login as super admin:');
  console.log(`  email/username: ${SUPER_ADMIN.email}  or  ${SUPER_ADMIN.username}`);
  console.log(`  password:       ${SUPER_ADMIN.initialPassword}  (change it immediately!)`);
}

main()
  .catch((e) => { console.error('SEED FAILED:', e); process.exit(1); })
  .finally(() => db.$disconnect());
