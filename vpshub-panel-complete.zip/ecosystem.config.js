// ============================================================
// DeUp-VPS — PM2 production process manager
// ============================================================
// Runs the Next.js panel in CLUSTER MODE (one process per CPU core)
// plus the socket.io realtime service. Built for 2500+ concurrent
// users — see DEPLOY.md for the full capacity plan.
//
//   pm2 start ecosystem.config.js     # start everything
//   pm2 save && pm2 startup           # survive reboots
//   pm2 logs deup-panel               # tail panel logs
//   pm2 scale deup-panel 8            # manual rescale
//
// Required environment (set inline or via .env + `pm2 start --env production`):
//   DATABASE_URL        postgresql://user:pass@localhost:5432/deup
//   REDIS_URL           redis://127.0.0.1:6379   (optional, enables the
//                       realtime adapter to scale across instances)
//   LXC_SSH_HOST        user@host (optional global LXC host fallback;
//                       per-node apiEndpoint takes priority)
// ============================================================

module.exports = {
  apps: [
    // -------- Next.js panel — cluster mode --------
    {
      name: 'deup-panel',
      cwd: __dirname,
      script: 'node_modules/next/dist/bin/next',
      args: 'start -p 3000',
      instances: process.env.CLUSTER_INSTANCES || 'max', // all cores
      exec_mode: 'cluster',
      max_memory_restart: '600M',
      kill_timeout: 8000,
      wait_ready: false,
      env: {
        NODE_ENV: 'production',
        PORT: 3000,
        // Realtime bridge (HTTP POST /emit from API routes)
        REALTIME_URL: process.env.REALTIME_URL || 'http://127.0.0.1:3003',
        ...(process.env.DATABASE_URL ? { DATABASE_URL: process.env.DATABASE_URL } : {}),
        ...(process.env.REDIS_URL ? { REDIS_URL: process.env.REDIS_URL } : {}),
        ...(process.env.LXC_SSH_HOST ? { LXC_SSH_HOST: process.env.LXC_SSH_HOST } : {}),
      },
      out_file: './logs/pm2-panel-out.log',
      error_file: './logs/pm2-panel-err.log',
      merge_logs: true,
      time: true,
    },

    // -------- socket.io realtime service — single instance --------
    // (Run MORE instances behind a TCP load balancer only after enabling
    //  the Redis adapter via REDIS_URL.)
    {
      name: 'deup-realtime',
      cwd: __dirname + '/mini-services/realtime',
      script: process.env.BUN_PATH || 'bun',
      args: 'index.ts',
      exec_mode: 'fork',
      max_memory_restart: '400M',
      env: {
        ...(process.env.REDIS_URL ? { REDIS_URL: process.env.REDIS_URL } : {}),
      },
      out_file: './logs/pm2-realtime-out.log',
      error_file: './logs/pm2-realtime-err.log',
      merge_logs: true,
      time: true,
    },
  ],
};
